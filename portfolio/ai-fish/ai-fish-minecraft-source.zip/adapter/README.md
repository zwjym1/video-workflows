# Qoder CN 游戏适配器

复用上游 MinecraftSession 和独立 Mineflayer 身体。Qoder CN 只生成聊天或单个高级动作计划；模型没有文件、Shell、浏览器或 MCP 工具。DSH 原版安装与模型选择保持独立。

## 启动与验证

先启动 Minecraft 测试服务器，再执行：

```powershell
node D:\AI-Fish\adapter\server.cjs
```

服务仅监听 `127.0.0.1:3100`，玩家为 `DaFeiYu`。同一时间不要在 DSH 中另开同名玩家。
本进程使用已登录的 `D:\AI-Fish\runtime\qodercn\qoderclicn.exe`，认证目录为 `D:\AI-Fish\data\qodercn`，不会自动调用国际版。
目前不启动摄像机，由主系统单独配置。

首次启动在 `D:\AI-Fish\data\adapter-token` 生成随机访问令牌；不要把令牌发到聊天或日志中。所有接口都要求 Bearer 认证，并检查 Host 和 Origin 是否为本机。未开放跨站访问。

## 接口

PowerShell 本机调用示例：

```powershell
$fishHeaders = @{ Authorization = 'Bearer ' + (Get-Content D:\AI-Fish\data\adapter-token -Raw).Trim() }
Invoke-RestMethod http://127.0.0.1:3100/state -Headers $fishHeaders
Invoke-RestMethod http://127.0.0.1:3100/tasks -Method Post -Headers $fishHeaders -ContentType application/json -Body '{"action":"collect","name":"oak_log","index":2}'
```

| 方法和路径 | 请求或结果 |
|---|---|
| GET `/state` | 世界时刻、近期事件、活动任务、思考/暂停状态 |
| GET `/tasks` | 历史任务，最多 200 项 |
| GET `/tasks/{id}` | 任务状态和进度 |
| POST `/tasks` | `{ "action":"craft", "name":"crafting_table", "index":1 }` |
| POST `/tasks/{id}/cancel` | 停止该活动任务并暂停适配器 |
| POST `/stop` | 停止游戏动作、取消模型思考、暂停适配器 |
| POST `/shutdown` | 安全断开身体、关闭 HTTP 与 SDK 进程，供主启动脚本使用 |
| POST `/resume` | 显式解除暂停，不自动重放任务 |
| POST `/chat` | `{ "text":"你在做什么？" }`，不打断身体任务 |
| POST `/plan` | `{ "text":"收集木头" }`，返回 `{reply,action,executed:false}` |

计划不会自动执行。调用者检查 `/plan` 返回的 `action` 后，可提交给 `/tasks`；接口会再次验证严格动作白名单和参数。只允许 `action/name/index/text` 字段，数量为 1..64。游戏聊天禁止以 `/` 开头的命令。
资源、方块和生物名称必须使用 `oak_log` 这样的 Minecraft 英文 ID，拒绝中文译名。`collect` 会自己寻找资源、寻路、采集和拾取，收集任务无需先调用 `find`。

## 上限与恢复

- 一次最多一个身体任务，最长 5 分钟，超时请求停止并暂停。
- 一次最多一个模型调用，最长 60 秒，最小间隔 10 秒，模型失败不自动重试。
- 身体任务失败、事件循环错误或模型错误时暂停；通过 `/resume` 明确恢复。
- 断线或事件消费失败后 `connected:false`，不能用 `/resume` 恢复或提交任务，需检查服务器后重启适配器。停止操作尚未完成时也不能恢复或提交新任务。
- 暂停时仍允许 `/chat` 对话，但聊天不会恢复身体任务；`/plan` 与 `/tasks` 仍被阻止。模型调用频率与超时上限继续生效。
- 聊天与思考不会调用身体 stop；原有移动、挖掘和自保由独立身体继续执行。
- 重启会把历史运行任务标为 `interrupted`，不会自动重放；可查询日志后重新提交。
- Ctrl+C / SIGTERM 关闭连接和 SDK daemon。Windows 强制结束进程可能来不及清理，重启时按中断处理。

## 记录

- `data\world-memory`：复用上游世界日志，包括目标、坐标、图纸和已支持的自动记录。
- `data\adapter-tasks.json`：任务历史。
- `logs\adapter-events.jsonl`、`logs\game-events.jsonl`：任务与游戏事件。
- 由主启动脚本运行时，`logs\adapter.log`、`logs\adapter-error.log` 保存身体子进程和适配器的主要控制台输出；直接运行时这些内容显示在当前终端。
- `logs\body-events.jsonl` 仅在上游虚影/预览等功能调用 `session.log` 时产生，不保证每次运行都存在，也不是主要身体日志。
- `logs\model-calls.jsonl`：国内版调用目的、响应延迟、服务报告的 usage/cost；`credits:null`、`costVerified:false` 表示未核实额度。零值不代表免费。

任务参数和世界聊天会作为游戏上下文交给 Qoder CN。适配器不上传项目源码、系统文件或无关凭据。
当前是受限的请求式规划适配器，尚未实现无人值守无限生存循环；实机、模型和摄像机验收由主会话执行。

## 本地检查

```powershell
node D:\AI-Fish\adapter\build.cjs
node D:\AI-Fish\adapter\test.cjs
```

测试不连接 Minecraft、不调用模型，验证接口认证、动作校验、重启中断、身体/思考并行、频率限制、取消与任务超时。
