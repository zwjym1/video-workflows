const http=require('node:http');
const fs=require('node:fs');
const path=require('node:path');
const {randomBytes,timingSafeEqual}=require('node:crypto');
function equal(a,b){return typeof a==='string'&&Buffer.byteLength(a)===Buffer.byteLength(b)&&timingSafeEqual(Buffer.from(a),Buffer.from(b));}
function createDashboard(options={}){
  const root=options.root||'D:/AI-Fish';
  const directory=options.directory||__dirname;
  const data=path.join(root,'data');fs.mkdirSync(data,{recursive:true});
  const launchFile=path.join(data,'ui-launch-token');
  if(!fs.existsSync(launchFile))fs.writeFileSync(launchFile,randomBytes(32).toString('hex'),{flag:'wx',mode:0o600});
  const launchToken=fs.readFileSync(launchFile,'utf8').trim();
  if(!/^[a-f0-9]{64}$/.test(launchToken))throw new Error('Invalid UI launch token');
  const sessions=new Map();
  const upstreamPort=options.upstreamPort||3100;
  const files=new Map([
    ['/',[path.join(directory,'public/index.html'),'text/html; charset=utf-8']],
    ['/app.js',[path.join(directory,'public/app.js'),'text/javascript; charset=utf-8']],
    ['/style.css',[path.join(directory,'public/style.css'),'text/css; charset=utf-8']],
  ]);
  const assetDir=path.join(root,'dsh-game/packages/dsh-game/assets/dafeiyu');
  for(const name of ['riceloop','think','ricetalk'])files.set('/fish/'+name+'.webm',[path.join(assetDir,name+'.webm'),'video/webm']);
  files.set('/fish/LICENSE.md',[path.join(assetDir,'LICENSE.md'),'text/plain; charset=utf-8']);
  const security={'cache-control':'no-store','x-content-type-options':'nosniff','referrer-policy':'no-referrer','content-security-policy':"default-src 'self'; script-src 'self'; style-src 'self'; media-src 'self'; connect-src 'self'; img-src 'self' data:; object-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"};
  function json(res,status,value){res.writeHead(status,{...security,'content-type':'application/json; charset=utf-8'});res.end(JSON.stringify(value));}
  function meta(){
    let records=[];try{const stat=fs.statSync(path.join(root,'logs/model-calls.jsonl'));if(stat.size<=16*1024*1024)records=fs.readFileSync(path.join(root,'logs/model-calls.jsonl'),'utf8').trim().split('\n').flatMap(line=>{try{return [JSON.parse(line)];}catch{return [];}}).filter(x=>x.provider==='qodercn');}catch{}
    const successes=records.filter(x=>x.success===true);const latest=successes.at(-1);
    return {provider:'Qoder CN',successfulCalls:successes.length,failedRecords:records.filter(x=>x.success===false).length,lastLatencyMs:Number.isFinite(latest?.latencyMs)?latest.latencyMs:null,lastSuccessAt:typeof latest?.at==='string'?latest.at:null,creditsVerified:false};
  }
  const server=http.createServer(async(req,res)=>{
    const port=server.address()?.port||3110;
    if(!['127.0.0.1:'+port,'localhost:'+port].includes(req.headers.host)){json(res,403,{error:'non_local_host'});return;}
    const url=new URL(req.url,'http://'+req.headers.host);
    if(req.method==='GET'&&url.pathname==='/'&&url.searchParams.has('access')){
      if(!equal(url.searchParams.get('access'),launchToken)){json(res,401,{error:'invalid_launch_link'});return;}
      const session=randomBytes(32).toString('hex');
      for(const [key,expiry] of sessions)if(expiry<Date.now())sessions.delete(key);
      if(sessions.size>=20)sessions.delete(sessions.keys().next().value);
      sessions.set(session,Date.now()+24*60*60*1000);
      res.writeHead(303,{...security,location:'/', 'set-cookie':'fish_session='+session+'; HttpOnly; SameSite=Strict; Path=/; Max-Age=86400'});res.end();return;
    }
    const cookie=(req.headers.cookie||'').split(';').map(v=>v.trim()).find(v=>v.startsWith('fish_session='))?.slice('fish_session='.length);
    if(!cookie||!sessions.has(cookie)||sessions.get(cookie)<Date.now()){json(res,401,{error:'open_launch_link'});return;}
    if(req.method==='POST'){
      if(req.headers.origin!=='http://'+req.headers.host){json(res,403,{error:'non_local_origin'});return;}
      if(!/^application\/json(?:;|$)/i.test(req.headers['content-type']||'')){json(res,415,{error:'json_required'});return;}
    }
    if(req.method==='GET'&&files.has(url.pathname)){
      const [file,mime]=files.get(url.pathname);let stat;try{stat=fs.statSync(file);}catch{json(res,404,{error:'file_not_found'});return;}
      let start=0,end=stat.size-1,status=200;
      if(req.headers.range){const match=/^bytes=(\d+)-(\d*)$/.exec(req.headers.range);if(!match){res.writeHead(416,{...security,'content-range':'bytes */'+stat.size});res.end();return;}start=Number(match[1]);end=match[2]?Number(match[2]):end;if(start>end||start>=stat.size){res.writeHead(416,{...security,'content-range':'bytes */'+stat.size});res.end();return;}end=Math.min(end,stat.size-1);status=206;}
      const headers={...security,'content-type':mime,'content-length':end-start+1,'accept-ranges':'bytes'};if(status===206)headers['content-range']=`bytes ${start}-${end}/${stat.size}`;
      res.writeHead(status,headers);const stream=fs.createReadStream(file,{start,end});stream.on('error',()=>res.destroy());res.on('close',()=>stream.destroy());stream.pipe(res);return;
    }
    if(req.method==='GET'&&url.pathname==='/api/meta'){json(res,200,meta());return;}
    const target=url.pathname.startsWith('/api/')?url.pathname.slice(4):'';
    const allowedGet=req.method==='GET'&&(['/state','/tasks'].includes(target)||/^\/tasks\/[a-f0-9-]+$/.test(target));
    const allowedPost=req.method==='POST'&&(['/chat','/plan','/tasks','/stop','/resume'].includes(target)||/^\/tasks\/[a-f0-9-]+\/cancel$/.test(target));
    if(!allowedGet&&!allowedPost){json(res,404,{error:'not_found'});return;}
    let body;
    if(allowedPost){let size=0;const parts=[];for await(const chunk of req){size+=chunk.length;if(size>16384){json(res,413,{error:'request_too_large'});return;}parts.push(chunk);}body=Buffer.concat(parts).toString('utf8')||'{}';let parsed;try{parsed=JSON.parse(body);}catch{json(res,400,{error:'invalid_json'});return;}
      if(!parsed||typeof parsed!=='object'||Array.isArray(parsed)){json(res,400,{error:'invalid_json'});return;}
      if(target==='/plan'&&typeof parsed.text==='string'){
        const guidance='\nPlanning constraints: resource/block/item/entity names must use canonical lowercase Minecraft English IDs, never translated names. collect searches, navigates and gathers automatically; do not call find first for collection. Examples: oak_log, crafting_table, wooden_pickaxe. Return one safe action only.';
        if(parsed.text.length>3600){json(res,400,{error:'invalid_prompt'});return;}
        parsed.text+=guidance;body=JSON.stringify(parsed);
      }
      if(target==='/tasks'&&['collect','craft','smelt','find','attack','equip','drop','bucket','use','breed','shear'].includes(parsed.action)&&!/^[a-z0-9_]+$/.test(parsed.name||'')){json(res,400,{error:'invalid_item'});return;}
    }
    try{
      const token=fs.readFileSync(path.join(data,'adapter-token'),'utf8').trim();
      const response=await fetch('http://127.0.0.1:'+upstreamPort+target,{method:req.method,headers:{authorization:'Bearer '+token,'content-type':'application/json'},body:allowedPost?body:undefined,signal:AbortSignal.timeout(70000)});
      const value=await response.json();json(res,response.status,value);
    }catch{json(res,503,{error:'adapter_unavailable'});}
  });
  server.requestTimeout=75000;server.headersTimeout=10000;
  return {server,launchToken};
}
if(require.main===module){const {server}=createDashboard();server.on('error',error=>{console.error('Dashboard could not start: '+(error.code||'unknown'));process.exitCode=1;});server.listen(3110,'127.0.0.1',()=>console.log('AI-Fish feedback dashboard ready at http://127.0.0.1:3110 (launch link required).'));}
module.exports={createDashboard};
