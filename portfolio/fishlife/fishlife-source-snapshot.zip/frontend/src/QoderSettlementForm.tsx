import { useEffect, useRef, useState, type FormEvent } from "react";
import { api, errorText } from "./api";
import { Notice } from "./components";

export function QoderSettlementForm({ reservation, reserved, onSettled }: {
  reservation: string; reserved: string | number; onSettled: () => void;
}) {
  const [dollars, setDollars] = useState("");
  const [credits, setCredits] = useState("");
  const [digest, setDigest] = useState("");
  const [acknowledged, setAcknowledged] = useState(false);
  const [busy, setBusy] = useState(false);
  const [hashing, setHashing] = useState(false);
  const [error, setError] = useState("");
  const live = useRef(true);
  const fileTicket = useRef(0);
  const previous = useRef<{ signature: string; key: string } | null>(null);
  useEffect(() => {
    live.current = true;
    return () => { live.current = false; fileTicket.current++; };
  }, []);

  async function fingerprint(file: File | undefined) {
    const ticket = ++fileTicket.current;
    setDigest(""); setAcknowledged(false); setError("");
    if (!file) return;
    if (file.size === 0 || file.size > 5 * 1024 * 1024) {
      setError("请选择非空且不超过 5 MB 的核对材料。"); return;
    }
    setHashing(true);
    try {
      const hash = await crypto.subtle.digest("SHA-256", await file.arrayBuffer());
      if (live.current && ticket === fileTicket.current)
        setDigest(Array.from(new Uint8Array(hash), n => n.toString(16).padStart(2, "0")).join(""));
    } catch {
      if (live.current && ticket === fileTicket.current) setError("无法读取核对材料，请重新选择。");
    } finally {
      if (live.current && ticket === fileTicket.current) setHashing(false);
    }
  }

  async function submit(event: FormEvent) {
    event.preventDefault();
    if (busy || hashing || !acknowledged || !digest) return;
    const amount = /^(?:0|[1-9]\d*)(?:\.\d{1,8})?$/;
    if (!amount.test(dollars) || !amount.test(credits)) {
      setError("请输入非负金额，最多保留 8 位小数；没有扣费时请明确填 0。"); return;
    }
    const payload = { actual_cost_usd: dollars, actual_credits: credits,
      evidence_sha256: digest, expected_reserved_usd: String(reserved),
      acknowledgement: "我已核对这次调用的供应商账单" };
    const signature = JSON.stringify(payload);
    if (previous.current?.signature !== signature)
      previous.current = { signature, key: crypto.randomUUID() };
    const key = previous.current.key;
    setBusy(true); setError("");
    try {
      await api(`/costs/qoder/${reservation}/settlement`, "POST", {
        ...payload, idempotency_key: key,
      });
      if (live.current) onSettled();
    } catch (e) {
      if (live.current) setError(errorText(e));
    } finally { if (live.current) setBusy(false); }
  }

  return <details>
    <summary>我已查清账单，记录人工确认</summary>
    <p>请先在供应商账单核对这次请求。确认后会把预算预占改为你填写的已发生支出，
      并记录人工确认；不会重发原请求，也不会开启模型。原始供应商报告保留。
      若实际支出超过预占，仍按实际金额记账，之后的新请求受剩余预算限制。</p>
    <form onSubmit={e => void submit(e)}>
      <label>已核对的美元支出
        <input required inputMode="decimal" value={dollars} disabled={busy}
          onChange={e => { setDollars(e.target.value); setAcknowledged(false); }} />
      </label>
      <label>已核对的 Credits 扣除
        <input required inputMode="decimal" value={credits} disabled={busy}
          onChange={e => { setCredits(e.target.value); setAcknowledged(false); }} />
      </label>
      <p>两项分别填写；未扣除请填 0。无法确定时请保留待核对状态。</p>
      <label>选择本地账单核对材料（不超过 5 MB）
        <input type="file" disabled={busy || hashing}
          onChange={e => void fingerprint(e.target.files?.[0])} />
      </label>
      <p>文件留在本机，只保存 SHA-256 核对指纹，不上传文件内容。
        指纹用于追溯你核对的材料，不证明供应商已自动验证。</p>
      {hashing && <p role="status">正在本机计算核对指纹…</p>}
      {digest && <p>核对指纹已生成。</p>}
      <label><input type="checkbox" checked={acknowledged} disabled={busy || hashing}
        onChange={e => setAcknowledged(e.target.checked)} />
        我已核对这次调用的供应商账单，确认以上两项金额。
      </label>
      <button disabled={busy || hashing || !digest || !acknowledged || !dollars || !credits}>
        {busy ? "正在保存人工确认…" : "保存人工确认并结算预算"}
      </button>
      <p>网络出错后可使用相同材料和金额再次提交，系统会核对确认编号，防止重复记账。
        这项确认不代替项目外历史调用的人工核对。</p>
      {error && <Notice error>{error}</Notice>}
    </form>
  </details>;
}
