type Voice = {localService: boolean; lang: string};
type Callback = (...args: never[]) => unknown;
type Utterance<V> = {voice?: V | null; lang?: string; onstart?: Callback | null;
  onend?: Callback | null; onerror?: Callback | null};
export type LocalSpeechState = "queued" | "speaking" | "idle" | "stopped" | "unavailable";

export function createLocalSpeechController<V extends Voice, U extends Utterance<V>>(
  synth: {getVoices(): V[]; cancel(): void; speak(utterance: U): void},
  makeUtterance: (text: string) => U,
  update: (state: LocalSpeechState) => void,
) {
  let generation = 0;
  function stop() { generation++; synth.cancel(); update("stopped"); }
  return {
    stop,
    dispose() { generation++; synth.cancel(); },
    play(text: string) {
      if (!text.trim() || text.length > 12000) return false;
      const voices = synth.getVoices().filter(v => v.localService === true);
      const voice = voices.find(v => v.lang.toLowerCase().startsWith("zh")) ?? voices[0];
      if (!voice) { stop(); update("unavailable"); return false; }
      const current = ++generation;
      synth.cancel();
      const utterance = makeUtterance(text);
      utterance.voice = voice; utterance.lang = voice.lang;
      utterance.onstart = () => { if (current === generation) update("speaking"); };
      utterance.onend = () => { if (current === generation) update("idle"); };
      utterance.onerror = () => { if (current === generation) update("unavailable"); };
      update("queued");
      try { synth.speak(utterance); return true; }
      catch { generation++; update("unavailable"); return false; }
    },
  };
}
