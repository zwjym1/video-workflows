import { useEffect, useRef, useState, type FormEvent } from "react";
import { api, list, errorText, when, type Character } from "./api";
import { Notice } from "./components";
import { PlanningPolicy } from "./PlanningPolicy";
import { ReadingSuggestions } from "./ReadingSuggestions";
import { InterestGrowth } from "./InterestGrowth";

type Goal = {
  id: string;
  title: string;
  material: string;
  priority: number;
  status: string;
  version: number;
};
type Schedule = {
  id: string;
  interval_seconds: number;
  enabled: boolean;
  next_run_at: string;
  version: number;
};
type Autonomy = {
  enabled: boolean;
  capability_enabled: boolean;
  paused: boolean;
};
type Activity = {
  id: string;
  kind: "local_activity" | "activity_plan";
  goal_id: string | null;
  status: string;
  error_code?: string;
  created_at: string;
  result?: {
    excerpt_lines?: string[];
    checklist?: string[];
    method?: string;
    source_hash?: string;
    verification?: Record<string, unknown>;
    reason?: string;
    quiet?: boolean;
    selected_task_id?: string;
  };
};
type Journal = {
  id: string;
  local_date: string;
  body: string;
  status: string;
  sources: { event_id: string; event_type: string; occurred_at: string }[];
};
const states: Record<string, string> = {
  active: "待整理",
  completed: "已完成",
  cancelled: "已取消",
  queued: "已排队",
  running: "处理中",
  succeeded: "核验完成",
  failed: "失败",
  unknown: "结果不确定",
  retry_wait: "等待重试",
};

export function Life({
  character,
  journalsOnly = false,
  onCharacterChanged,
}: {
  character: Character;
  journalsOnly?: boolean;
  onCharacterChanged?: (character: Character) => void;
}) {
  const [goals, setGoals] = useState<Goal[]>([]),
    [schedules, setSchedules] = useState<Schedule[]>([]);
  const [activities, setActivities] = useState<Activity[]>([]),
    [journals, setJournals] = useState<Journal[]>([]);
  const [autonomy, setAutonomy] = useState<Autonomy | null>(null);
  const [activityCursor, setActivityCursor] = useState<string | null>(null);
  const [journalCursor, setJournalCursor] = useState<string | null>(null);
  const [goalCursor, setGoalCursor] = useState<string | null>(null);
  const [paging, setPaging] = useState(false);
  const pagingLock = useRef(false);
  const generation = useRef(0);
  const currentCharacter = useRef(character.id);
  currentCharacter.current = character.id;
  const [deleting, setDeleting] = useState<Goal | null>(null);
  const [title, setTitle] = useState(""),
    [material, setMaterial] = useState(""),
    [priority, setPriority] = useState(3);
  const [minutes, setMinutes] = useState(60),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [info, setInfo] = useState("");
  const base = `/characters/${character.id}`;
  async function refresh(signal?: AbortSignal) {
    const current = ++generation.current;
    setGoals([]); setActivities([]); setJournals([]);
    setGoalCursor(null); setActivityCursor(null); setJournalCursor(null);
    pagingLock.current = false; setPaging(false);
    const [g, s, a, j, p] = await Promise.all([
      list<Goal>(base + "/goals", signal),
      list<Schedule>(base + "/schedules", signal),
      list<Activity>(base + "/activities", signal),
      list<Journal>(base + "/journals", signal),
      api<Autonomy>(base + "/autonomy", "GET", undefined, undefined, signal),
    ]);
    if (signal?.aborted || current !== generation.current || currentCharacter.current !== character.id) return;
    setGoals(g.items);
    setGoalCursor(g.next_cursor ?? null);
    setSchedules(s.items);
    setActivities(a.items);
    setJournals(j.items);
    setActivityCursor(a.next_cursor ?? null);
    setJournalCursor(j.next_cursor ?? null);
    setAutonomy(p);
  }
  useEffect(() => {
    const c = new AbortController();
    const stopped = () => {
      void refresh(c.signal).catch((e) => {
        if (!c.signal.aborted) setError(errorText(e));
      });
    };
    window.addEventListener("fishlife:safety-changed", stopped);
    void refresh(c.signal).catch((e) => {
      if (!c.signal.aborted) setError(errorText(e));
    });
    return () => {
      generation.current++;
      c.abort();
      window.removeEventListener("fishlife:safety-changed", stopped);
    };
  }, [character.id]);
  async function loadMore(kind: "activities" | "journals" | "goals") {
    const cursor = kind === "activities" ? activityCursor : kind === "goals" ? goalCursor : journalCursor;
    if (!cursor || pagingLock.current || busy) return;
    const current = generation.current;
    pagingLock.current = true; setPaging(true); setError("");
    try {
      const page = await list<Activity | Journal | Goal>(`${base}/${kind}?cursor=${encodeURIComponent(cursor)}`);
      if (current !== generation.current || currentCharacter.current !== character.id) return;
      if (kind === "activities") {
        setActivities((old) => [...old, ...(page.items as Activity[]).filter((x) => !old.some((y) => x.id === y.id))]);
        setActivityCursor(page.next_cursor ?? null);
      } else if (kind === "goals") {
        setGoals((old) => [...old, ...(page.items as Goal[]).filter((x) => !old.some((y) => x.id === y.id))]);
        setGoalCursor(page.next_cursor ?? null);
      } else {
        setJournals((old) => [...old, ...(page.items as Journal[]).filter((x) => !old.some((y) => x.id === y.id))]);
        setJournalCursor(page.next_cursor ?? null);
      }
    } catch (e) {
      if (current === generation.current) setError(errorText(e));
    } finally {
      if (current === generation.current) { pagingLock.current = false; setPaging(false); }
    }
  }
  async function act(operation: () => Promise<void>) {
    generation.current++;
    pagingLock.current = false; setPaging(false);
    setGoals([]); setActivities([]); setJournals([]);
    setGoalCursor(null); setActivityCursor(null); setJournalCursor(null);
    setBusy(true);
    setError("");
    setInfo("");
    try {
      await operation();
      if (currentCharacter.current !== character.id) return;
      await refresh();
    } catch (e) {
      setError(errorText(e));
    } finally {
      setBusy(false);
    }
  }
  function createGoal(e: FormEvent) {
    e.preventDefault();
    void act(async () => {
      await api(base + "/goals", "POST", { title, material, priority });
      setTitle("");
      setMaterial("");
      setInfo(`目标已保存。启用站内活动并设置日程后，${character.name}会整理一次材料。`);
    });
  }
  function saveSchedule(e: FormEvent) {
    e.preventDefault();
    void act(async () => {
      const s = schedules[0];
      await api(
        s ? `/schedules/${s.id}` : base + "/schedules",
        s ? "PATCH" : "POST",
        { interval_seconds: minutes * 60, enabled: true },
        s ? { "If-Match": String(s.version) } : undefined,
      );
      setInfo("日程已保存；错过多次唤醒时只合并处理一次。");
    });
  }
  return (
    <>
      <div className="page-heading">
        <div>
          <p className="eyebrow">
            {journalsOnly ? "JOURNAL WITH EVIDENCE" : "GOALS & LOCAL LIFE"}
          </p>
          <h1>{journalsOnly ? "有来源的日记" : "让目标慢慢有进展"}</h1>
        </div>
        <button disabled={busy} onClick={() => void act(async () => {})}>
          刷新记录
        </button>
      </div>
      <Notice>
        本地活动整理你提供的材料，生成摘录和模板清单。可选的模型选择需另行开启并受次数和预算限制；没有待办时会保持安静。
        本地默认选择先看优先级，在最早的至多3个候选中，同优先级优先匹配角色兴趣的标题；这只是本机关键词匹配，不会自行创造新目标。
      </Notice>
      {!journalsOnly && <p className="muted">当前兴趣：{character.interests.length ? character.interests.join("、") : "尚未设置，可到角色设定中填写"}。
        兴趣排序不增加模型调用；单独开启模型选择时，最终仍由该次模型选择决定。</p>}
      {error && <Notice error>{error}</Notice>}
      {info && <Notice>{info}</Notice>}
      {!journalsOnly && (
        <>
          <section className="life-controls">
            <div>
              <h2>
                {autonomy?.enabled
                  ? "全部角色站内活动已启用"
                  : "全部角色站内活动已暂停"}
              </h2>
              <p>
                暂停会取消尚未提交的站内任务并抑制新分享，聊天仍可使用。站内分享由陪伴偏好控制。
              </p>
            </div>
            <button
              className={autonomy?.enabled ? "danger" : "primary"}
              disabled={busy || !autonomy || !autonomy.capability_enabled}
              onClick={() =>
                void act(async () => {
                  await api(base + "/autonomy", "PATCH", {
                    enabled: !autonomy?.enabled,
                  });
                })
              }
            >
              {autonomy?.enabled ? "暂停全部角色活动" : "启用全部角色站内活动"}
            </button>
            <button
              disabled={busy || !autonomy?.enabled}
              onClick={() =>
                void act(async () => {
                  const r = await api<{ status: string; reason?: string }>(
                    base + "/wake",
                    "POST",
                    {},
                    { "Idempotency-Key": crypto.randomUUID() },
                  );
                  setInfo(
                    r.status === "quiet"
                      ? `当前没有可执行的目标，${character.name}保持安静。`
                      : "已记录本次唤醒，稍后刷新查看实际结果。",
                  );
                })
              }
            >
              现在唤醒一次
            </button>
          </section>
          <PlanningPolicy key={character.id} characterId={character.id} />
          <ReadingSuggestions key={`reading-${character.id}`} characterId={character.id} />
          <InterestGrowth key={`growth-${character.id}`} characterId={character.id} onChanged={onCharacterChanged} />
          <div className="life-columns">
            <form className="settings-form" onSubmit={createGoal}>
              <h2>添加一个小目标</h2>
              <label>
                目标名称
                <input
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  required
                  maxLength={120}
                />
              </label>
              <label>
                供{character.name}整理的材料
                <textarea
                  value={material}
                  onChange={(e) => setMaterial(e.target.value)}
                  required
                  rows={6}
                  maxLength={6000}
                  placeholder="粘贴你自己的笔记或待整理内容。它只会处理这些文字，不会声称读过其他资料。"
                />
              </label>
              <label>
                优先级
                <select
                  value={priority}
                  onChange={(e) => setPriority(Number(e.target.value))}
                >
                  {[1, 2, 3, 4, 5].map((x) => (
                    <option key={x} value={x}>
                      {x}
                      {x === 5 ? " · 最高" : ""}
                    </option>
                  ))}
                </select>
              </label>
              <button
                className="primary"
                disabled={busy || !title.trim() || !material.trim()}
              >
                保存目标
              </button>
            </form>
            <form className="settings-form" onSubmit={saveSchedule}>
              <h2>定时醒来</h2>
              <label>
                间隔（分钟）
                <input
                  type="number"
                  min={1}
                  max={1440}
                  value={minutes}
                  onChange={(e) => setMinutes(Number(e.target.value))}
                  required
                />
              </label>
              <p>
                每轮最多选择一个目标，每个目标只整理一次。完成后不会反复制造新任务。
              </p>
              <button disabled={busy}>保存并启用日程</button>
              {schedules.map((s) => (
                <div key={s.id}>
                  <p>
                    当前：每 {s.interval_seconds / 60} 分钟 ·{" "}
                    {s.enabled ? "已启用" : "已停用"}
                  </p>
                  <p>下次：{when(s.next_run_at)}</p>
                  <button
                    type="button"
                    disabled={busy}
                    onClick={() =>
                      void act(async () => {
                        await api(
                          `/schedules/${s.id}`,
                          "PATCH",
                          {
                            interval_seconds: s.interval_seconds,
                            enabled: !s.enabled,
                          },
                          { "If-Match": String(s.version) },
                        );
                      })
                    }
                  >
                    {s.enabled ? "停用日程" : "启用日程"}
                  </button>
                </div>
              ))}
            </form>
          </div>
          <h2>目标</h2>
          <div className="memory-grid">
            {goals.map((g) => (
              <article className="memory-card" key={g.id}>
                <span className="tag">{states[g.status] ?? g.status}</span>
                <h3>{g.title}</h3>
                <p className="life-source">{g.material}</p>
                <small>优先级 {g.priority}</small>
                {g.status === "active" && (
                  <button
                    disabled={busy}
                    onClick={() =>
                      void act(async () => {
                        await api(
                          `/goals/${g.id}`,
                          "PATCH",
                          { status: "cancelled" },
                          { "If-Match": String(g.version) },
                        );
                      })
                    }
                  >
                    取消目标
                  </button>
                )}
                <button
                  className="danger"
                  disabled={busy}
                  onClick={() => setDeleting(g)}
                >
                  删除材料与结果
                </button>
              </article>
            ))}
            {!goals.length && (
              <p className="empty-state">
                还没有目标。先添加材料，再决定是否启用站内活动。
              </p>
            )}
          </div>
          {goalCursor && <button disabled={busy || paging} onClick={() => void loadMore("goals")}>
            {paging ? "正在读取…" : "加载更早目标"}
          </button>}
          <h2>实际活动记录</h2>
          <div className="timeline">
            {activities.map((a) => (
              <article key={a.id}>
                <small>{when(a.created_at)}</small>
                <h3>{a.kind === "activity_plan"
                  ? `活动选择 · ${a.status === "succeeded" ? "选择已结束" : (states[a.status] ?? a.status)}`
                  : (states[a.status] ?? a.status)}</h3>
                {a.error_code && <p>{a.error_code}</p>}
                {a.kind === "activity_plan" && a.result && <div>
                  <p>{a.result.quiet ? "本次选择保持安静。" : "建议已记录，实际执行另有活动记录。"}</p>
                  <p className="muted">模型建议（推测）：{a.result.reason ?? "理由已清除或未保存"}</p>
                </div>}
                {a.kind !== "activity_plan" && a.result && (
                  <div>
                    <h4>材料摘录</h4>
                    {a.result.excerpt_lines?.map((line, i) => (
                      <blockquote key={i}>{line}</blockquote>
                    ))}
                    <h4>下一步清单（模板建议）</h4>
                    <ul>
                      {a.result.checklist?.map((line, i) => (
                        <li key={i}>{line}</li>
                      ))}
                    </ul>
                    <p className="muted">{a.result.method}</p>
                    <details>
                      <summary>查看结果与核验依据</summary>
                      <pre className="life-result">
                        {JSON.stringify(a.result, null, 2)}
                      </pre>
                    </details>
                  </div>
                )}
              </article>
            ))}
            {!activities.length && (
              <p className="empty-state">
                尚无活动记录。生成文字不代表任务已核验完成。
              </p>
            )}
          </div>
          {activityCursor && <button disabled={busy || paging} onClick={() => void loadMore("activities")}>
            {paging ? "正在读取…" : "加载更早活动"}
          </button>}
        </>
      )}
      <h2>{character.name}的日记</h2>
      <div className="memory-grid">
        {journals.map((j) => (
          <article className="memory-card" key={j.id}>
            <span className="tag">
              {j.local_date} ·{" "}
              {j.status === "invalidated" ? "来源已失效" : "实际活动摘要"}
            </span>
            <p className="life-source">
              {j.body || "来源已清理，日记不再显示原文。"}
            </p>
            <details>
              <summary>查看实际事件来源</summary>
              {j.sources?.map((s) => (
                <p key={s.event_id}>
                  {when(s.occurred_at)} · {s.event_type}
                  <br />
                  <small>事件 {s.event_id}</small>
                </p>
              ))}
            </details>
          </article>
        ))}
        {!journals.length && (
          <p className="empty-state">
            有真实活动后才会留下日记，不会为了热闹编造经历。
          </p>
        )}
      </div>
      {journalCursor && <button disabled={busy || paging} onClick={() => void loadMore("journals")}>
        {paging ? "正在读取…" : "加载更早日记"}
      </button>}
      <p className="muted">刷新或执行操作后，历史列表回到首页并重新核验来源；可再次加载更早记录。</p>
      {deleting && (
        <div className="modal-scrim">
          <section
            className="modal"
            role="dialog"
            aria-modal="true"
            aria-label="删除目标材料"
          >
            <h2>删除材料与相关结果</h2>
            <p>
              将清除“{deleting.title}
              ”的在线原文、整理结果和关联日记。此操作无法在页面中撤销；历史备份不在本次清理范围内。
            </p>
            {error && <Notice error>{error}</Notice>}
            <div className="card-actions">
              <button disabled={busy} onClick={() => setDeleting(null)}>
                保留
              </button>
              <button
                className="danger"
                disabled={busy}
                onClick={() =>
                  void act(async () => {
                    await api(`/goals/${deleting.id}`, "DELETE");
                    setDeleting(null);
                    setInfo("目标材料和关联在线结果已清理。");
                  })
                }
              >
                确认删除材料
              </button>
            </div>
          </section>
        </div>
      )}
    </>
  );
}
