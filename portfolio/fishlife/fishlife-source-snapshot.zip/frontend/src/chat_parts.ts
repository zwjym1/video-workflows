/** Display only: preserve the stored reply and never split on punctuation. */
export function chatParts(text: string): string[] {
  if (!text.trim()) return [];
  if (text.includes("```")) return [text];
  const parts = text.split(/\r?\n\s*\r?\n/).map((s) => s.trim()).filter(Boolean);
  return parts.length <= 4 ? parts : [...parts.slice(0, 3), parts.slice(3).join("\n\n")];
}
