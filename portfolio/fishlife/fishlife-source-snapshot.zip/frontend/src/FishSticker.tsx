export const fishStickers = ["开心", "贴贴", "疑惑", "困困"] as const;

export function FishSticker({ text }: {text: string}) {
  const match = /^\[表情：(开心|贴贴|疑惑|困困)\]$/.exec(text.trim());
  if (!match) return null;
  const mood = match[1];
  return <svg viewBox="0 0 180 130" width="160" height="116" role="img" aria-label={`大肥鱼：${mood}`}>
    <title>大肥鱼：{mood}</title>
    <path d="M126 65L165 37Q158 66 165 95Z" fill="#51a7ce" stroke="#23617d" strokeWidth="3" />
    <ellipse cx="79" cy="65" rx="65" ry="48" fill="#89d5ee" stroke="#23617d" strokeWidth="3" />
    <path d="M64 22Q85 0 104 24M67 106Q85 125 104 104" fill="#51a7ce" stroke="#23617d" strokeWidth="3" />
    {mood === "困困" ? <path d="M37 55h14m23 0h14" stroke="#214d67" strokeWidth="4" strokeLinecap="round" /> : <g fill="#214d67"><circle cx="44" cy="53" r="5"/><circle cx="81" cy="53" r="5"/></g>}
    <ellipse cx="30" cy="71" rx="10" ry="5" fill="#f3a8af"/><ellipse cx="93" cy="71" rx="10" ry="5" fill="#f3a8af"/>
    <path d={mood === "疑惑" ? "M57 77q6 -6 12 0" : "M53 74q10 15 22 0"} fill="none" stroke="#214d67" strokeWidth="3" strokeLinecap="round" />
    <text x="128" y="25" fontSize="23" fill="#526e80">{mood === "疑惑" ? "?" : mood === "困困" ? "zZ" : mood === "贴贴" ? "♥" : "♪"}</text>
    <text x="65" y="126" fontSize="14" fill="currentColor">{mood}</text>
  </svg>;
}
