import { useEffect, useRef, useState, type FormEvent } from "react";
import { api, errorText } from "./api";
import { Notice } from "./components";

type Match = { ordinal: number; source_hash: string; excerpt: string; matched_terms: string[] };
type Results = { items: Match[]; total_matches: number; mode: string };

export function ReadingSearch({ bookId, segments, disabled, onSelect }: {
  bookId: string; segments: number; disabled: boolean; onSelect: (ordinal: number) => void;
}) {
  const [query, setQuery] = useState("");
  const [page, setPage] = useState(1);
  const [results, setResults] = useState<Results | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const request = useRef<AbortController | null>(null), alive = useRef(true);
  const ticket = useRef(0);
  useEffect(() => {
    alive.current = true;
    return () => { alive.current = false; ticket.current++; request.current?.abort(); };
  }, []);
  async function search(event: FormEvent) {
    event.preventDefault();
    if (disabled || !query.trim()) return;
    request.current?.abort();
    const controller = new AbortController(), current = ++ticket.current;
    request.current = controller; setBusy(true); setError(""); setResults(null);
    try {
      const value = await api<Results>(`/books/${bookId}/search?q=${encodeURIComponent(query)}`,
        "GET", undefined, undefined, controller.signal);
      if (alive.current && !controller.signal.aborted && ticket.current === current) setResults(value);
    } catch (e) {
      if (alive.current && !controller.signal.aborted && ticket.current === current) setError(errorText(e));
    } finally {
      if (alive.current && ticket.current === current) setBusy(false);
    }
  }
  return <section className="settings-form">
    <h3>在整份资料里找原文</h3>
    <p>在本机按关键词查找，不调用模型。中文请使用原文中的词语，多个词用空格分开；这不是语义理解。</p>
    <form onSubmit={(event) => void search(event)}>
      <label>关键词<input value={query} maxLength={120} disabled={disabled}
        onChange={(event) => {
          ticket.current++; request.current?.abort(); setBusy(false); setResults(null);
          setQuery(event.target.value); setError("");
        }} /></label>
      <button disabled={disabled || busy || !query.trim()}>{busy ? "查找中…" : "在本机查找"}</button>
    </form>
    {error && <Notice error>{error}</Notice>}
    {results && <p>找到 {results.total_matches} 个相关段落，最多展示10段。点击后核对原文，再决定是否向云端提问。</p>}
    {results?.items.map((item) => <article className="memory-card" key={item.ordinal}>
      <h4>第 {item.ordinal + 1} 段</h4><p className="life-source">{item.excerpt}</p>
      <small>匹配：{item.matched_terms.join("、")}</small>
      <button disabled={disabled} onClick={() => onSelect(item.ordinal)}>打开这一段原文</button>
    </article>)}
    {results?.total_matches === 0 && <p>没有找到这些词。可尝试原文中的短词，或直接按段浏览。</p>}
    <form onSubmit={(event) => { event.preventDefault(); if (!disabled && Number.isInteger(page) && page >= 1 && page <= segments) onSelect(page - 1); }}>
      <label>直接打开段落（共{segments}段）<input type="number" min={1} max={segments} step={1}
        value={page} disabled={disabled} onChange={(event) => setPage(Number(event.target.value))} /></label>
      <button disabled={disabled || !Number.isInteger(page) || page < 1 || page > segments}>查看原文</button>
    </form>
  </section>;
}
