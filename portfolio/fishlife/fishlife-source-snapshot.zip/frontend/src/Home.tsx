import { useState, type FormEvent } from "react";
import { api, errorText, type Character } from "./api";
import { Notice, Portrait } from "./components";
import { useModelMode } from "./Mode";
import { defaultPersona, defaultInterests, personaText } from "./persona";
export function Home({
  character,
  onCreated,
  onChat,
}: {
  character: Character | null;
  onCreated: (c: Character) => void;
  onChat: () => void;
}) {
  const mode = useModelMode();
  const [name, setName] = useState("小鱼");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  async function create(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      onCreated(
        await api<Character>("/characters", "POST", {
          name,
          core_persona: defaultPersona,
          interests: defaultInterests,
        }),
      );
    } catch (e) {
      setError(errorText(e));
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <section className="intro">
        <p className="eyebrow">PROJECT FISHLIFE / YOUR COMPANION</p>
        <h1>
          {character
            ? `今天，也和${character.name}一起。`
            : "一个持续的故事，\n从这里开始。"}
        </h1>
        <p>
          共同经历会留下来源，记忆由你掌握。
          <br />
          不用急着开始宏大的冒险，先聊聊今天。
        </p>
      </section>
      <section className="welcome">
        <Portrait />
        <div>
          <span className="tag">
            {character ? "数字伙伴 · M5" : "尚未创建角色"}
          </span>
          <h2>
            {character ? `${character.name}的空间` : "给你的伙伴一个名字。"}
          </h2>
          {character ? (
            <>
              <p>聊天、共同记录，以及可以修正的长期记忆，已经有了归处。</p>
              <p>{personaText(character.core_persona.identity)}</p>
              <p>性格：{Array.isArray(character.core_persona.traits) ? character.core_persona.traits.filter((v) => typeof v === "string").join("、") : "尚未设置"}</p>
              <p>兴趣：{character.interests.join("、") || "慢慢探索中"}</p>
              <details><summary>看看她的角色背景</summary><p>{personaText(character.core_persona.background) || "尚未设置"}</p></details>
              <button className="primary" onClick={onChat}>
                开始对话 ↗
              </button>
            </>
          ) : (
            <form onSubmit={create} className="inline-form">
              <input
                aria-label="角色名字"
                value={name}
                onChange={(e) => setName(e.target.value)}
                maxLength={80}
                required
              />
              <button className="primary" disabled={busy}>
                {busy ? "正在创建…" : "创建伙伴"}
              </button>
            </form>
          )}
          <div className="safe">
            <span />
            站内活动默认暂停 <span />
            站内分享默认关闭
          </div>
          {error && <Notice error>{error}</Notice>}
        </div>
      </section>
      <section className="status-grid">
        <article>
          <p className="eyebrow">会记得，也能忘记</p>
          <h3>你的记忆，由你决定</h3>
          <p>
            每条记忆都能查看来源。发现偏差可以修正，不想保留的内容可以连同原始来源一起清除。
          </p>
        </article>
        <article>
          <p className="eyebrow">
            {mode === "mock"
              ? "模拟模型 · 无 API 费用"
              : mode === "unknown" ? "正在确认模型状态" : "真实模型 · 受预算限制"}
          </p>
          <h3>先验证连续性</h3>
          <p>
            {mode === "mock"
              ? "当前回复用于验证记忆流程，不等同真实大模型。试着说“我喜欢绿茶”，再新建会话询问。"
              : mode === "unknown" ? "尚未取得模型配置，暂不作免费或模拟模式的判断。"
              : "模型会读取相关来源记忆。涉及外部世界的说法仍需证据，生成文字不等于执行行动。"}
          </p>
        </article>
      </section>
    </>
  );
}
