import { useEffect, useRef, useState, type FormEvent } from "react";
import { api, errorText } from "./api";
import { Notice } from "./components";
import { useWaitingSeconds } from "./useWaitingSeconds";

type Source = { ordinal: number; content: string; source_hash: string };
type Answer = { answer: string; grounded: boolean; quotes: string[];
  book_id: string; ordinal: number; source_hash: string };
type Progress = { status: string; error_code?: string | null; answer: Answer | null };
type Previous = { task_id: string; status: string; error_code?: string | null; question: string; source_hash: string };
const pending = (status: string) => ["queued", "running", "retry_wait"].includes(status);

export function ReadingQuestion({ bookId, source, disabled }: {
  bookId: string; source: Source; disabled: boolean;
}) {
  const [question, setQuestion] = useState("");
  const [consent, setConsent] = useState(false);
  const [sending, setSending] = useState(false);
  const [attempted, setAttempted] = useState(false);
  const [job, setJob] = useState("");
  const [progress, setProgress] = useState<Progress | null>(null);
  const [error, setError] = useState("");
  const [history, setHistory] = useState<Previous[]>([]);
  const [loading, setLoading] = useState(true);
  const alive = useRef(true), locked = useRef(false), key = useRef(crypto.randomUUID());
  const base = `/books/${bookId}/questions`;
  const waitingSeconds = useWaitingSeconds(!!job && (!progress || pending(progress.status)), job);
  useEffect(() => {
    alive.current = true;
    return () => { alive.current = false; };
  }, []);
  useEffect(() => {
    const controller = new AbortController();
    void api<{items: Previous[]}>(`${base}?ordinal=${source.ordinal}`, "GET", undefined, undefined, controller.signal)
      .then((value) => {
        if (!alive.current || controller.signal.aborted) return;
        const items = value.items.filter((item) => item.source_hash === source.source_hash);
        setHistory(items); setLoading(false);
        const latest = items[0];
        if (latest) {
          setQuestion(latest.question); setJob(latest.task_id); setAttempted(true);
          // Fetch the validated answer even when this task has already finished.
          setProgress(null);
        }
      }).catch((e) => {
        if (alive.current && !controller.signal.aborted) setError(errorText(e) + "；尚未确认历史请求，请收起原文再打开重试查询。");
      });
    return () => controller.abort();
  }, [base, source.ordinal, source.source_hash]);
  useEffect(() => {
    if (!job || (progress && !pending(progress.status))) return;
    const controller = new AbortController();
    let active = false;
    async function refresh() {
      if (active) return;
      active = true;
      try {
        const value = await api<Progress>(`${base}/${job}`, "GET", undefined, undefined, controller.signal);
        if (alive.current && !controller.signal.aborted) { setProgress(value); setError(""); }
      } catch (e) {
        if (alive.current && !controller.signal.aborted) setError(errorText(e));
      } finally { active = false; }
    }
    void refresh();
    const timer = window.setInterval(() => void refresh(), 2000);
    return () => { controller.abort(); window.clearInterval(timer); };
  }, [job, progress?.status, base]);

  async function submit(event: FormEvent) {
    event.preventDefault();
    if (locked.current || loading || !consent || disabled || !question.trim() || job) return;
    locked.current = true; setSending(true); setAttempted(true); setError("");
    try {
      const value = await api<{ reply_job_id: string }>(base, "POST", {
        ordinal: source.ordinal, source_hash: source.source_hash, question,
        acknowledgement: "允许将所选原文和问题发送给Qoder",
      }, { "Idempotency-Key": key.current });
      if (alive.current) {
        setJob(value.reply_job_id); setProgress({ status: "queued", answer: null }); setConsent(false);
      }
    } catch (e) { if (alive.current) setError(errorText(e)); }
    finally { locked.current = false; if (alive.current) setSending(false); }
  }
  const answer = progress?.answer;
  const matched = answer && answer.book_id === bookId && answer.ordinal === source.ordinal &&
    answer.source_hash === source.source_hash && answer.quotes.every((q) => source.content.includes(q));
  return <section className="settings-form">
    <h3>问问她，这一段讲了什么</h3>
    <p>只发送上方第 {source.ordinal + 1} 段原文和本次问题，不发送整本书。
      这是云端模型解读，可能出错；不会把书中内容记成你的个人经历。</p>
    {error && <Notice error>{error} 网络异常不代表请求未受理，请勿换请求重复发送。</Notice>}
    {loading && <p>正在查找这一段已有的问答…</p>}
    {history.length > 0 && <label>本段已有问答（最多20条）<select value={job}
      disabled={sending || disabled} onChange={(e) => {
        const previous = history.find((item) => item.task_id === e.target.value);
        if (!previous) return;
        setJob(previous.task_id); setQuestion(previous.question); setProgress(null);
        setAttempted(true); setConsent(false); setError("");
      }}><option value="" disabled>选择已有问题</option>
      {!history.some((item) => item.task_id === job) && job && <option value={job}>当前问题</option>}
      {history.map((item) => <option key={item.task_id} value={item.task_id}>{item.question}</option>)}
    </select></label>}
    <form onSubmit={(e) => void submit(e)}>
      <label>你的问题<textarea rows={3} maxLength={1500} required value={question}
        disabled={loading || attempted || sending || !!job || disabled} onChange={(e) => {
          setQuestion(e.target.value); setConsent(false); key.current = crypto.randomUUID();
        }} /></label>
      <label className="planning-consent"><input type="checkbox" checked={consent}
        disabled={sending || !!job || disabled} onChange={(e) => setConsent(e.target.checked)} />
        允许将所选原文和问题发送给 Qoder。本次调用使用现有费用预留，未知账单继续保留。</label>
      <button className="primary" disabled={loading || sending || !!job || disabled || !consent || !question.trim()}>
        {sending ? "正在提交…" : attempted && !job ? "用原请求标识重新确认受理状态" : "发送这一段并提问"}</button>
    </form>
    {progress && pending(progress.status) && <Notice>
      {progress.status === "queued" ? "问题已保存，等待后台处理。" : "后台正在处理，尚未完成回答。"}
      本页已等待 {waitingSeconds} 秒。可以继续查看原文，不需要重复发送。
    </Notice>}
    {progress && !pending(progress.status) && progress.status !== "succeeded" &&
      <Notice error>本次未得到可展示的回答：{progress.error_code || progress.status}。不会自动重发模型请求。</Notice>}
    {answer && !matched && <Notice error>回答来源不匹配，已隐藏内容。</Notice>}
    {matched && <article><span className="tag">{answer.grounded ? "附有逐字原文引文" : "原文依据不足"}</span>
      <p className="life-source">{answer.answer}</p>
      {answer.quotes.map((quote, i) => <blockquote key={i}>{quote}</blockquote>)}
      <small>出处：第 {source.ordinal + 1} 段 · SHA256 {source.source_hash}。
        引文存在不代表解释一定正确，请对照上方原文。</small>
    </article>}
    {job && progress && !pending(progress.status) && <button type="button" disabled={disabled} onClick={() => {
      setJob(""); setProgress(null); setQuestion(""); setConsent(false); setAttempted(false); setError(""); key.current = crypto.randomUUID();
    }}>开始另一个问题（需要重新授权）</button>}
  </section>;
}
