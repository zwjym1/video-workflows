import { useEffect, useState, useRef } from "react";
import {
  localVoices,
  presentation,
  createPlaybackGuard,
} from "./presentation_events";
import { Portrait, Notice } from "./components";
export function Presentation({characterName}: {characterName?: string}) {
  const playback = useRef(createPlaybackGuard());
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]),
    [voice, setVoice] = useState(""),
    [text, setText] = useState(
      characterName ? `你好，我是${characterName}。每次行动，都留下可以核对的记录。`
        : "你好，这里是本地语音与形象预览。每次行动，都留下可以核对的记录。",
    ),
    [state, setState] = useState(presentation("idle")),
    [error, setError] = useState("");
  useEffect(() => {
    if (!("speechSynthesis" in window)) return;
    const synth = window.speechSynthesis;
    const load = () => {
      const local = localVoices(synth.getVoices());
      setVoices(local);
      setVoice((old) =>
        local.some((v) => v.voiceURI === old)
          ? old
          : (local[0]?.voiceURI ?? ""),
      );
    };
    const stop = () => {
      playback.current.invalidate();
      synth.cancel();
      setState(presentation("stopped"));
    };
    load();
    synth.addEventListener("voiceschanged", load);
    window.addEventListener("fishlife:safety-changed", stop);
    return () => {
      playback.current.invalidate();
      synth.cancel();
      synth.removeEventListener("voiceschanged", load);
      window.removeEventListener("fishlife:safety-changed", stop);
    };
  }, []);
  function speak() {
    setError("");
    const selected = voices.find(
      (v) => v.voiceURI === voice && v.localService === true,
    );
    if (!selected) {
      setError("当前没有可用的设备本地声音，未发送到云语音。");
      return;
    }
    const synth = window.speechSynthesis;
    const current = playback.current.next();
    synth.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.voice = selected;
    utterance.lang = selected.lang;
    utterance.onstart = () => {
      if (current()) setState(presentation("speaking"));
    };
    utterance.onend = () => {
      if (current()) setState(presentation("idle"));
    };
    utterance.onerror = () => {
      if (!current()) return;
      setState(presentation("stopped"));
      setError("设备语音没有成功播放，请检查声音或浏览器支持。");
    };
    synth.speak(utterance);
  }
  return (
    <>
      <div className="page-heading">
        <div>
          <p className="eyebrow">VOICE & PRESENTATION</p>
          <h1>听见它，也看见它</h1>
        </div>
      </div>
      <Notice>
        语音只在你点击时播放，且只使用浏览器标记为本地服务的声音。未配置服务器语音，不能导出音频文件；动画仅表达界面状态，不代表真实情绪或任务完成。
      </Notice>
      <div className={`presentation-avatar ${state.kind}`}>
        <Portrait />
      </div>
      <form
        className="settings-form"
        onSubmit={(e) => {
          e.preventDefault();
          speak();
        }}
      >
        <label>
          朗读文字
          <textarea
            rows={4}
            value={text}
            maxLength={2000}
            onChange={(e) => setText(e.target.value)}
          />
        </label>
        <label>
          设备本地声音
          <select value={voice} onChange={(e) => setVoice(e.target.value)}>
            <option value="">
              {voices.length ? "选择声音" : "当前未发现本地声音"}
            </option>
            {voices.map((v) => (
              <option key={v.voiceURI} value={v.voiceURI}>
                {v.name} · {v.lang}
              </option>
            ))}
          </select>
        </label>
        {error && <Notice error>{error}</Notice>}
        <div className="card-actions">
          <button className="primary" disabled={!voice || !text.trim()}>
            播放本地语音
          </button>
          <button
            type="button"
            onClick={() => {
              playback.current.invalidate();
              window.speechSynthesis?.cancel();
              setState(presentation("stopped"));
            }}
          >
            停止播放
          </button>
        </div>
        <p>
          展示状态：
          {state.kind === "speaking"
            ? "设备正在朗读"
            : state.kind === "stopped"
              ? "已停止"
              : "安静待机"}
        </p>
      </form>
      <p className="muted">
        Live2D、3D与实时麦克风对话尚未接入。无本地声音时保留明确不可用状态，不生成假音频。
      </p>
    </>
  );
}
