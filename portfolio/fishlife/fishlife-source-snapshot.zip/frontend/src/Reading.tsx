import { useEffect, useRef, useState, type FormEvent } from "react";
import { api, errorText, when, type Character } from "./api";
import { Notice } from "./components";
import { decodeReadingFile, readingCharacterCount } from "./reading_text";
import { readReadingSnapshot } from "./reading_snapshot";
import { ReadingQuestion } from "./ReadingQuestion";
import { ReadingSearch } from "./ReadingSearch";

type Book = {
  id: string; title: string; status: string; cursor: number; verified_cursor: number | null;
  segment_count: number; source_valid: boolean; source_hash: string; total_chars: number;
  auto_enabled: boolean; interval_seconds: number; version: number;
  last_task?: { status: string; error_code?: string } | null;
};
type Note = { id: string; ordinal: number; source_hash: string; excerpts: string[]; created_at: string };
type NotePage = { items: Note[]; next_after: number | null };
type Source = { ordinal: number; start_offset: number; end_offset: number; content: string; source_hash: string };
type Shelf = { items: Book[]; capability_enabled: boolean };

export function Reading({ character }: { character: Character }) {
  const [shelf, setShelf] = useState<Shelf | null>(null);
  const [selected, setSelected] = useState("");
  const [book, setBook] = useState<Book | null>(null);
  const [notes, setNotes] = useState<Note[]>([]);
  const [after, setAfter] = useState<number | null>(null);
  const [source, setSource] = useState<Source | null>(null);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [automatic, setAutomatic] = useState(false);
  const [minutes, setMinutes] = useState(30);
  const [enabled, setEnabled] = useState(false);
  const [busy, setBusy] = useState(false);
  const [paging, setPaging] = useState(false);
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");
  const [deleting, setDeleting] = useState(false);
  const mounted = useRef(true), writing = useRef(false), pagingLock = useRef(false);
  const generation = useRef(0), shelfTicket = useRef(0), detailTicket = useRef(0);
  const selection = useRef(""), fileTicket = useRef(0), draftDirty = useRef(false);
  const importKey = useRef(crypto.randomUUID());
  const sourceTicket = useRef(0);
  const base = `/characters/${character.id}`;

  async function loadShelf(signal?: AbortSignal) {
    const ticket = ++shelfTicket.current, epoch = generation.current;
    const [value, autonomy] = await Promise.all([
      api<Shelf>(base + "/books", "GET", undefined, undefined, signal),
      api<{ enabled: boolean }>(base + "/autonomy", "GET", undefined, undefined, signal),
    ]);
    if (!mounted.current || signal?.aborted || epoch !== generation.current || ticket !== shelfTicket.current) return null;
    setShelf(value); setEnabled(autonomy.enabled);
    return value;
  }

  function choose(id: string) {
    generation.current++; selection.current = id; draftDirty.current = false;
    setSelected(id); setBook(null); setNotes([]); setAfter(null); setSource(null); setDeleting(false);
    pagingLock.current = false; setPaging(false);
  }

  async function loadBook(id: string, signal?: AbortSignal) {
    if (!id || writing.current) return;
    const ticket = ++detailTicket.current, epoch = generation.current;
    const current = () => mounted.current && !signal?.aborted && !writing.current &&
      epoch === generation.current && ticket === detailTicket.current && selection.current === id;
    const snapshot = await readReadingSnapshot(
      () => api<Book>(`/books/${id}`, "GET", undefined, undefined, signal),
      () => api<NotePage>(`/books/${id}/notes`, "GET", undefined, undefined, signal),
      {items: [], next_after: null} as NotePage,
    );
    if (!current()) return;
    const value = snapshot.book;
    setBook(value);
    setShelf((old) => old ? { ...old, items: old.items.map((b) => b.id === id ? value : b) } : old);
    if (!draftDirty.current) { setAutomatic(value.auto_enabled); setMinutes(value.interval_seconds / 60); }
    if (!value.source_valid) setSource(null);
    setNotes(snapshot.notes.items); setAfter(snapshot.notes.next_after);
  }

  useEffect(() => {
    mounted.current = true;
    const controller = new AbortController();
    void loadShelf(controller.signal).then((value) => {
      if (value && !selection.current && value.items[0]) choose(value.items[0].id);
    }).catch((e) => { if (!controller.signal.aborted) setError(errorText(e)); });
    const stopped = () => {
      generation.current++; setSource(null); setNotes([]); setAfter(null);
      void loadShelf(controller.signal).then(() => loadBook(selection.current, controller.signal))
        .catch((e) => { if (!controller.signal.aborted) setError(errorText(e)); });
    };
    window.addEventListener("fishlife:safety-changed", stopped);
    return () => {
      mounted.current = false; generation.current++; fileTicket.current++; controller.abort();
      window.removeEventListener("fishlife:safety-changed", stopped);
    };
  }, [character.id]);

  useEffect(() => {
    const controller = new AbortController();
    void loadBook(selected, controller.signal).catch((e) => {
      if (!controller.signal.aborted) setError(errorText(e));
    });
    return () => controller.abort();
  }, [selected]);

  useEffect(() => {
    const pending = ["queued", "running", "retry_wait"].includes(book?.last_task?.status ?? "");
    if (!selected || (!book?.auto_enabled && !pending)) return;
    const controller = new AbortController();
    const timer = window.setInterval(() => {
      if (!writing.current && !pagingLock.current) void loadBook(selected, controller.signal)
        .catch((e) => { if (!controller.signal.aborted) setError(errorText(e)); });
    }, 10000);
    return () => { clearInterval(timer); controller.abort(); };
  }, [selected, book?.auto_enabled, book?.last_task?.status]);

  async function act(operation: () => Promise<string | void>) {
    if (writing.current) return;
    writing.current = true; generation.current++; fileTicket.current++;
    setBusy(true); setError(""); setInfo("");
    setSource(null); setNotes([]); setAfter(null); pagingLock.current = false; setPaging(false);
    let target = selection.current;
    try {
      const result = await operation();
      if (!mounted.current) return;
      if (typeof result === "string") target = result;
    } catch (e) { if (mounted.current) setError(errorText(e)); }
    finally {
      writing.current = false;
      if (mounted.current) {
        draftDirty.current = false;
        try {
          const value = await loadShelf();
          if (value) {
            if (!value.items.some((b) => b.id === target)) target = value.items[0]?.id ?? "";
            if (selection.current !== target) choose(target);
            else await loadBook(target);
          }
        } catch (e) { if (mounted.current) setError(errorText(e)); }
        if (mounted.current) setBusy(false);
      }
    }
  }

  async function pickFile(file: File | undefined) {
    if (!file) return;
    const ticket = ++fileTicket.current;
    setError("");
    try {
      if (file.size > 1024 * 1024) throw new Error("文件不能超过1 MiB。");
      const value = decodeReadingFile(file.name, new Uint8Array(await file.arrayBuffer()));
      if (!mounted.current || ticket !== fileTicket.current) return;
      setContent(value); setTitle(Array.from(file.name.replace(/\.(txt|md)$/i, "")).slice(0, 120).join(""));
      importKey.current = crypto.randomUUID();
    } catch (e) { if (mounted.current && ticket === fileTicket.current) setError(errorText(e)); }
  }

  function submit(event: FormEvent) {
    event.preventDefault();
    void act(async () => {
      const value = await api<Book>(base + "/books", "POST", { title, content },
        { "Idempotency-Key": importKey.current });
      if (mounted.current) { setContent(""); setTitle(""); setInfo("已保存到本地书架，尚未处理正文。"); }
      importKey.current = crypto.randomUUID();
      return value.id;
    });
  }

  async function showSource(ordinal: number) {
    const id = selection.current, epoch = generation.current;
    const ticket = ++sourceTicket.current;
    try {
      const value = await api<Source>(`/books/${id}/segments/${ordinal}`);
      if (mounted.current && epoch === generation.current && selection.current === id && ticket === sourceTicket.current) setSource(value);
    } catch (e) { if (mounted.current && epoch === generation.current) setError(errorText(e)); }
  }

  async function moreNotes() {
    if (after === null || pagingLock.current) return;
    pagingLock.current = true; setPaging(true);
    detailTicket.current++;
    const id = selection.current, epoch = generation.current;
    try {
      const value = await api<NotePage>(`/books/${id}/notes?after=${after}`);
      if (mounted.current && epoch === generation.current && selection.current === id) {
        setNotes((old) => [...old, ...value.items.filter((n) => !old.some((o) => o.id === n.id))]);
        setAfter(value.next_after);
      }
    } catch (e) { if (mounted.current && epoch === generation.current) setError(errorText(e)); }
    finally { if (mounted.current && epoch === generation.current) { pagingLock.current = false; setPaging(false); } }
  }

  const count = readingCharacterCount(content);
  return <>
    <div className="page-heading"><div><p className="eyebrow">LOCAL READING WITH SOURCES</p>
      <h1>读到哪里，下次接着来</h1></div>
      <button disabled={busy} onClick={() => void act(async () => {})}>刷新进度</button></div>
    <Notice>日程阅读在本机分段处理纯文本，保留原文摘录和进度，不调用云端模型。
      选中原文后可单独授权向云端提问；每次只发送所选的一段。
      处理进度不代表理解程度；不生成个人事实记忆，也不执行书中的指令。</Notice>
    {error && <Notice error>{error}</Notice>}{info && <Notice>{info}</Notice>}
    {shelf && !shelf.capability_enabled && <Notice>当前服务尚未开放本地阅读。</Notice>}
    <div className="life-columns">
      <form className="settings-form" onSubmit={submit}><h2>放一本资料到书架</h2>
        <label>选择 UTF-8 文本文件<input type="file" accept=".txt,.md,text/plain,text/markdown"
          disabled={busy || !shelf?.capability_enabled}
          onChange={(e) => { const file = e.target.files?.[0]; e.target.value = ""; void pickFile(file); }} /></label>
        <label>资料标题<input value={title} maxLength={120} required disabled={busy}
          onChange={(e) => { setTitle(e.target.value); importKey.current = crypto.randomUUID(); }} /></label>
        <label>正文（也可以直接粘贴）<textarea rows={8} value={content} required disabled={busy}
          onChange={(e) => { fileTicket.current++; setContent(e.target.value); importKey.current = crypto.randomUUID(); }} /></label>
        <p className="muted">{count} / 200000 字符；文件≤1 MiB，最多100段，每段≤2500字符。
          每个角色最多20份资料。PDF、EPUB及扫描件尚不支持。</p>
        <button className="primary" disabled={busy || !shelf?.capability_enabled || !title.trim() || !content.trim() || count > 200000}>保存到本地书架</button>
      </form>
      <section className="settings-form"><h2>{character.name}的书架</h2>
        {!shelf?.items.length && <p className="empty-state">书架还是空的。选择你愿意保存在这里的文本。</p>}
        {shelf?.items.map((value) => <button key={value.id} disabled={busy}
          aria-pressed={selected === value.id} onClick={() => choose(value.id)}>
          {value.title} · {value.source_valid ? `${value.verified_cursor}/${value.segment_count} 段` : "来源待检查"}
        </button>)}
        <p>{enabled ? "站内活动已启用" : "站内活动已暂停，不会推进阅读。"}</p>
        {!enabled && <button disabled={busy || !shelf?.capability_enabled} onClick={() => void act(async () => {
          await api(base + "/autonomy", "PATCH", { enabled: true });
        })}>启用站内活动（适用全部角色）</button>}
      </section>
    </div>
    {book && <section className="reading-detail">
      <div className="page-heading"><div><h2>{book.title}</h2>
        <p>{book.source_valid ? `已核验处理 ${book.verified_cursor} / ${book.segment_count} 段` : "来源或证据失效，停止推进"}
          {book.source_valid && book.status === "completed" && " · 本地处理已完成"}</p></div>
        <button className="danger" disabled={busy} onClick={() => setDeleting(true)}>清除资料与笔记</button></div>
      {book.last_task?.error_code && <Notice error>上次任务：{book.last_task.error_code}，没有将失败计为已完成。</Notice>}
      <div className="card-actions">
        <button disabled={busy || !enabled || !book.source_valid || book.status === "completed"}
          onClick={() => void act(async () => {
            const result = await api<{ status: string }>(`/books/${book.id}/next`, "POST",
              { expected_version: book.version }, { "Idempotency-Key": crypto.randomUUID() });
            setInfo(result.status === "quiet" ? "已处理到末尾，保持安静。" :
              ["failed", "unknown", "cancelled"].includes(result.status)
                ? "现有任务已失败或停止，没有创建新的任务。请查看错误记录。"
                : "已受理，后台会核验下一段；可稍后刷新。");
          })}>处理下一段</button>
        <button disabled={busy || !book.source_valid || book.cursor >= book.segment_count}
          onClick={() => void showSource(book.cursor)}>查看下一段原文</button>
      </div>
      <form className="settings-form planning-policy" onSubmit={(e) => { e.preventDefault(); void act(async () => {
        await api(`/books/${book.id}`, "PATCH", { auto_enabled: automatic,
          interval_seconds: minutes * 60, expected_version: book.version });
        setInfo("阅读日程已保存。每轮只处理一段，不积压补跑。");
      }); }}>
        <h3>定时接着读</h3>
        <p>当前：{book.auto_enabled ? "此书已启用自动处理" : "此书自动处理关闭"}；受站内活动主开关约束。</p>
        <label className="planning-consent"><input type="checkbox" checked={automatic} disabled={busy}
          onChange={(e) => { draftDirty.current = true; setAutomatic(e.target.checked); }} />允许在本机定时处理下一段</label>
        <label>间隔（分钟，1–1440）<input type="number" min={1} max={1440} step={1} value={minutes}
          disabled={busy} onChange={(e) => { draftDirty.current = true; setMinutes(Number(e.target.value)); }} /></label>
        <button disabled={busy || !Number.isInteger(minutes) || minutes < 1 || minutes > 1440 ||
          (automatic && (!enabled || !book.source_valid || book.status === "completed"))}>保存阅读日程</button>
      </form>
      <ReadingSearch key={`${book.id}:${book.source_hash}`} bookId={book.id} segments={book.segment_count}
        disabled={busy || deleting || !book.source_valid} onSelect={(ordinal) => void showSource(ordinal)} />
      {source && <article className="memory-card"><h3>第 {source.ordinal + 1} 段原文</h3>
        <p className="life-source">{source.content}</p><small>字符范围 {source.start_offset}–{source.end_offset} · SHA256 {source.source_hash}</small>
        <div className="card-actions">
          <button disabled={busy || source.ordinal === 0} onClick={() => void showSource(source.ordinal - 1)}>上一段</button>
          <button disabled={busy || source.ordinal + 1 >= book.segment_count} onClick={() => void showSource(source.ordinal + 1)}>下一段</button>
          <button onClick={() => setSource(null)}>收起原文</button>
        </div></article>}
      {source && <ReadingQuestion key={`${book.id}:${source.ordinal}:${source.source_hash}`}
        bookId={book.id} source={source} disabled={busy || deleting || !book.source_valid} />}
      <h2>有来源的阅读摘录</h2><p className="muted">以下为本地逐行摘录，未进行模型解读。</p>
      <div className="memory-grid">{notes.map((note) => <article className="memory-card" key={note.id}>
        <span className="tag">第 {note.ordinal + 1} 段 · {when(note.created_at)}</span>
        {note.excerpts.map((quote, i) => <blockquote key={i}>{quote}</blockquote>)}
        <button disabled={busy} onClick={() => void showSource(note.ordinal)}>核对原文来源</button>
      </article>)}</div>
      {!notes.length && <p className="empty-state">尚无可核验摘录。导入和排队本身不算处理完成。</p>}
      {after !== null && <button disabled={busy || paging} onClick={() => void moreNotes()}>加载更多摘录</button>}
    </section>}
    {deleting && book && <div className="modal-scrim"><section className="modal" role="dialog" aria-modal="true" aria-label="清除阅读资料">
      <h2>清除这份资料？</h2><p>会清除标题、所有段落、阅读摘录和派生文本，并取消待处理任务。历史备份不在本次清理范围内，页面无法撤销。</p>
      <div className="card-actions"><button disabled={busy} onClick={() => setDeleting(false)}>保留资料</button>
        <button className="danger" disabled={busy} onClick={() => void act(async () => {
          const removed = book.id;
          await api(`/books/${removed}`, "DELETE");
          if (mounted.current) {
            choose("");
            setShelf((old) => old ? { ...old, items: old.items.filter((value) => value.id !== removed) } : old);
            setInfo("资料与摘录已清除。");
          }
          return "";
        })}>确认清除资料与摘录</button></div></section></div>}
  </>;
}
