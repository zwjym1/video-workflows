/** Fetch all evidence before publishing terminal status, so effects cannot abort half an update. */
export async function readReadingSnapshot<B extends { source_valid: boolean }, N>(
  readBook: () => Promise<B>, readNotes: () => Promise<N>, emptyNotes: N,
): Promise<{ book: B; notes: N }> {
  const book = await readBook();
  const notes = book.source_valid ? await readNotes() : emptyNotes;
  return { book, notes };
}
