import { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  api,
  list,
  setCsrf,
  errorText,
  type Auth,
  type Character,
  type User,
} from "./api";
import { Login, Notice } from "./components";
import { Home } from "./Home";
import { Chat } from "./Chat";
import { Memories } from "./Memories";
import { ModeContext } from "./Mode";
import { Timeline, SettingsPage, StatusPage } from "./OtherPages";
import { Life } from "./Life";
import { Tools } from "./Tools";
import { ErrorBoundary } from "./ErrorBoundary";
import { Companion, GlobalStop } from "./Companion";
import { World } from "./World";
import { Presentation } from "./Presentation";
import { WebReader } from "./WebReader";
import { Reading } from "./Reading";
import "./style.css";

type Page =
  | "home"
  | "chat"
  | "memories"
  | "timeline"
  | "settings"
  | "status"
  | "life"
  | "journals"
  | "tools"
  | "companion"
  | "world"
  | "presentation"
  | "web"
  | "reading";
const navigation: { id: Page; title: string; mark: string }[] = [
  { id: "home", title: "角色主页", mark: "⌂" },
  { id: "chat", title: "对话", mark: "↗" },
  { id: "memories", title: "记忆", mark: "◇" },
  { id: "timeline", title: "共同记录", mark: "◷" },
  { id: "life", title: "目标与活动", mark: "☷" },
  { id: "journals", title: "日记", mark: "▤" },
  { id: "tools", title: "工具与安全", mark: "⬡" },
  { id: "web", title: "只读网页资料", mark: "◎" },
  { id: "reading", title: "书架与阅读", mark: "▥" },
  { id: "companion", title: "陪伴与分享", mark: "♡" },
  { id: "world", title: "伙伴与交流", mark: "♧" },
  { id: "presentation", title: "语音与形象", mark: "♫" },
  { id: "settings", title: "角色设定", mark: "⚙" },
  { id: "status", title: "运行与费用", mark: "◌" },
];

function App() {
  const [user, setUser] = useState<User | null>(null);
  const [boot, setBoot] = useState(true);
  const [character, setCharacter] = useState<Character | null>(null);
  const [characters, setCharacters] = useState<Character[]>([]);
  const [page, setPage] = useState<Page>("home");
  const [error, setError] = useState("");
  const [mode, setMode] = useState("unknown");
  useEffect(() => {
    const c = new AbortController();
    const expired = () => {
      setUser(null);
      setCharacter(null);
      setCharacters([]);
      setMode("unknown");
      setCsrf("");
      setPage("home");
    };
    window.addEventListener("fishlife:unauthorized", expired);
    void api<Auth>("/auth/me", "GET", undefined, undefined, c.signal)
      .then((a) => {
        setCsrf(a.csrf_token);
        setUser(a.user);
      })
      .catch((e) => {
        if (!c.signal.aborted && !(e?.status === 401)) setError(errorText(e));
      })
      .finally(() => {
        if (!c.signal.aborted) setBoot(false);
      });
    return () => {
      c.abort();
      window.removeEventListener("fishlife:unauthorized", expired);
    };
  }, []);
  useEffect(() => {
    if (!user) return;
    const c = new AbortController();
    void list<Character>("/characters", c.signal)
      .then((r) => {
        setCharacters(r.items);
        setCharacter(r.items[0] ?? null);
      })
      .catch((e) => {
        if (!c.signal.aborted) setError(errorText(e));
      });
    void api<{ model_provider: string }>(
      "/runtime/status",
      "GET",
      undefined,
      undefined,
      c.signal,
    )
      .then((r) => setMode(r.model_provider))
      .catch((e) => {
        if (!c.signal.aborted) setError(errorText(e));
      });
    return () => c.abort();
  }, [user?.id]);
  async function logout() {
    try {
      await api("/auth/logout", "POST", {});
      setCsrf("");
      setUser(null);
      setCharacter(null);
      setCharacters([]);
      setPage("home");
    } catch (e) {
      setError(errorText(e));
    }
  }
  if (boot)
    return <div className="boot-state">正在打开你的 FishLife 空间…</div>;
  if (!user)
    return (
      <>
        {error && <Notice error>{error}</Notice>}
        <Login
          onLogin={(a) => {
            setCsrf(a.csrf_token);
            setUser(a.user);
            setError("");
          }}
        />
      </>
    );
  return (
    <ModeContext.Provider value={mode}>
      <div className="shell">
        <aside>
          <a
            className="brand"
            href="/"
            onClick={(e) => {
              e.preventDefault();
              setPage("home");
            }}
          >
            ◌{" "}
            <span>
              FishLife<small>个人电子生命</small>
            </span>
          </a>
          <div className="nav-label">你的空间</div>
          <nav className="main-nav">
            {navigation.map((n) => (
              <button
                className={page === n.id ? "nav-current" : ""}
                key={n.id}
                onClick={() => setPage(n.id)}
              >
                {n.mark}　{n.title}
              </button>
            ))}
          </nav>
          <div className="sidebar-note">
            M5 · 独立角色与扩展
            <br />
            {user.username}
            <br />
            <button onClick={logout}>退出登录</button>
          </div>
        </aside>
        <main>
          <header>
            <label className="character-picker">
              当前伙伴
              <select
                aria-label="切换角色"
                value={character?.id ?? ""}
                onChange={(e) => {
                  setCharacter(
                    characters.find((c) => c.id === e.target.value) ?? null,
                  );
                  setPage("home");
                }}
              >
                <option value="" disabled>
                  尚未创建角色
                </option>
                {characters.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </label>
            <span className="stage">
                M5 · {modelMode(mode)}
            </span>
          </header>
          <GlobalStop />
          {error && (
            <Notice error>
              {error}
              <button onClick={() => setError("")}>收起</button>
            </Notice>
          )}
          {page === "home" ? (
            <Home
              character={character}
              onCreated={(c) => {
                setCharacter(c);
                setCharacters((v) => [...v.filter((x) => x.id !== c.id), c]);
              }}
              onChat={() => setPage("chat")}
            />
          ) : page === "status" ? (
            <StatusPage />
          ) : page === "world" ? (
            <World
              key={character?.id ?? "empty"}
              character={character}
              characters={characters}
              onCreated={(c) => {
                setCharacters((v) => [...v, c]);
                setCharacter(c);
              }}
            />
          ) : page === "presentation" ? (
            <Presentation key={character?.id ?? "empty"} characterName={character?.name} />
          ) : !character ? (
            <Notice>
              先到角色主页创建你的伙伴。
              <button onClick={() => setPage("home")}>前往创建</button>
            </Notice>
          ) : page === "chat" ? (
            <Chat key={character.id} character={character} />
          ) : page === "memories" ? (
            <Memories key={character.id} character={character} />
          ) : page === "timeline" ? (
            <Timeline key={character.id} character={character} />
          ) : page === "life" || page === "journals" ? (
            <Life
              key={character.id}
              character={character}
              journalsOnly={page === "journals"}
              onCharacterChanged={(c) => {
                setCharacter(c);
                setCharacters((v) => v.map((x) => x.id === c.id ? c : x));
              }}
            />
          ) : page === "tools" ? (
            <Tools key={character.id} character={character} />
          ) : page === "web" ? (
            <WebReader key={character.id} character={character} />
          ) : page === "reading" ? (
            <Reading key={character.id} character={character} />
          ) : page === "companion" ? (
            <Companion key={character.id} character={character} />
          ) : (
            <SettingsPage
              key={character.id}
              character={character}
              onChanged={(c) => {
                setCharacter(c);
                setCharacters((v) => v.map((x) => (x.id === c.id ? c : x)));
              }}
            />
          )}
          <footer>
            连续的陪伴，建立在真实记录之上。<span>FishLife · M5</span>
          </footer>
        </main>
      </div>
    </ModeContext.Provider>
  );
}
createRoot(document.getElementById("root")!).render(
  <ErrorBoundary>
    <App />
  </ErrorBoundary>,
);
import { modelMode } from "./model_mode";
