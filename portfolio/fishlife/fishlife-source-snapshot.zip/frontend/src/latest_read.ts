/** Prevent earlier reads from restoring private data after a newer read or write. */
export function createLatestReadGate() {
  let version = 0;
  let blocked = false;
  return {
    begin: () => blocked ? null : ++version,
    current: (ticket: number) => !blocked && ticket === version,
    invalidate: () => { version++; },
    pause: () => { blocked = true; version++; },
    resume: () => { blocked = false; version++; },
  };
}
