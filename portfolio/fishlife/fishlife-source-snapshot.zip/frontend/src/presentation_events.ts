export type PresentationEvent = {
  kind: "idle" | "working" | "speaking" | "stopped";
  mood: string;
  gesture: string;
  audio_ref?: string;
  occurred_at: string;
  simulated: true;
};
export function createPlaybackGuard() {
  let generation = 0;
  return {
    next() {
      const current = ++generation;
      return () => current === generation;
    },
    invalidate() {
      generation++;
    },
  };
}
export function localVoices<T extends { localService: boolean; lang: string }>(
  voices: T[],
): T[] {
  return voices.filter((v) => v.localService === true);
}
export function presentation(
  kind: PresentationEvent["kind"],
): PresentationEvent {
  return {
    kind,
    mood: kind === "working" ? "focused" : "calm",
    gesture: kind === "speaking" ? "gentle_bob" : "rest",
    occurred_at: new Date().toISOString(),
    simulated: true,
  };
}
