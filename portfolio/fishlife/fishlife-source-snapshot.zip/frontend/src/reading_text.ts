export function readingCharacterCount(text: string): number {
  const normalized = (text.startsWith("\ufeff") ? text.slice(1) : text).replace(/\r\n/g, "\n");
  return Array.from(normalized).length;
}

export function decodeReadingFile(name: string, bytes: Uint8Array): string {
  if (!/\.(txt|md)$/i.test(name)) throw new Error("首版仅支持 UTF-8 的 .txt 和 .md 文件。");
  if (bytes.byteLength > 1024 * 1024) throw new Error("文件不能超过 1 MiB。");
  let text: string;
  try { text = new TextDecoder("utf-8", { fatal: true, ignoreBOM: true }).decode(bytes); }
  catch { throw new Error("文件不是有效 UTF-8，请先转换编码。"); }
  if (!text.trim() || text.includes("\0")) throw new Error("请选择包含正文的纯文本文件。");
  if (readingCharacterCount(text) > 200000) throw new Error("正文最多 20 万字符。");
  return text;
}
