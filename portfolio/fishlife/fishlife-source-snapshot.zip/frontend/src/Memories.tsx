import { useEffect, useRef, useState, type FormEvent } from "react";
import { api, list, errorText, when, type Character, type Memory } from "./api";
import { Notice } from "./components";
import { Autobiography } from "./Autobiography";
import { createLatestReadGate } from "./latest_read";

export function Memories({ character }: { character: Character }) {
  const [items, setItems] = useState<Memory[]>([]);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("active");
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");
  const [loading, setLoading] = useState(false);
  const [edit, setEdit] = useState<Memory | null>(null);
  const [content, setContent] = useState("");
  const [deleting, setDeleting] = useState<Memory | null>(null);
  const [busy, setBusy] = useState(false);
  const [expiring, setExpiring] = useState<Memory | null>(null);
  const [expiryDate, setExpiryDate] = useState("");
  const [noExpiry, setNoExpiry] = useState(false);
  const [nextCursor, setNextCursor] = useState<string | null>(null);
  const reads = useRef(createLatestReadGate());
  const lastRead = useRef<number | null>(null);
  const mounted = useRef(false);
  const committedSearch = useRef({query: "", filter: "active"});
  function beginWrite() {
    reads.current.pause(); setItems([]); setNextCursor(null); setLoading(false);
  }
  async function reloadAfterWrite() {
    if (!mounted.current) return;
    reads.current.resume();
    await load();
  }
  function writeError(e: unknown) {
    if (!mounted.current) return;
    reads.current.resume(); setError(errorText(e));
  }
  async function load(cursor?: string) {
    const ticket = reads.current.begin();
    if (ticket === null || !mounted.current) return;
    lastRead.current = ticket;
    if (!cursor) { committedSearch.current = {query, filter}; setItems([]); setNextCursor(null); }
    const search = committedSearch.current;
    setLoading(true);
    setError("");
    try {
      const r = await list<Memory>(
        `/characters/${character.id}/memories?q=${encodeURIComponent(search.query)}&status=${search.filter}${cursor ? `&cursor=${encodeURIComponent(cursor)}` : ""}`,
      );
      if (!reads.current.current(ticket)) return;
      setItems((old) => cursor ? [...old, ...r.items.filter((x) => !old.some((y) => x.id === y.id))] : r.items);
      setNextCursor(r.next_cursor ?? null);
    } catch (e) {
      if (reads.current.current(ticket)) setError(errorText(e));
    } finally {
      if (reads.current.current(ticket)) setLoading(false);
    }
  }
  useEffect(() => {
    mounted.current = true;
    reads.current.resume();
    void load();
    return () => { mounted.current = false; reads.current.invalidate(); };
  }, [character.id, filter]);
  async function save(e: FormEvent) {
    e.preventDefault();
    if (!edit) return;
    beginWrite();
    setBusy(true);
    setError("");
    try {
      await api(
        `/memories/${edit.id}`,
        "PATCH",
        { content, reason: "用户在记忆页面明确修正" },
        { "If-Match": String(edit.version) },
      );
      if (!mounted.current) return;
      setEdit(null);
      setInfo("记忆已修正；旧版本不再参与正常检索。");
      await reloadAfterWrite();
    } catch (e) {
      writeError(e);
    } finally {
      setBusy(false);
    }
  }
  async function remove() {
    if (!deleting) return;
    beginWrite();
    setBusy(true);
    setError("");
    try {
      const r = await api<{ deletion_request_id: string }>(
        `/memories/${deleting.id}?scope=memory_and_sources`,
        "DELETE",
      );
      setDeleting(null);
      const d = await api<{ status: string }>(
        `/deletions/${r.deletion_request_id}`,
      );
      if (!mounted.current) return;
      setInfo(
        d.status === "completed"
          ? "记忆和相关在线来源已清除。"
          : "删除请求已受理，清理期间角色将暂停写入。",
      );
      await reloadAfterWrite();
    } catch (e) {
      writeError(e);
    } finally {
      setBusy(false);
    }
  }
  async function saveExpiry(e: FormEvent) {
    e.preventDefault();
    if (!expiring) return;
    beginWrite();
    setBusy(true);
    setError("");
    try {
      await api(`/memories/${expiring.id}/expiration`, "PATCH", {
        expires_at: noExpiry ? null : new Date(expiryDate).toISOString(),
      }, { "If-Match": String(expiring.version) });
      if (!mounted.current) return;
      setExpiring(null);
      setInfo("期限已保存，使用旧上下文的任务已取消。到期只停止使用，原文仍可查看；彻底清除请使用忘记。");
      await reloadAfterWrite();
    } catch (e) { writeError(e); }
    finally { setBusy(false); }
  }
  return (
    <>
      <div className="page-heading">
        <div>
          <p className="eyebrow">MEMORY WITH SOURCES</p>
          <h1>记忆，由你掌握</h1>
        </div>
      </div>
      <Notice>
        当前采用关键词与近期记忆检索。每条事实只表示“你曾这样告诉我”，不会被当作外部世界已核实的事实。
      </Notice>
      <form
        className="search-row"
        onSubmit={(e) => {
          e.preventDefault();
          void load();
        }}
      >
        <input
          aria-label="搜索记忆"
          placeholder="搜索共同记录…"
          value={query}
          disabled={busy}
          onChange={(e) => setQuery(e.target.value)}
        />
        <select
          aria-label="记忆状态"
          value={filter}
          disabled={busy}
          onChange={(e) => setFilter(e.target.value)}
        >
          <option value="active">有效记忆</option>
          <option value="disputed">存在冲突</option>
          <option value="superseded">已被修正</option>
          <option value="expired">已到期</option>
        </select>
        <button disabled={busy}>搜索</button>
      </form>
      {error && <Notice error>{error}</Notice>}
      {info && <Notice>{info}</Notice>}
      <div className="memory-grid">
        {loading && !items.length ? (
          <p>正在读取…</p>
        ) : (
          items.map((m) => (
            <article key={m.id} className="memory-card">
              <div className="card-top">
                <span className="tag">
                  {m.status === "disputed"
                    ? "待你确认"
                    : m.kind === "fact"
                      ? "事实 / 偏好"
                      : "共同记录"}
                </span>
                <small>{when(m.created_at)}</small>
              </div>
              <h3>{m.content}</h3>
              <p className="muted">
                来源类型：
                {m.reality_class === "observed" ? "系统实际记录" : "用户陈述"} ·
                可靠度权重 {Number(m.confidence).toFixed(2)}
              </p>
              <p className="muted">使用期限：{m.expires_at ? when(m.expires_at) : "未设到期时间"}</p>
              <details>
                <summary>查看来源</summary>
                {m.sources?.length ? (
                  m.sources.map((s, i) => (
                    <blockquote key={i}>
                      <p>{s.quote || "已保存原始消息引用"}</p>
                      <small>{s.message_id ? `消息 ${s.message_id}` : `纠错记录 ${s.event_id ?? "已登记"}`}</small>
                    </blockquote>
                  ))
                ) : (
                  <p className="muted">读取完整来源后可查看原始引用。</p>
                )}
              </details>
              <div className="card-actions">
                {(m.status === "active" || m.status === "disputed") && <button onClick={() => {
                  setExpiring(m);
                  setNoExpiry(!m.expires_at);
                  const date = m.expires_at ? new Date(m.expires_at) : new Date(Date.now() + 86400000);
                  setExpiryDate(new Date(date.getTime() - date.getTimezoneOffset() * 60000).toISOString().slice(0, 16));
                }}>设置使用期限</button>}
                <button
                  disabled={busy || loading}
                  onClick={async () => {
                    const ticket = lastRead.current;
                    if (ticket === null || !reads.current.current(ticket)) return;
                    try {
                      const d = await api<Memory>(`/memories/${m.id}`);
                      if (!reads.current.current(ticket)) return;
                      setItems((v) =>
                        v.map((x) => (x.id === m.id ? { ...x, ...d } : x)),
                      );
                    } catch (e) {
                      if (reads.current.current(ticket)) setError(errorText(e));
                    }
                  }}
                >
                  读取完整来源
                </button>
                <button
                  onClick={() => {
                    setEdit(m);
                    setContent(m.content);
                  }}
                >
                  修正
                </button>
                <button className="danger" onClick={() => setDeleting(m)}>
                  忘记
                </button>
              </div>
            </article>
          ))
        )}
        {!loading && !items.length && (
          <div className="empty-state">
            <h3>这里还没有这类记忆。</h3>
            <p>聊天中的明确事实会在回复完成后留下来源记录。</p>
          </div>
        )}
      </div>
      {nextCursor && <button disabled={busy || loading} onClick={() => void load(nextCursor)}>
        {loading ? "正在读取…" : "加载更早记忆"}
      </button>}
      {!busy && <Autobiography characterId={character.id} revision={items.map(m => `${m.id}:${m.version}:${m.status}`).join(",")} />}
      {expiring && <div className="modal-scrim"><section className="modal" role="dialog" aria-modal="true" aria-label="设置记忆使用期限">
        <h2>设置记忆使用期限</h2>
        <p>到期后停止用于聊天和摘要，保留原文供你查看。已过期记录不会自动复活。</p>
        <p className="muted">按当前浏览器本地时间输入（{Intl.DateTimeFormat().resolvedOptions().timeZone}）。</p>
        {error && <Notice error>{error}</Notice>}
        <form onSubmit={saveExpiry}>
          <label><input type="checkbox" checked={noExpiry} onChange={e => setNoExpiry(e.target.checked)} />不设到期时间</label>
          <label>到期时间<input type="datetime-local" value={expiryDate} disabled={noExpiry} required={!noExpiry} onChange={e => setExpiryDate(e.target.value)} /></label>
          <div className="card-actions"><button type="button" disabled={busy} onClick={() => setExpiring(null)}>取消</button><button className="primary" disabled={busy}>保存期限</button></div>
        </form>
      </section></div>}
      {edit && (
        <div className="modal-scrim">
          <section
            className="modal"
            role="dialog"
            aria-modal="true"
            aria-label="修正记忆"
          >
            <h2>让记忆更准确</h2>
            {error && <Notice error>{error}</Notice>}
            <p>这是你的明确纠正，保存后旧版本将退出正常检索。</p>
            <form onSubmit={save}>
              <textarea
                aria-label="修正后的记忆"
                value={content}
                onChange={(e) => setContent(e.target.value)}
                rows={4}
                required
                maxLength={1000}
              />
              <div className="card-actions">
                <button
                  type="button"
                  disabled={busy}
                  onClick={() => setEdit(null)}
                >
                  取消
                </button>
                <button className="primary" disabled={busy || !content.trim()}>
                  保存修正
                </button>
              </div>
            </form>
          </section>
        </div>
      )}
      {deleting && (
        <div className="modal-scrim">
          <section
            className="modal"
            role="dialog"
            aria-modal="true"
            aria-label="忘记这条记忆"
          >
            <h2>忘记这条记忆</h2>
            {error && <Notice error>{error}</Notice>}
            <p>
              会同时清理相关在线原始消息、派生记忆和任务中的原文；关联对话可能显示“已清除”。历史备份和模型供应商的保留策略不受此操作保证。
            </p>
            <blockquote>{deleting.content}</blockquote>
            <div className="card-actions">
              <button disabled={busy} onClick={() => setDeleting(null)}>
                取消
              </button>
              <button className="danger" disabled={busy} onClick={remove}>
                {busy ? "正在清理…" : "确认忘记并清除来源"}
              </button>
            </div>
          </section>
        </div>
      )}
    </>
  );
}
