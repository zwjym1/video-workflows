import {useEffect, useRef, useState} from "react";
import {createLocalSpeechController, type LocalSpeechState} from "./local_speech";

export function ChatSpeech({text}: {text: string}) {
  const [state,setState] = useState<LocalSpeechState>("idle");
  const controller = useRef<{play(text:string): boolean; stop():void; dispose():void} | null>(null);
  useEffect(() => {
    if (!("speechSynthesis" in window)) { setState("unavailable"); return; }
    const current = createLocalSpeechController<SpeechSynthesisVoice,SpeechSynthesisUtterance>(
      window.speechSynthesis, value => new SpeechSynthesisUtterance(value), setState);
    controller.current = current;
    const stop = () => current.stop();
    window.addEventListener("fishlife:safety-changed",stop);
    window.addEventListener("fishlife:chat-speech-start",stop);
    return () => {
      window.removeEventListener("fishlife:safety-changed",stop);
      window.removeEventListener("fishlife:chat-speech-start",stop);
      current.dispose(); controller.current=null;
    };
  },[text]);
  return <div className="card-actions">
    <button type="button" onClick={() => {
      window.dispatchEvent(new Event("fishlife:chat-speech-start"));
      controller.current?.play(text);
    }}>本地朗读</button>
    {(state === "queued" || state === "speaking") && <button type="button"
      onClick={() => controller.current?.stop()}>停止朗读</button>}
    {state === "unavailable" && <small>设备本地朗读不可用，未发送到云语音。</small>}
    {state === "speaking" && <small role="status">设备正在朗读</small>}
  </div>;
}
