import { createContext, useContext } from "react";
export const ModeContext = createContext("unknown");
export function useModelMode() {
  return useContext(ModeContext);
}
