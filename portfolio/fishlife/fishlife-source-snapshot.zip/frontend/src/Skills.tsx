import { useEffect, useRef, useState } from "react";
import { api, errorText } from "./api";
import { Notice } from "./components";
import { createLatestReadGate } from "./latest_read";

type Recipe = {
  recipe_id: string;
  title: string;
  recipe_version: number;
  execution_allowed: boolean;
  steps: string[];
  verification_rules: string[];
  recent_success_count: number;
  reuse_hint: string;
  evidence: { event_id: string; artifact_id?: string; execution_id?: string; sha256?: string }[];
};

export function Skills({ characterId, revision }: { characterId: string; revision: string }) {
  const [items, setItems] = useState<Recipe[]>([]);
  const [error, setError] = useState("");
  const [checkedAt, setCheckedAt] = useState("");
  const gate = useRef(createLatestReadGate());
  async function load(signal?: AbortSignal) {
    const ticket = gate.current.begin();
    if (ticket === null) return;
    try {
      const result = await api<{ items: Recipe[] }>(`/characters/${characterId}/skills`, "GET", undefined, undefined, signal);
      if (!gate.current.current(ticket)) return;
      setItems(result.items);
      setCheckedAt(new Date().toLocaleTimeString());
      setError("");
    } catch (e) {
      if (!gate.current.current(ticket)) return;
      setItems([]);
      setError(errorText(e));
    }
  }
  useEffect(() => {
    const controller = new AbortController();
    void load(controller.signal);
    const timer = window.setInterval(() => {
      if (document.visibilityState === "visible") void load(controller.signal);
    }, 15000);
    return () => { gate.current.invalidate(); controller.abort(); window.clearInterval(timer); };
  }, [characterId, revision]);
  return <section aria-label="可复用经验档案">
    <h2>做成过的事，可以留下经验</h2>
    <Notice>这里把真实成功记录关联到已有操作流程，不代表角色自行学会了新程序。来源失效或文件核验失败后，不再列入经验。</Notice>
    <p className="muted">只核对最近25次有效活动与最多10份候选产物，计数不是终身技能评分。{checkedAt && `最近核对 ${checkedAt}`}</p>
    <button onClick={() => void load()}>重新核对经验</button>
    {error && <Notice error>{error}</Notice>}
    {!items.length && !error && <p className="muted">还没有有证据的经验。完成一次材料整理后再来看看。</p>}
    {items.map(recipe => <article className="card" key={recipe.recipe_id}>
      <h3>{recipe.title}</h3>
      <p>流程版本 {recipe.recipe_version} · 本次窗口内成功证据 {recipe.recent_success_count} 条</p>
      <p>{recipe.execution_allowed ? "当前权限允许复用此流程，执行仍需通过原有入口检查。" : "当前执行已暂停，历史成功证据仍保留。"}</p>
      <ol>{recipe.steps.map(step => <li key={step}>{step}</li>)}</ol>
      <p>{recipe.reuse_hint}</p>
      <details><summary>核验规则与来源证据</summary>
        <ul>{recipe.verification_rules.map(rule => <li key={rule}>{rule}</li>)}</ul>
        {recipe.evidence.map((item, index) => <div key={item.artifact_id ?? item.event_id + index}>
          <p>活动事件 {item.event_id}</p>
          {item.artifact_id && <p>产物 {item.artifact_id}</p>}
          {item.execution_id && <p>执行记录 {item.execution_id}</p>}
          {item.sha256 && <p className="muted">SHA256 {item.sha256}</p>}
        </div>)}
      </details>
    </article>)}
  </section>;
}
