import { useEffect, useRef, useState, type FormEvent } from "react";
import {
  api,
  list,
  errorText,
  when,
  canRetry,
  type Character,
  type Conversation,
  type Message,
  type Job,
} from "./api";
import { Notice, Portrait } from "./components";
import { useModelMode } from "./Mode";
import { VoiceMessage } from "./VoiceMessage";
import { useWaitingSeconds } from "./useWaitingSeconds";
import { chatParts } from "./chat_parts";
import { FishSticker, fishStickers } from "./FishSticker";

export function Chat({ character }: { character: Character }) {
  const mode = useModelMode();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [selected, setSelected] = useState("");
  const [messages, setMessages] = useState<Message[]>([]);
  const [text, setText] = useState("");
  const [emojiOpen, setEmojiOpen] = useState(false);
  const [contentKind, setContentKind] = useState("real");
  const [jobId, setJobId] = useState("");
  const [jobStatus, setJobStatus] = useState("");
  const waitingSeconds = useWaitingSeconds(!!jobId, jobId);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [loading, setLoading] = useState(false);
  const [truncated, setTruncated] = useState(false);
  const [failedMessage, setFailedMessage] = useState("");
  const end = useRef<HTMLDivElement>(null);
  const selectedRef = useRef(selected);
  selectedRef.current = selected;
  const pending = useRef<{
    content: string;
    key: string;
    kind: string;
    conversation: string;
  } | null>(null);
  useEffect(() => {
    const c = new AbortController();
    void list<Conversation>(
      `/characters/${character.id}/conversations`,
      c.signal,
    )
      .then((r) => {
        setConversations(r.items);
        setSelected(r.items[0]?.id ?? "");
      })
      .catch((e) => {
        if (!c.signal.aborted) setError(errorText(e));
      });
    return () => c.abort();
  }, [character.id]);
  useEffect(() => {
    if (!selected) {
      setMessages([]);
      return;
    }
    const c = new AbortController();
    setLoading(true);
    setError("");
    setFailedMessage("");
    setJobId("");
    setJobStatus("");
    void list<Message>(`/conversations/${selected}/messages`, c.signal)
      .then((r) => {
        const sorted = r.items.sort((a, b) => a.seq - b.seq);
        setMessages(sorted);
        setTruncated(Boolean(r.truncated));
        const last = sorted.filter((m) => m.role === "user").at(-1);
        if (last?.reply_job_id) setJobId(last.reply_job_id);
      })
      .catch((e) => {
        if (!c.signal.aborted) setError(errorText(e));
      })
      .finally(() => {
        if (!c.signal.aborted) setLoading(false);
      });
    return () => c.abort();
  }, [selected]);
  useEffect(() => {
    if (!jobId || !selected) return;
    const c = new AbortController();
    const conversationId = selected;
    let timer: ReturnType<typeof setTimeout>;
    const deadline = Date.now() + 120000;
    const poll = async () => {
      try {
        const job = await api<Job>(
          `/jobs/${jobId}`,
          "GET",
          undefined,
          undefined,
          c.signal,
        );
        if (c.signal.aborted) return;
        setJobStatus(job.status);
        if (["succeeded", "completed"].includes(job.status)) {
          const r = await list<Message>(
            `/conversations/${conversationId}/messages`,
            c.signal,
          );
          setMessages(r.items.sort((a, b) => a.seq - b.seq));
          setTruncated(Boolean(r.truncated));
          setJobId("");
          setFailedMessage("");
        } else if (["failed", "unknown", "cancelled"].includes(job.status)) {
          setJobId("");
          const retryable = canRetry(job);
          setError(
            job.status === "unknown"
              ? "模型调用结果或费用尚不确定。原消息已保存，请先核对服务商账单，系统不会自动重试。"
              : job.status === "cancelled"
                ? "本次回复已取消。原消息已保存。"
                : `回复未完成（${job.error_code ?? job.status}）。原消息已保存。${retryable ? "可以重试。" : "已达到重试上限。"}`,
          );
          const r = await list<Message>(
            `/conversations/${conversationId}/messages`,
            c.signal,
          );
          setMessages(r.items.sort((a, b) => a.seq - b.seq));
          setTruncated(Boolean(r.truncated));
          setFailedMessage(
            retryable
              ? (r.items.filter((m) => m.role === "user").at(-1)?.id ?? "")
              : "",
          );
        } else if (Date.now() > deadline) {
          setJobId("");
          setError(
            "回复仍在后台处理。消息已保存，稍后重新打开会话即可查看，请勿重复发送。",
          );
        } else timer = setTimeout(poll, 1000);
      } catch (e) {
        if (!c.signal.aborted) {
          setJobId("");
          setError(errorText(e));
        }
      }
    };
    void poll();
    return () => {
      c.abort();
      clearTimeout(timer);
    };
  }, [jobId, selected]);
  useEffect(() => {
    end.current?.scrollIntoView({ block: "nearest" });
  }, [messages, jobId]);
  async function newConversation() {
    setBusy(true);
    setError("");
    try {
      const c = await api<Conversation>(
        `/characters/${character.id}/conversations`,
        "POST",
        { title: "新的对话" },
      );
      setConversations((v) => [c, ...v]);
      setSelected(c.id);
      pending.current = null;
    } catch (e) {
      setError(errorText(e));
    } finally {
      setBusy(false);
    }
  }
  async function send(e: FormEvent) {
    e.preventDefault();
    if (!text.trim() || !selected || busy || jobId) return;
    const body = text.trim();
    const current = selected;
    if (
      pending.current?.content !== body ||
      pending.current.kind !== contentKind ||
      pending.current.conversation !== current
    )
      pending.current = {
        content: body,
        key: crypto.randomUUID(),
        kind: contentKind,
        conversation: current,
      };
    setBusy(true);
    setError("");
    try {
      const r = await api<{ user_message_id: string; reply_job_id: string }>(
        `/conversations/${current}/messages`,
        "POST",
        {
          content: body,
          client_request_id: pending.current.key,
          content_kind: contentKind,
        },
        { "Idempotency-Key": pending.current.key },
      );
      pending.current = null;
      setText("");
      if (selectedRef.current === current) {
        const m = await list<Message>(`/conversations/${current}/messages`);
        setMessages(m.items.sort((a, b) => a.seq - b.seq));
        setTruncated(Boolean(m.truncated));
        setJobId(r.reply_job_id);
        setFailedMessage("");
      }
    } catch (e) {
      setError(errorText(e));
    } finally {
      setBusy(false);
    }
  }
  async function retry() {
    setBusy(true);
    setError("");
    try {
      const r = await api<{ reply_job_id: string }>(
        `/messages/${failedMessage}/retry`,
        "POST",
        {},
        { "Idempotency-Key": crypto.randomUUID() },
      );
      setJobId(r.reply_job_id);
    } catch (e) {
      setError(errorText(e));
    } finally {
      setBusy(false);
    }
  }
  async function earlier() {
    if (!selected || !messages.length) return;
    const conversationId = selected;
    setLoading(true);
    setError("");
    try {
      const page = await list<Message>(
        `/conversations/${conversationId}/messages?cursor=${messages[0].seq}`,
      );
      if (selectedRef.current !== conversationId) return;
      setMessages((current) =>
        [
          ...new Map(
            [...page.items, ...current].map((m) => [m.id, m]),
          ).values(),
        ].sort((a, b) => a.seq - b.seq),
      );
      setTruncated(Boolean(page.truncated));
    } catch (e) {
      if (selectedRef.current === conversationId) setError(errorText(e));
    } finally {
      if (selectedRef.current === conversationId) setLoading(false);
    }
  }
  return (
    <>
      <div className="page-heading">
        <div>
          <p className="eyebrow">CONVERSATIONS</p>
          <h1>和{character.name}聊聊</h1>
        </div>
        <button onClick={newConversation} disabled={busy}>
          ＋ 新会话
        </button>
      </div>
      <details className="technical-details"><summary>聊天与语音说明</summary><Notice>
        {mode === "mock"
          ? "模拟模型 · 可测试“我喜欢绿茶”等明确偏好与跨会话记忆，无付费调用。"
          : mode === "qoder"
            ? "Qoder 云端模型 · 聊天及相关记忆将发送给 Qoder；费用预占与账单报告分别记录。"
            : mode === "codex" ? "GPT · 使用已登录的 Codex 订阅，聊天及相关记忆发送给 OpenAI。消耗订阅额度，不能视为无限或零费用；语音仍在本机生成。"
            : "模型 API 模式 · 回复经过费用预占，实际经历仍以来源记录为准。"}
      </Notice><p>语音在本机生成，可播放和保存。当前不自动播放；刷新页面后可重新生成。内置表情为原创大肥鱼图案。</p></details>
      {truncated && (
        <Notice>
          还有更早的记录。
          <button disabled={loading || !!jobId} onClick={() => void earlier()}>
            加载更早的消息
          </button>
        </Notice>
      )}
      <div className="chat-layout">
        <nav className="conversation-list" aria-label="会话列表">
          {conversations.map((c) => (
            <button
              key={c.id}
              className={selected === c.id ? "selected" : ""}
              onClick={() => setSelected(c.id)}
            >
              {c.title}
              <small>{when(c.created_at)}</small>
            </button>
          ))}
          {!conversations.length && <p className="muted">先新建一个会话。</p>}
        </nav>
        <section className="chat-panel">
          <div className="chat-messages" aria-live="polite">
            {loading ? (
              <p className="muted">正在读取记录…</p>
            ) : !messages.length ? (
              <div className="chat-empty">
                <Portrait />
                <h3>从一句简单的话开始。</h3>
                <p>试试“我喜欢绿茶”。你之后可以在记忆中查看它的来源。</p>
              </div>
            ) : (
              messages.flatMap((m) => (m.role === "assistant" && m.content ? chatParts(m.content) : [m.content]).map((part, index, parts) => (
                <article
                  key={`${m.id}-${index}`}
                  className={`bubble ${m.role === "user" ? "bubble-user" : ""}`}
                >
                  <span>{m.role === "user" ? "你" : character.name}</span>
                  {part && /^\[表情：(开心|贴贴|疑惑|困困)\]$/.test(part.trim()) ? <FishSticker text={part} /> : <p>{part || "这段内容已按你的要求清除。"}</p>}
                  {m.role === "assistant" && m.content && !/^\[表情：(开心|贴贴|疑惑|困困)\]$/.test(m.content.trim()) && index === parts.length - 1 && <VoiceMessage messageId={m.id} text={m.content} />}
                </article>
              )))
            )}
            {jobId && (
              <div className="typing" role="status">
                {jobStatus === "queued" ? "等一下，消息正在排队…" : `${character.name}正在回复…`}
                <small>已等待 {waitingSeconds} 秒</small>
              </div>
            )}
            <div ref={end} />
          </div>
          {error && (
            <Notice error>
              {error}
              {failedMessage && (
                <button onClick={retry} disabled={busy}>
                  重试回复
                </button>
              )}
            </Notice>
          )}
          <form className="composer" onSubmit={send}>
            <div className="card-actions">
              {fishStickers.map((mood) => <button type="button" key={mood} disabled={!selected || busy || !!jobId} title={`插入大肥鱼${mood}表情`} onClick={() => setText((v) => (v ? v + "\n\n" : "") + `[表情：${mood}]`)}>🐟 {mood}</button>)}
              <button type="button" aria-expanded={emojiOpen} onClick={() => setEmojiOpen((v) => !v)}>☺ 表情</button>
              {emojiOpen && <div aria-label="常用表情">{["🐟","😄","🥺","🤔","😴","🙌","❤️","😂","👀","🌊","🫂","✨"].map((emoji) => <button type="button" key={emoji} disabled={!selected || busy || !!jobId} aria-label={`插入${emoji}`} onClick={() => {setText((v) => (v + emoji).slice(0,6000));setEmojiOpen(false);}}>{emoji}</button>)}</div>}
            </div>
            <textarea
              aria-label="消息"
              placeholder={selected ? "说说你今天的想法…" : "先点击“新会话”"}
              value={text}
              onChange={(e) => setText(e.target.value)}
              disabled={!selected}
              maxLength={6000}
              rows={3}
            />
            <div>
              <select
                aria-label="消息类型"
                value={contentKind}
                onChange={(e) => setContentKind(e.target.value)}
                disabled={busy || !!jobId}
                style={{ maxWidth: 210, fontSize: 11 }}
              >
                <option value="real">真实自述 · 可形成来源记忆</option>
                <option value="roleplay">角色扮演 · 不写事实记忆</option>
              </select>
              <button
                className="primary"
                disabled={!selected || !text.trim() || busy || !!jobId}
              >
                {busy ? "正在保存…" : "发送 ↗"}
              </button>
            </div>
          </form>
        </section>
      </div>
    </>
  );
}
