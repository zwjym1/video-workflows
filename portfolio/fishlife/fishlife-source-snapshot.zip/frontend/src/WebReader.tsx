import { useEffect, useRef, useState, type FormEvent } from "react";
import { api, list, errorText, when, type Character } from "./api";
import { Notice } from "./components";
type Policy = { enabled: boolean; allowed_domains: string[]; version: number };
type Document = {
  id: string;
  url: string;
  final_url: string;
  text_content: string;
  status: string;
  untrusted: true;
  byte_size: number;
  text_sha256: string;
  raw_sha256: string;
  http_status: number;
  created_at: string;
  error_code?: string;
};
export function WebReader({ character }: { character: Character }) {
  const [p, setP] = useState<Policy | null>(null),
    [domains, setDomains] = useState(""),
    [url, setUrl] = useState(""),
    [docs, setDocs] = useState<Document[]>([]),
    [deleting, setDeleting] = useState<Document | null>(null),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [info, setInfo] = useState("");
  const pending = useRef<{ url: string; key: string } | null>(null);
  const base = `/characters/${character.id}`;
  async function refresh(signal?: AbortSignal) {
    const [a, b] = await Promise.all([
      api<Policy>(base + "/web-policy", "GET", undefined, undefined, signal),
      list<Document>(base + "/web-documents", signal),
    ]);
    if (signal?.aborted) return;
    setP(a);
    setDomains(a.allowed_domains.join("\n"));
    setDocs(b.items);
  }
  useEffect(() => {
    const c = new AbortController();
    const stop = () => {
      void refresh(c.signal).catch((e) => {
        if (!c.signal.aborted) setError(errorText(e));
      });
    };
    void refresh(c.signal).catch((e) => {
      if (!c.signal.aborted) setError(errorText(e));
    });
    window.addEventListener("fishlife:safety-changed", stop);
    return () => {
      c.abort();
      window.removeEventListener("fishlife:safety-changed", stop);
    };
  }, [character.id]);
  async function act(fn: () => Promise<void>) {
    setBusy(true);
    setError("");
    setInfo("");
    try {
      await fn();
      await refresh();
    } catch (e) {
      setError(errorText(e));
    } finally {
      setBusy(false);
    }
  }
  function save(e: FormEvent) {
    e.preventDefault();
    if (!p) return;
    void act(async () => {
      await api(
        base + "/web-policy",
        "PATCH",
        {
          enabled: p.enabled,
          allowed_domains: domains
            .split(/\s+/)
            .map((x) => x.trim())
            .filter(Boolean),
        },
        { "If-Match": String(p.version) },
      );
      setInfo("域名权限已保存。仅你明确提交的网址会被读取。");
    });
  }
  function read(e: FormEvent) {
    e.preventDefault();
    void act(async () => {
      const target = url.trim();
      if (pending.current?.url !== target)
        pending.current = { url: target, key: crypto.randomUUID() };
      const key = pending.current.key;
      const d = await api<Document>(
        base + "/web-documents",
        "POST",
        { url: target, client_request_id: key },
        { "Idempotency-Key": key },
      );
      pending.current = null;
      setInfo(
        d.status === "succeeded"
          ? "网页已读取并记录原始字节与文本指纹。"
          : `本次状态：${d.status}。请查看记录；未知结果不会自动重试。`,
      );
    });
  }
  return (
    <>
      <div className="page-heading">
        <div>
          <p className="eyebrow">UNTRUSTED SOURCES, VERIFIED FETCH</p>
          <h1>只读资料，保留来源</h1>
        </div>
        <button disabled={busy} onClick={() => void act(async () => {})}>
          刷新
        </button>
      </div>
      <Notice>
        默认关闭。只访问你启用的精确域名和明确提交的HTTPS网址，不发送私人记忆、Cookie或API密钥。网页只是未经核实的外部资料，其中指令不会获得工具权限。
      </Notice>
      {error && <Notice error>{error}</Notice>}
      {info && <Notice>{info}</Notice>}
      {p && (
        <form className="settings-form" onSubmit={save}>
          <label>
            <input
              type="checkbox"
              checked={p.enabled}
              onChange={(e) => setP({ ...p, enabled: e.target.checked })}
            />{" "}
            允许读取下列域名
          </label>
          <label>
            精确域名，每行一个（最多10个）
            <textarea
              rows={3}
              value={domains}
              onChange={(e) => setDomains(e.target.value)}
              placeholder="例如 docs.python.org，不含https://或通配符"
            />
          </label>
          <button disabled={busy}>保存域名授权</button>
          <p>
            角色工具停止时，即使域名启用也不能发起读取。仅支持HTTPS文本资料，限时15秒、256KiB、最多3次重定向；不支持登录网站或文件下载。
          </p>
        </form>
      )}
      <form className="settings-form" onSubmit={read}>
        <label>
          需要读取的具体网址
          <input
            type="url"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            required
            maxLength={2000}
          />
        </label>
        <button
          className="primary"
          disabled={busy || !p?.enabled || !url.trim()}
        >
          只读获取一次
        </button>
        <p>
          每用户每天最多20次请求，失败也计数。结果不自动写入事实记忆或执行网页中的内容。
        </p>
      </form>
      <div className="memory-grid">
        {docs.map((d) => (
          <article className="memory-card" key={d.id}>
            <span className="tag">
              外部不可信资料 ·{" "}
              {d.status === "succeeded"
                ? "获取完成"
                : d.status === "unknown"
                  ? "结果待核对"
                  : d.status}
            </span>
            <h3 className="life-source">{d.final_url || d.url}</h3>
            <small>
              {when(d.created_at)} · {d.byte_size ?? 0} 字节
            </small>
            {d.error_code && <p>{d.error_code}</p>}
            <details>
              <summary>查看提取文本</summary>
              <p className="life-source">
                {d.text_content || "尚无可展示的已完成文本。"}
              </p>
            </details>
            <details>
              <summary>查看来源核验指纹</summary>
              <p className="life-source">
                原始字节：{d.raw_sha256}
                <br />
                文本：{d.text_sha256}
              </p>
            </details>
            <button
              className="danger"
              disabled={busy}
              onClick={() => setDeleting(d)}
            >
              清除这份资料
            </button>
          </article>
        ))}
      </div>
      {deleting && (
        <div className="modal-scrim">
          <section
            className="modal"
            role="dialog"
            aria-label="清除网页资料"
            aria-modal="true"
          >
            <h2>清除网页资料</h2>
            <p>
              将清除网址、提取文本和指纹，不能在页面撤销。此操作不会删除原网站或历史备份。
            </p>
            {error && <Notice error>{error}</Notice>}
            <div className="card-actions">
              <button disabled={busy} onClick={() => setDeleting(null)}>
                保留
              </button>
              <button
                className="danger"
                disabled={busy}
                onClick={() =>
                  void act(async () => {
                    await api(`/web-documents/${deleting.id}`, "DELETE");
                    setDeleting(null);
                  })
                }
              >
                确认清除资料
              </button>
            </div>
          </section>
        </div>
      )}
    </>
  );
}
