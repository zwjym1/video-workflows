export function modelMode(provider: string | undefined): string {
  if (provider === "mock") return "模拟模型";
  if (provider === "qoder") return "Qoder 云端模型";
  if (provider === "codex") return "GPT · Codex 订阅";
  if (provider === "openai") return "模型 API";
  return "模型状态未识别";
}
