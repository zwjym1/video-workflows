import { useEffect, useRef, useState } from "react";
import { api, errorText, type Character } from "./api";
import { Notice } from "./components";

type Suggestion = {topic: string; reason: string; source_digest: string;
  evidence: {book_id: string; title: string; source_hash: string}[]};
type Response = {items: Suggestion[]; character_version: number};

export function InterestGrowth({ characterId, onChanged }: {characterId: string; onChanged?: (character: Character) => void}) {
  const [data, setData] = useState<Response | null>(null);
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");
  const [busy, setBusy] = useState(false);
  const [selected, setSelected] = useState<Suggestion | null>(null);
  const alive = useRef(true), ticket = useRef(0), writing = useRef(false);
  const base = `/characters/${characterId}/interest-suggestions`;
  async function load(signal?: AbortSignal) {
    const current = ++ticket.current;
    const value = await api<Response>(base,"GET",undefined,undefined,signal);
    if(alive.current && !signal?.aborted && ticket.current === current) setData(value);
  }
  useEffect(() => {
    alive.current = true;
    const controller = new AbortController();
    void load(controller.signal).catch((e) => {if(!controller.signal.aborted) setError(errorText(e));});
    return () => {alive.current = false; ticket.current++; controller.abort();};
  },[characterId]);
  async function accept() {
    if(writing.current || !data || !selected) return;
    writing.current = true; ticket.current++; setBusy(true); setError("");
    try {
      const character = await api<Character>(base+"/accept","POST",{topic:selected.topic,source_digest:selected.source_digest,
        expected_version:data.character_version,acknowledgement:"确认添加这项兴趣"});
      if(alive.current) {
        onChanged?.(character);
        setSelected(null); setInfo("兴趣已添加。可在角色设定中查看或移除。");
        await load();
      }
    } catch(e) {if(alive.current) setError(errorText(e)+"；如请求结果不确定，请刷新建议，不要盲目重复提交。");}
    finally {writing.current=false;if(alive.current)setBusy(false);}
  }
  return <section className="settings-form"><h2>兴趣可以慢慢形成</h2>
    <p>两份不同、已核验处理完成的资料，标题具有相同的 #主题 时，才给出本地建议。
      处理过不代表一定喜欢，是否加入兴趣由你决定；不会自动改写核心人格。</p>
    {error && <Notice error>{error}</Notice>}{info && <Notice>{info}</Notice>}
    {!data?.items.length && <p>目前没有足够依据。可以在书架资料标题标注 #植物 等主题；无需为了生成建议反复处理资料。</p>}
    {data?.items.map((item) => <article className="memory-card" key={item.topic}>
      <h3>考虑加入「{item.topic}」</h3><p>{item.reason}</p>
      <ul>{item.evidence.map((e) => <li key={e.book_id}>{e.title}<br/><small>来源 SHA256 {e.source_hash}</small></li>)}</ul>
      <button disabled={busy} onClick={() => setSelected(item)}>查看确认</button>
    </article>)}
    {selected && <Notice>确认把「{selected.topic}」加入角色兴趣？不改变其他人格设定。
      <button disabled={busy} onClick={() => void accept()}>确认添加这项兴趣</button>
      <button disabled={busy} onClick={() => setSelected(null)}>暂不添加</button></Notice>}
    <button disabled={busy} onClick={() => {setSelected(null);setError("");void load().catch((e)=>{if(alive.current)setError(errorText(e));});}}>刷新兴趣建议</button>
  </section>;
}
