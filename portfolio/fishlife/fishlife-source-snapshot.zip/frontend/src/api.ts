export type User = { id: string; username: string };
export type Auth = { user: User; csrf_token: string };
export type Character = {
  id: string;
  name: string;
  core_persona: Record<string, unknown>;
  interests: string[];
  version: number;
};
export type Conversation = { id: string; title: string; created_at?: string };
export type Message = {
  id: string;
  role: string;
  content: string;
  status: string;
  seq: number;
  reply_job_id?: string;
  in_reply_to?: string;
};
export type Job = {
  id: string;
  status: string;
  result_message_id?: string;
  error_code?: string;
  attempt_count?: number;
  max_attempts?: number;
};
export function canRetry(job: Job) {
  return (
    job.status === "failed" &&
    (job.attempt_count ?? 0) < (job.max_attempts ?? 3)
  );
}
export type Memory = {
  id: string;
  content: string;
  status: string;
  kind: string;
  confidence: number;
  version: number;
  expires_at?: string | null;
  reality_class?: string;
  created_at?: string;
  sources?: { message_id?: string; event_id?: string; quote?: string }[];
};
export type LifeEvent = {
  id: string;
  event_type: string;
  occurred_at?: string;
  created_at?: string;
  reality_class?: string;
};
export type Runtime = {
  stage?: string;
  app_version?: string;
  capabilities?: Record<string, boolean>;
  model_provider?: string;
  [key: string]: unknown;
};

export class ApiError extends Error {
  status: number;
  code: string;
  constructor(status: number, code: string, message: string) {
    super(message);
    this.status = status;
    this.code = code;
  }
}
let csrf = "";
export function setCsrf(value: string) {
  csrf = value;
}
export async function messageAudio(messageId: string, signal: AbortSignal): Promise<Blob> {
  const response = await fetch(`/api/v1/messages/${encodeURIComponent(messageId)}/audio`, {
    method: "POST", credentials: "same-origin", headers: {"X-CSRF-Token": csrf}, signal,
  });
  if (!response.ok) {
    if (response.status === 401) window.dispatchEvent(new Event("fishlife:unauthorized"));
    const data = await response.json().catch(() => undefined);
    throw new ApiError(response.status, data?.error?.code ?? "VOICE_FAILED",
      data?.error?.message ?? "语音暂时无法生成，请稍后再试。");
  }
  if (!response.headers.get("Content-Type")?.startsWith("audio/wav")) throw new Error("语音响应格式异常");
  const blob = await response.blob();
  if (!blob.size || blob.size > 2_000_000) throw new Error("语音文件大小异常");
  return blob;
}
export async function api<T>(
  path: string,
  method = "GET",
  body?: unknown,
  extraHeaders?: Record<string, string>,
  signal?: AbortSignal,
): Promise<T> {
  const headers: Record<string, string> = { ...extraHeaders };
  if (body !== undefined) headers["Content-Type"] = "application/json";
  if (method !== "GET") headers["X-CSRF-Token"] = csrf;
  const response = await fetch(`/api/v1${path}`, {
    method,
    headers,
    credentials: "same-origin",
    body: body === undefined ? undefined : JSON.stringify(body),
    signal,
  });
  const data =
    response.status === 204
      ? undefined
      : await response.json().catch(() => undefined);
  if (!response.ok) {
    if (response.status === 401)
      window.dispatchEvent(new Event("fishlife:unauthorized"));
    const detail =
      data?.error?.message ??
      (typeof data?.detail === "string" ? data.detail : undefined);
    throw new ApiError(
      response.status,
      data?.error?.code ?? "REQUEST_FAILED",
      detail ??
        (response.status === 422
          ? "输入内容不符合要求，请检查后重试。"
          : `请求失败（${response.status}）`),
    );
  }
  return data as T;
}
export function list<T>(path: string, signal?: AbortSignal) {
  return api<{ items: T[]; next_cursor?: string; truncated?: boolean }>(
    path,
    "GET",
    undefined,
    undefined,
    signal,
  );
}
export function errorText(e: unknown) {
  return e instanceof Error ? e.message : "暂时无法完成，请稍后重试。";
}
export function when(value?: string) {
  return value
    ? new Date(value).toLocaleString("zh-CN", { hour12: false })
    : "";
}
