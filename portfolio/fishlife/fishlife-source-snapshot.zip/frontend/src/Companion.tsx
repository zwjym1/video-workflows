import { useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import { api, list, errorText, when, type Character } from "./api";
import { Notice } from "./components";
type Preferences = {
  enabled: boolean;
  timezone: string;
  quiet_start_hour: number;
  quiet_end_hour: number;
  daily_limit: number;
  min_interval_minutes: number;
  version: number;
  capability_enabled: boolean;
};
type Share = {
  id: string;
  body: string;
  status: string;
  source_event_id: string;
  created_at: string;
};
export function Companion({ character }: { character: Character }) {
  const scope = useMemo(
    () => ({
      active: false,
      generation: 0,
      writing: false,
      loading: false,
      controller: null as AbortController | null,
    }),
    [character.id],
  );
  const currentScope = useRef(scope);
  currentScope.current = scope;
  const [p, setP] = useState<Preferences | null>(null),
    [history, setHistory] = useState({
      characterId: character.id,
      items: [] as Share[],
      nextCursor: null as string | null,
    }),
    [loading, setLoading] = useState(false),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [info, setInfo] = useState("");
  const shares = history.characterId === character.id ? history.items : [];
  const nextCursor = history.characterId === character.id ? history.nextCursor : null;
  function live() {
    return scope.active && currentScope.current === scope;
  }
  function current(ticket: number) {
    return live() && scope.generation === ticket;
  }
  function clearHistory() {
    scope.generation++;
    scope.controller?.abort();
    scope.controller = null;
    scope.loading = false;
    setLoading(false);
    setHistory({ characterId: character.id, items: [], nextCursor: null });
  }
  async function refresh() {
    if (!live()) return;
    clearHistory();
    if (scope.writing) return;
    const ticket = scope.generation;
    const controller = new AbortController();
    scope.controller = controller;
    scope.loading = true;
    setLoading(true);
    setError("");
    try {
      const [a, b] = await Promise.all([
        api<Preferences>(
          "/notification-preferences",
          "GET",
          undefined,
          undefined,
          controller.signal,
        ),
        list<Share>(`/characters/${character.id}/notifications`, controller.signal),
      ]);
      if (!current(ticket)) return;
      setP(a);
      setHistory({
        characterId: character.id,
        items: b.items,
        nextCursor: b.next_cursor ?? null,
      });
    } catch (e) {
      if (current(ticket)) setError(errorText(e));
    } finally {
      if (current(ticket)) {
        scope.loading = false;
        scope.controller = null;
        setLoading(false);
      }
    }
  }
  async function loadEarlier() {
    if (!live() || scope.writing || scope.loading || !nextCursor) return;
    const ticket = ++scope.generation;
    const controller = new AbortController();
    scope.controller = controller;
    scope.loading = true;
    setLoading(true);
    setError("");
    try {
      const page = await list<Share>(
        `/characters/${character.id}/notifications?cursor=${encodeURIComponent(nextCursor)}`,
        controller.signal,
      );
      if (!current(ticket)) return;
      setHistory((previous) => {
        if (!current(ticket) || previous.characterId !== character.id) return previous;
        const seen = new Set(previous.items.map((item) => item.id));
        const additions = page.items.filter((item) => {
          if (seen.has(item.id)) return false;
          seen.add(item.id);
          return true;
        });
        return {
          characterId: character.id,
          items: [...previous.items, ...additions],
          nextCursor: page.next_cursor ?? null,
        };
      });
    } catch (e) {
      if (current(ticket)) setError(errorText(e));
    } finally {
      if (current(ticket)) {
        scope.loading = false;
        scope.controller = null;
        setLoading(false);
      }
    }
  }
  useEffect(() => {
    scope.active = true;
    setBusy(false);
    setInfo("");
    const stopped = () => {
      void refresh();
    };
    window.addEventListener("fishlife:safety-changed", stopped);
    void refresh();
    return () => {
      scope.active = false;
      scope.generation++;
      scope.controller?.abort();
      window.removeEventListener("fishlife:safety-changed", stopped);
    };
  }, [character.id]);
  async function act(fn: () => Promise<void>, message = "") {
    if (!live() || scope.writing) return;
    clearHistory();
    scope.writing = true;
    setBusy(true);
    setError("");
    setInfo("");
    try {
      await fn();
      if (!live()) return;
      scope.writing = false;
      await refresh();
      if (live()) setInfo(message);
    } catch (e) {
      if (live()) setError(errorText(e));
    } finally {
      scope.writing = false;
      if (live()) setBusy(false);
    }
  }
  function save(e: FormEvent) {
    e.preventDefault();
    if (!p) return;
    void act(async () => {
      const {
        enabled,
        timezone,
        quiet_start_hour,
        quiet_end_hour,
        daily_limit,
        min_interval_minutes,
      } = p;
      await api(
        "/notification-preferences",
        "PATCH",
        {
          enabled,
          timezone,
          quiet_start_hour,
          quiet_end_hour,
          daily_limit,
          min_interval_minutes,
        },
        { "If-Match": String(p.version) },
      );
    }, "陪伴偏好已保存。只有有效活动才会产生站内分享。");
  }
  return (
    <>
      <div className="page-heading">
        <div>
          <p className="eyebrow">THOUGHTFUL COMPANY</p>
          <h1>有值得分享的事，再来找你</h1>
        </div>
        <button disabled={busy} onClick={() => void refresh()}>
          刷新
        </button>
      </div>
      <Notice>
        仅保存在此控制台内，不发送微信、邮件或系统推送。默认关闭；静默期或达到频率上限时会等待，不因你没回应而催促。
      </Notice>
      {error && <Notice error>{error}</Notice>}
      {info && <Notice>{info}</Notice>}
      {p && (
        <form className="settings-form" onSubmit={save}>
          <label>
            <input
              type="checkbox"
              checked={p.enabled}
              onChange={(e) => setP({ ...p, enabled: e.target.checked })}
            />{" "}
            允许基于真实活动的站内分享
          </label>
          <label>
            时区
            <input
              value={p.timezone}
              onChange={(e) => setP({ ...p, timezone: e.target.value })}
              required
            />
          </label>
          <div className="life-columns">
            <label>
              静默开始（小时）
              <input
                type="number"
                min={0}
                max={23}
                value={p.quiet_start_hour}
                onChange={(e) =>
                  setP({ ...p, quiet_start_hour: Number(e.target.value) })
                }
              />
            </label>
            <label>
              静默结束（小时）
              <input
                type="number"
                min={0}
                max={23}
                value={p.quiet_end_hour}
                onChange={(e) =>
                  setP({ ...p, quiet_end_hour: Number(e.target.value) })
                }
              />
            </label>
          </div>
          <p>开始与结束相同表示不设静默时段。配额在所有角色间共享。</p>
          <label>
            每天最多几条
            <input
              type="number"
              min={1}
              max={5}
              value={p.daily_limit}
              onChange={(e) =>
                setP({ ...p, daily_limit: Number(e.target.value) })
              }
            />
          </label>
          <label>
            两次分享至少间隔（分钟）
            <input
              type="number"
              min={60}
              max={1440}
              value={p.min_interval_minutes}
              onChange={(e) =>
                setP({ ...p, min_interval_minutes: Number(e.target.value) })
              }
            />
          </label>
          <button className="primary" disabled={busy || !p.capability_enabled}>
            保存陪伴偏好
          </button>
        </form>
      )}
      <h2>{character.name}的分享</h2>
      <div className="memory-grid">
        {shares.map((s) => (
          <article className="memory-card" key={s.id}>
            <span className="tag">
              {s.status === "invalidated"
                ? "来源失效"
                : s.status === "read"
                  ? "已读"
                  : "未读"}
            </span>
            <small>{when(s.created_at)}</small>
            <p className="life-source">{s.body || "来源内容已清除。"}</p>
            <details>
              <summary>实际事件来源</summary>
              <small>{s.source_event_id}</small>
            </details>
            {s.status === "unread" && (
              <button
                disabled={busy}
                onClick={() =>
                  void act(async () => {
                    await api(`/notifications/${s.id}/read`, "POST", {});
                  })
                }
              >
                标记已读
              </button>
            )}
          </article>
        ))}
        {!shares.length && (
          <p className="empty-state">
            暂时没有新分享。没有值得说的事情时，可以安静陪着。
          </p>
        )}
      </div>
      {nextCursor && (
        <button disabled={busy || loading} onClick={() => void loadEarlier()}>
          {loading ? "正在加载…" : "加载更早分享"}
        </button>
      )}
    </>
  );
}

export function GlobalStop() {
  const [busy, setBusy] = useState(false),
    [message, setMessage] = useState("");
  async function stop() {
    setBusy(true);
    setMessage("");
    try {
      await api("/safety/stop", "POST", {});
      window.dispatchEvent(new Event("fishlife:safety-changed"));
      setMessage("所有角色的活动、工具和站内分享已停止；聊天仍可用。");
    } catch (e) {
      setMessage(errorText(e));
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="global-stop">
      <button className="danger" disabled={busy} onClick={() => void stop()}>
        {busy ? "正在停止…" : "停止全部自主活动与工具"}
      </button>
      {message && <p role="status">{message}</p>}
    </div>
  );
}
