import { useEffect, useMemo, useState, useRef, type FormEvent } from "react";
import { api, list, errorText, when, type Character } from "./api";
import { Notice } from "./components";
import { Skills } from "./Skills";
type Goal = { id: string; title: string; status: string };
type Artifact = {
  id: string;
  goal_id: string;
  status: string;
  sha256: string;
  byte_size: number;
  download_url: string;
  created_at: string;
};
type Policy = {
  enabled: boolean;
  allowed_tools: string[];
  external_execution_supported: boolean;
};
type Preview = {
  id: string;
  action: string;
  payload: Record<string, unknown>;
  payload_hash: string;
  status: string;
  expires_at: string;
  execution_supported: false;
};
type Execution = {
  id: string;
  status: string;
  tool_name?: string;
  started_at: string;
  error_code?: string;
};
export function Tools({ character }: { character: Character }) {
  const scope = useMemo(() => ({ active: false, generation: 0, writing: false,
    loading: false, controller: null as AbortController | null }), [character.id]);
  const currentScope = useRef(scope);
  currentScope.current = scope;
  type History = { characterId: string; goals: Goal[]; artifacts: Artifact[];
    previews: Preview[]; logs: Execution[]; cursors: Record<Kind, string | null> };
  type Kind = "goals" | "artifacts" | "previews" | "logs";
  const empty = (): History => ({ characterId: character.id, goals: [], artifacts: [],
    previews: [], logs: [], cursors: { goals: null, artifacts: null, previews: null, logs: null } });
  const [history, setHistory] = useState<History>(empty);
  const visible = history.characterId === character.id ? history : empty();
  const { goals, artifacts, previews, logs, cursors } = visible;
  const [storedPolicy, setPolicy] = useState<Policy | null>(null);
  const policy = history.characterId === character.id ? storedPolicy : null;
  const [goal, setGoal] = useState(""), [busy, setBusy] = useState(false),
    [loading, setLoading] = useState(false), [error, setError] = useState(""),
    [info, setInfo] = useState("");
  const [action, setAction] = useState("publish"),
    [payload, setPayload] = useState('{"target":"预览示例","content":"仅预览，不执行"}');
  const base = `/characters/${character.id}`;
  const pendingNote = useRef<{ goal: string; key: string } | null>(null);
  const pendingPreview = useRef<{ body: string; key: string } | null>(null);
  const paths: Record<Kind, string> = { goals: "/goals", artifacts: "/artifacts",
    previews: "/tool-previews", logs: "/tool-executions" };
  function live() { return scope.active && currentScope.current === scope; }
  function current(ticket: number) { return live() && scope.generation === ticket; }
  function clearHistory() {
    scope.generation++;
    scope.controller?.abort();
    scope.controller = null;
    scope.loading = false;
    setLoading(false);
    setHistory(empty());
    setPolicy(null);
  }
  async function refresh() {
    if (!live()) return;
    clearHistory();
    if (scope.writing) return;
    const ticket = scope.generation;
    const controller = new AbortController();
    scope.controller = controller;
    scope.loading = true;
    setLoading(true);
    setError("");
    try {
      const [g, a, p, l, t] = await Promise.all([
        list<Goal>(base + "/goals", controller.signal),
        list<Artifact>(base + "/artifacts", controller.signal),
        list<Preview>(base + "/tool-previews", controller.signal),
        list<Execution>(base + "/tool-executions", controller.signal),
        api<Policy>(base + "/tool-policy", "GET", undefined, undefined, controller.signal),
      ]);
      if (!current(ticket)) return;
      setHistory({ characterId: character.id, goals: g.items, artifacts: a.items,
        previews: p.items, logs: l.items, cursors: { goals: g.next_cursor ?? null,
          artifacts: a.next_cursor ?? null, previews: p.next_cursor ?? null, logs: l.next_cursor ?? null } });
      setPolicy(t);
    } catch (e) { if (current(ticket)) setError(errorText(e)); }
    finally {
      if (current(ticket)) { scope.loading = false; scope.controller = null; setLoading(false); }
    }
  }
  async function loadEarlier(kind: Kind) {
    const cursor = cursors[kind];
    if (!live() || scope.writing || scope.loading || !cursor) return;
    const ticket = ++scope.generation;
    const controller = new AbortController();
    scope.controller = controller;
    scope.loading = true;
    setLoading(true);
    setError("");
    try {
      const page = await list<Goal | Artifact | Preview | Execution>(
        base + paths[kind] + `?cursor=${encodeURIComponent(cursor)}`, controller.signal);
      if (!current(ticket)) return;
      setHistory(previous => {
        if (!current(ticket) || previous.characterId !== character.id) return previous;
        const seen = new Set(previous[kind].map(item => item.id));
        const additions = page.items.filter(item => {
          if (seen.has(item.id)) return false;
          seen.add(item.id); return true;
        });
        return { ...previous, [kind]: [...previous[kind], ...additions],
          cursors: { ...previous.cursors, [kind]: page.next_cursor ?? null } };
      });
    } catch (e) { if (current(ticket)) setError(errorText(e)); }
    finally {
      if (current(ticket)) { scope.loading = false; scope.controller = null; setLoading(false); }
    }
  }
  useEffect(() => {
    scope.active = true;
    setGoal(""); setBusy(false); setInfo("");
    pendingNote.current = null; pendingPreview.current = null;
    const stopped = () => { void refresh(); };
    window.addEventListener("fishlife:safety-changed", stopped);
    void refresh();
    return () => {
      scope.active = false; scope.generation++; scope.controller?.abort();
      window.removeEventListener("fishlife:safety-changed", stopped);
    };
  }, [character.id]);
  async function act(fn: () => Promise<void>) {
    if (!live() || scope.writing) return;
    clearHistory();
    scope.writing = true;
    setBusy(true); setError(""); setInfo("");
    try {
      await fn();
      if (!live()) return;
      scope.writing = false;
      await refresh();
    } catch (e) { if (live()) setError(errorText(e)); }
    finally { scope.writing = false; if (live()) setBusy(false); }
  }
  function earlier(kind: Kind, label: string) {
    return cursors[kind] && <button type="button" disabled={busy || loading}
      onClick={() => void loadEarlier(kind)}>{loading ? "正在加载…" : label}</button>;
  }
  function note(e: FormEvent) {
    e.preventDefault();
    void act(async () => {
      if (pendingNote.current?.goal !== goal)
        pendingNote.current = { goal, key: crypto.randomUUID() };
      const key = pendingNote.current.key;
      await api(
        base + "/tools/notes",
        "POST",
        { goal_id: goal, client_request_id: key },
        { "Idempotency-Key": key },
      );
      if (!live()) return;
      pendingNote.current = null;
      setInfo("笔记文件已写入并核验，可从下方下载。");
    });
  }
  function preview(e: FormEvent) {
    e.preventDefault();
    void act(async () => {
      const value = JSON.parse(payload);
      if (!value || Array.isArray(value) || typeof value !== "object")
        throw new Error("参数必须是JSON对象。");
      const body = JSON.stringify({ action, payload: value });
      if (pendingPreview.current?.body !== body)
        pendingPreview.current = { body, key: crypto.randomUUID() };
      const key = pendingPreview.current.key;
      await api(
        base + "/tool-previews",
        "POST",
        { action, payload: value, client_request_id: key },
        { "Idempotency-Key": key },
      );
      if (!live()) return;
      pendingPreview.current = null;
      setInfo("已保存预览。当前没有外部执行适配器，审批也不会触发发布或付款。");
    });
  }
  async function download(a: Artifact) {
    await act(async () => {
      const response = await fetch(a.download_url, {
        credentials: "same-origin",
      });
      if (!response.ok) {
        const body = await response.json().catch(() => null);
        throw new Error(
          body?.error?.message ?? `下载核验失败（${response.status}）`,
        );
      }
      const blob = await response.blob();
      if (!live()) return;
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `FishLife-${a.id}.md`;
      link.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      setInfo("已下载通过服务端核验的笔记。");
    });
  }
  return (
    <>
      <div className="page-heading">
        <div>
          <p className="eyebrow">VERIFIED TOOLS & SAFETY</p>
          <h1>每次行动，都有依据</h1>
        </div>
        <button disabled={busy} onClick={() => void act(async () => {})}>
          刷新
        </button>
      </div>
      <Notice>
        白名单只包含专用目录中的笔记导出。不执行任意文件、命令、浏览器操作或联网请求。
      </Notice>
      {error && <Notice error>{error}</Notice>}
      {info && <Notice>{info}</Notice>}
      <section className="life-controls">
        <div>
          <h2>{policy?.enabled ? "本地导出工具可用" : "本地导出工具已停止"}</h2>
          <p>
            只在你点击导出时生成文件。停止后拒绝新导出，已有文件仍需校验才能下载。
          </p>
        </div>
        <button
          className={policy?.enabled ? "danger" : "primary"}
          disabled={busy || !policy}
          onClick={() =>
            void act(async () => {
              await api(base + "/tool-policy", "PATCH", {
                enabled: !policy?.enabled,
              });
            })
          }
        >
          {policy?.enabled ? "停止新工具调用" : "允许本地导出"}
        </button>
      </section>
      <form className="settings-form" onSubmit={note}>
        <h2>导出资料笔记</h2>
        <label>
          已完成的目标
          <select
            value={goal}
            onChange={(e) => setGoal(e.target.value)}
            required
          >
            <option value="">选择一个已核验目标</option>
            {goals
              .filter((g) => g.status === "completed")
              .map((g) => (
                <option key={g.id} value={g.id}>
                  {g.title}
                </option>
              ))}
          </select>
        </label>
        {earlier("goals", "加载更早目标")}
        <button
          className="primary"
          disabled={busy || !goal || !policy?.enabled}
        >
          生成并核验 Markdown 文件
        </button>
        <p>
          先在“目标与活动”完成一次整理。文件路径由服务端生成，不覆盖你的现有文件。
        </p>
      </form>
      <h2>真实产物</h2>
      <div className="memory-grid">
        {artifacts.map((a) => (
          <article className="memory-card" key={a.id}>
            <span className="tag">{a.status}</span>
            <h3>资料笔记</h3>
            <p>
              {when(a.created_at)} · {a.byte_size} 字节
            </p>
            <details>
              <summary>查看核验指纹</summary>
              <p className="life-source">SHA-256：{a.sha256}</p>
            </details>
            <button
              disabled={busy || a.status !== "available"}
              onClick={() => void download(a)}
            >
              核验并下载
            </button>
          </article>
        ))}
        {!artifacts.length && (
          <p className="empty-state">
            没有导出产物。只有文件实际存在且读回核验成功，才会被记为完成。
          </p>
        )}
      </div>
      {earlier("artifacts", "加载更早产物")}
      <details className="technical-details">
        <summary>查看工具执行记录</summary>
        {logs.map((l) => (
          <p key={l.id}>
            {when(l.started_at)} · {l.tool_name ?? "本地导出"} · {l.status}{" "}
            {l.error_code ?? ""}
          </p>
        ))}
        {earlier("logs", "加载更早执行记录")}
      </details>
      <h2>外部操作预览</h2>
      <Notice>
        此处只检查预览与审批流程。当前没有外部执行接口，批准不会发送消息、发布内容、购买或删除文件。不要填写密钥或密码。
      </Notice>
      <form className="settings-form" onSubmit={preview}>
        <label>
          动作
          <select value={action} onChange={(e) => setAction(e.target.value)}>
            <option value="publish">公开发布</option>
            <option value="message">发送私信</option>
            <option value="purchase">购买</option>
            <option value="delete_files">删除文件</option>
            <option value="account_settings">修改账户设置</option>
          </select>
        </label>
        <label>
          完整动作参数（JSON）
          <textarea
            rows={5}
            value={payload}
            maxLength={6000}
            onChange={(e) => setPayload(e.target.value)}
            required
          />
        </label>
        <button disabled={busy}>保存预览，不执行</button>
      </form>
      <div className="memory-grid">
        {previews.map((p) => (
          <article className="memory-card" key={p.id}>
            <span className="tag">{p.status} · 外部执行未开放</span>
            <h3>{p.action}</h3>
            <pre className="life-result">
              {JSON.stringify(p.payload, null, 2)}
            </pre>
            <p>过期：{when(p.expires_at)}</p>
            <details>
              <summary>参数哈希</summary>
              <p className="life-source">{p.payload_hash}</p>
            </details>
            {p.status === "pending" && (
              <button
                disabled={busy}
                onClick={() =>
                  void act(async () => {
                    await api(`/tool-previews/${p.id}/approve`, "POST", {
                      payload_hash: p.payload_hash,
                    });
                    if (live()) setInfo("审批已记录；当前仍不会执行任何外部操作。");
                  })
                }
              >
                确认这些预览参数（不执行）
              </button>
            )}
          </article>
        ))}
      </div>
      {earlier("previews", "加载更早预览")}
      <Skills characterId={character.id} revision={`${policy?.enabled}:${artifacts.map(a => `${a.id}:${a.status}`).join(",")}`} />
    </>
  );
}
