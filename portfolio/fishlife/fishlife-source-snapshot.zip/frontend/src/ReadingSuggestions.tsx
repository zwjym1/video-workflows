import { useEffect, useRef, useState } from "react";
import { api, errorText } from "./api";
import { Notice } from "./components";

type Suggestion = { book_id: string; title: string; ordinal: number; source_hash: string;
  book_version: number; matched_interests: string[]; reason: string; action: string };
type Source = { ordinal: number; source_hash: string; content: string };

export function ReadingSuggestions({ characterId }: { characterId: string }) {
  const [items, setItems] = useState<Suggestion[]>([]);
  const [chosen, setChosen] = useState<Suggestion | null>(null);
  const [source, setSource] = useState<Source | null>(null);
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");
  const [busy, setBusy] = useState(false);
  const alive = useRef(true), ticket = useRef(0), lock = useRef(false);
  const pending = useRef<{identity: string; key: string} | null>(null);
  async function load(signal?: AbortSignal) {
    const current = ++ticket.current;
    const value = await api<{items: Suggestion[]}>(`/characters/${characterId}/reading-suggestions`, "GET", undefined, undefined, signal);
    if (alive.current && !signal?.aborted && current === ticket.current) setItems(value.items);
  }
  useEffect(() => {
    alive.current = true;
    const controller = new AbortController();
    void load(controller.signal).catch((e) => { if (!controller.signal.aborted) setError(errorText(e)); });
    const stopped = () => {
      ticket.current++; setChosen(null); setSource(null); setItems([]);
      void load(controller.signal).catch((e) => { if (!controller.signal.aborted) setError(errorText(e)); });
    };
    window.addEventListener("fishlife:safety-changed", stopped);
    return () => { alive.current = false; ticket.current++; controller.abort();
      window.removeEventListener("fishlife:safety-changed", stopped); };
  }, [characterId]);
  async function preview(item: Suggestion) {
    if (lock.current) return;
    const current = ++ticket.current;
    setChosen(item); setSource(null); setError(""); setInfo("");
    try {
      const value = await api<Source>(`/books/${item.book_id}/segments/${item.ordinal}`);
      if (!alive.current || current !== ticket.current) return;
      if (value.source_hash !== item.source_hash) throw new Error("资料已变化，请刷新建议。");
      setSource(value);
    } catch (e) { if (alive.current && current === ticket.current) setError(errorText(e)); }
  }
  async function confirm() {
    if (lock.current || !chosen || !source) return;
    lock.current = true; setBusy(true); setError("");
    const identity = `${chosen.book_id}:${chosen.book_version}:${chosen.ordinal}:${chosen.source_hash}`;
    if (pending.current?.identity !== identity) pending.current = {identity, key:crypto.randomUUID()};
    try {
      const result = await api<{status: string}>(`/books/${chosen.book_id}/suggested-reading`, "POST", {
        expected_version: chosen.book_version, ordinal: chosen.ordinal, source_hash: chosen.source_hash,
        acknowledgement: "确认处理这段本地资料",
      }, {"Idempotency-Key":pending.current.key});
      if (alive.current) {
        setInfo(["queued", "running", "retry_wait"].includes(result.status)
          ? "已受理本地阅读任务，完成情况可到书架查看；受理不代表已完成。"
          : `任务当前状态：${result.status}。没有自动创建新的请求。`);
        setChosen(null); setSource(null);
        await load();
      }
    } catch (e) { if (alive.current) setError(errorText(e) + "；网络不确定时重试沿用原请求标识。"); }
    finally { lock.current = false; if (alive.current) setBusy(false); }
  }
  return <section className="settings-form"><h2>可以接着做的小事</h2>
    <p>根据本地书架和兴趣词提出建议，最多3项。只在你确认后处理一段，不调用云端模型，不会自行开启站内活动。</p>
    {error && <Notice error>{error}</Notice>}{info && <Notice>{info}</Notice>}
    {!items.length && <p>暂无合适的阅读建议。先在书架放入资料；没有材料时保持安静。</p>}
    {items.map((item) => <article className="memory-card" key={item.book_id}>
      <h3>{item.title} · 第 {item.ordinal + 1} 段</h3><p>{item.reason}</p>
      <button disabled={busy} onClick={() => void preview(item)}>查看原文再决定</button>
    </article>)}
    {chosen && source && <article className="memory-card"><h3>确认范围</h3>
      <p className="life-source">{source.content}</p><small>原文 SHA256 {source.source_hash}</small>
      <p>只做本机摘录并保存进度，不代表理解整本书，也不会把原文写成你的个人经历。</p>
      <button disabled={busy} onClick={() => void confirm()}>确认处理这段本地资料</button>
      <button disabled={busy} onClick={() => { ticket.current++; setChosen(null); setSource(null); }}>暂时不做</button>
    </article>}
    <button disabled={busy} onClick={() => {
      ticket.current++; setChosen(null); setSource(null); setError("");
      void load().catch((e) => { if (alive.current) setError(errorText(e)); });
    }}>刷新建议</button>
  </section>;
}
