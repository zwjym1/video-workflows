import { useState, type FormEvent, type ReactNode } from "react";
import { api, errorText, setCsrf, type Auth } from "./api";
export function Notice({
  children,
  error = false,
}: {
  children: ReactNode;
  error?: boolean;
}) {
  return (
    <div
      className={`notice ${error ? "notice-error" : ""}`}
      role={error ? "alert" : "status"}
    >
      {children}
    </div>
  );
}
export function Portrait() {
  return (
    <div className="portrait" aria-hidden="true">
      <div className="fish">
        ◉<span>◁</span>
      </div>
      <i />
      <i />
      <i />
    </div>
  );
}
export function Login({ onLogin }: { onLogin: (auth: Auth) => void }) {
  const [username, setUsername] = useState("owner");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      const a = await api<Auth>("/auth/login", "POST", { username, password });
      setCsrf(a.csrf_token);
      setPassword("");
      onLogin(a);
    } catch (e) {
      setError(errorText(e));
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="login-layout">
      <section className="login-story">
        <a className="brand" href="/">
          ◌{" "}
          <span>
            FishLife<small>个人电子生命</small>
          </span>
        </a>
        <Portrait />
        <p className="eyebrow">A SPACE THAT REMEMBERS</p>
        <h1>
          让每一次相遇，
          <br />
          都有下文。
        </h1>
        <p>
          一个角色，一段持续的陪伴。
          <br />
          你可以查看、修正，也可以让它忘记。
        </p>
        <span className="muted-label">
          仅在本机运行 · 站内活动与分享需明确启用
        </span>
      </section>
      <section className="login-card">
        <p className="eyebrow">欢迎回来</p>
        <h2>回到你的空间</h2>
        <p className="muted">登录后继续你与伙伴的对话。</p>
        <form onSubmit={submit}>
          <label>
            用户名
            <input
              autoComplete="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
              maxLength={80}
            />
          </label>
          <label>
            密码
            <input
              type="password"
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </label>
          {error && <Notice error>{error}</Notice>}
          <button className="primary" disabled={busy}>
            {busy ? "正在登录…" : "进入 FishLife →"}
          </button>
        </form>
        <p className="small-help">
          首次运行需由本机管理员创建账号。初始化登录信息保存在“电子”项目的 work
          文件夹中，请妥善保存。
        </p>
      </section>
    </div>
  );
}
