import { useEffect, useRef, useState, type FormEvent } from "react";
import {
  api,
  list,
  errorText,
  when,
  type Character,
  type LifeEvent,
  type Runtime,
} from "./api";
import { Notice } from "./components";
import { UnresolvedCosts } from "./UnresolvedCosts";
import { modelMode } from "./model_mode";
import { personaText } from "./persona";

export function Timeline({ character }: { character: Character }) {
  const [events, setEvents] = useState<LifeEvent[]>([]);
  const [error, setError] = useState("");
  const [nextCursor, setNextCursor] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const pending = useRef<AbortController | null>(null);
  async function loadPage(controller: AbortController, cursor?: string) {
    setLoading(true); setError("");
    try {
      const query = cursor ? `?cursor=${encodeURIComponent(cursor)}` : "";
      const page = await list<LifeEvent>(`/characters/${character.id}/events${query}`, controller.signal);
      if (controller.signal.aborted) return;
      setEvents((old) => cursor ? [...old, ...page.items.filter((item) => !old.some((e) => e.id === item.id))] : page.items);
      setNextCursor(page.next_cursor ?? null);
    } catch (e) { if (!controller.signal.aborted) setError(errorText(e)); }
    finally { if (!controller.signal.aborted) setLoading(false); }
  }
  useEffect(() => {
    const c = new AbortController();
    pending.current = c;
    setEvents([]); setNextCursor(null);
    void loadPage(c);
    return () => c.abort();
  }, [character.id]);
  const names: Record<string, string> = {
    message_received: "收到你的消息",
    chat_completed: "完成一次回复",
    memory_created: "记录一条来源记忆",
    memory_corrected: "你修正了记忆",
    memory_deleted: "按你的要求清除记忆",
    character_created: "伙伴的故事开始了",
    activity_completed: "完成一次站内材料整理",
    local_activity_completed: "完成一次站内材料整理",
    goal_created: "保存一个目标",
    autonomy_changed: "站内活动开关已改变",
    reading_segment_processed: "核验并摘录一段本地阅读资料",
  };
  return (
    <>
      <div className="page-heading">
        <div>
          <p className="eyebrow">SHARED TIMELINE</p>
          <h1>一起留下的记录</h1>
        </div>
      </div>
      <p className="muted">
        这里只显示系统实际记录的事件。目标材料整理和来源日记可在“目标与活动”中查看。
      </p>
      {error && <Notice error>{error}</Notice>}
      <div className="timeline">
        {events.map((e) => (
          <article key={e.id}>
            <span className="timeline-dot" />
            <small>{when(e.occurred_at ?? e.created_at)}</small>
            <h3>{names[e.event_type] ?? e.event_type}</h3>
            <span className="tag">
              {e.reality_class === "user_claim" ? "用户陈述" : "系统记录"}
            </span>
          </article>
        ))}
        {!events.length && !loading && (
          <p className="empty-state">还没有新的经历，先从一次对话开始。</p>
        )}
      </div>
      {nextCursor && <button disabled={loading} onClick={() => {
        if (pending.current && !loading) void loadPage(pending.current, nextCursor);
      }}>{loading ? "正在读取…" : "加载更早记录"}</button>}
    </>
  );
}

export function SettingsPage({
  character,
  onChanged,
}: {
  character: Character;
  onChanged: (c: Character) => void;
}) {
  const [name, setName] = useState(character.name);
  const [identity, setIdentity] = useState(personaText(character.core_persona.identity));
  const [background, setBackground] = useState(personaText(character.core_persona.background));
  const [traits, setTraits] = useState(Array.isArray(character.core_persona.traits) ? character.core_persona.traits.filter((v) => typeof v === "string").join("、") : "");
  const [style, setStyle] = useState(
    String(character.core_persona.speaking_style ?? ""),
  );
  const [interests, setInterests] = useState(character.interests.join("、"));
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");
  const [busy, setBusy] = useState(false);
  async function save(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      onChanged(
        await api<Character>(
          `/characters/${character.id}`,
          "PATCH",
          {
            name,
            core_persona: { ...character.core_persona, identity, background,
              traits: traits.split(/[、,，]/).map((x) => x.trim()).filter(Boolean), speaking_style: style },
            interests: interests
              .split(/[、,，]/)
              .map((x) => x.trim())
              .filter(Boolean),
          },
          { "If-Match": String(character.version) },
        ),
      );
      setInfo("角色设定已保存。");
    } catch (e) {
      setError(errorText(e));
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <div className="page-heading">
        <div>
          <p className="eyebrow">CHARACTER SETTINGS</p>
          <h1>它是谁，由你定义</h1>
        </div>
      </div>
      <form className="settings-form" onSubmit={save}>
        <label>
          名字
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
            maxLength={80}
          />
        </label>
        <label>
          身份与定位
          <textarea value={identity} onChange={(e) => setIdentity(e.target.value)} maxLength={500} rows={2} />
        </label>
        <label>
          性格
          <input value={traits} onChange={(e) => setTraits(e.target.value)} maxLength={300} placeholder="用顿号分隔" />
        </label>
        <label>
          角色背景（虚构设定）
          <textarea value={background} onChange={(e) => setBackground(e.target.value)} maxLength={1500} rows={4} />
        </label>
        <label>
          说话风格
          <textarea
            value={style}
            onChange={(e) => setStyle(e.target.value)}
            rows={3}
            maxLength={2000}
          />
        </label>
        <label>
          兴趣
          <input
            value={interests}
            onChange={(e) => setInterests(e.target.value)}
            placeholder="用顿号或逗号分隔"
          />
          <small>本地活动会在有限候选内，同优先级优先选择标题包含这些兴趣词的目标；不会因此自动生成任务或扩大权限。</small>
        </label>
        <p className="muted">
          角色背景是虚构设定，不会作为已经发生的真实经历写入记忆。
        </p>
        {error && <Notice error>{error}</Notice>}
        {info && <Notice>{info}</Notice>}
        <button className="primary" disabled={busy}>
          {busy ? "正在保存…" : "保存设定"}
        </button>
      </form>
      <Notice>
        站内活动需在“目标与活动”中明确启用，站内分享由陪伴偏好控制；没有外部发布、私信或购买工具。
      </Notice>
    </>
  );
}

export function StatusPage() {
  const [r, setR] = useState<Runtime | null>(null);
  const [cost, setCost] = useState<Record<string, unknown> | null>(null);
  const [daily, setDaily] = useState("");
  const [monthly, setMonthly] = useState("");
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState("");
  const [error, setError] = useState("");
  useEffect(() => {
    void Promise.all([
      api<Runtime>("/runtime/status"),
      api<Record<string, unknown>>("/costs/summary"),
    ])
      .then(([a, b]) => {
        setR(a);
        setCost(b);
        setDaily(String(b.limit));
        setMonthly(String(b.monthly_limit));
      })
      .catch((e) => setError(errorText(e)));
  }, []);
  async function saveBudget(event: FormEvent) {
    event.preventDefault();
    if (!cost || saving) return;
    setSaving(true); setError(""); setSaved("");
    try {
      await api("/costs/limits", "PATCH", {
        daily_limit: daily, monthly_limit: monthly,
        expected_daily_limit: cost.limit, expected_monthly_limit: cost.monthly_limit,
      });
      const next = await api<Record<string, unknown>>("/costs/summary");
      setCost(next); setDaily(String(next.limit)); setMonthly(String(next.monthly_limit));
      setSaved("预算已保存；已发生及预占费用保留，已受理的调用可能继续完成。");
    } catch (e) { setError(errorText(e)); }
    finally { setSaving(false); }
  }
  return (
    <>
      <div className="page-heading">
        <div>
          <p className="eyebrow">SYSTEM & COST</p>
          <h1>看得见的运行状态</h1>
        </div>
      </div>
      {error && <Notice error>{error}</Notice>}
      <section className="status-grid">
        <article>
          <p className="eyebrow">模型与权限</p>
          <h3>
            {r ? modelMode(r.model_provider) : "读取中…"}
          </h3>
          <p>版本 {r?.app_version ?? "读取中"} · 阶段 {r?.stage ?? "读取中"}</p>
          <p>站内活动与分享需明确启用 · 无外部推送</p>
          <p>已实现能力不等于执行授权；具体操作仍受开关和来源核验约束。</p>
          {r?.capabilities && <details><summary>查看能力与限制</summary>
            {Object.entries({
              sourced_memory: "带来源记忆", autobiography: "阶段自传摘要",
              experience_catalog: "经验档案", multi_character: "多角色管理",
              web_reader: "白名单网页工具", vector_retrieval: "语义向量检索",
              model_planning: "模型自主规划", external_execution: "外部平台执行",
              local_reading: "本地文本分段与来源摘录",
              server_tts: "服务器语音", live2d: "Live2D形象", three_d: "3D形象",
            }).map(([key, label]) => <p key={key}>{label}：{r.capabilities?.[key] ? "已实现" : "尚未实现或接通"}</p>)}
            <p>当前自主活动采用本地有限流程，伙伴交流采用明确标注的两轮模板。外部连通性需要单独验证。</p>
          </details>}
        </article>
        <article>
          <p className="eyebrow">费用记录</p>
          <h3>
            {cost
              ? `累计已结算 $${Number(cost.spent ?? 0).toFixed(4)}`
              : "读取中…"}
          </h3>
          {cost && (
            <p>待结算预占 ${Number(cost.reserved ?? 0).toFixed(4)} · 美元</p>
          )}
          {cost && Number(cost.unknown_count ?? 0) > 0 && (
            <Notice>
              有 {Number(cost.unknown_count)} 笔调用的费用结果不确定，
              其中 ${Number(cost.unknown_reserved ?? 0).toFixed(4)} 仍占用预算。
              请核对供应商账单；重复请求可能再次收费。
            </Notice>
          )}
          {cost && <p>正常等待结算：{Number(cost.pending_count ?? 0)} 笔。</p>}
          {cost && (
            <p>
              每日上限 ${String(cost.limit)} · 每月上限 $
              {String(cost.monthly_limit)}
            </p>
          )}
          <p>{r?.model_provider === "codex"
            ? "GPT 使用 Codex 订阅额度；美元预占只是本机风险限额，不是供应商报价。订阅调用不按零美元结算，令牌用量与未知金额分别保留。"
            : r?.model_provider === "qoder"
            ? "Qoder 采用实时免费状态检查；零金额回执仍保留待核对预占，不代表账单已核实。"
            : "模拟调用费用为零；真实模型必须配置凭据、价格和预算才能启用。"}</p>
          {cost && <form onSubmit={(e) => void saveBudget(e)}>
            <label>每日上限（美元）<input type="number" min="0" max="1000" step="0.00000001"
              required value={daily} onChange={(e) => setDaily(e.target.value)} disabled={saving} /></label>
            <label>每月上限（美元）<input type="number" min="0" max="10000" step="0.00000001"
              required value={monthly} onChange={(e) => setMonthly(e.target.value)} disabled={saving} /></label>
            <button disabled={saving}>{saving ? "正在保存…" : "保存预算"}</button>
            <p>上限为零可阻止新的收费预占；调整预算不会取消已受理调用。需要停止自主工具时请使用安全停止开关。</p>
          </form>}
          {saved && <Notice>{saved}</Notice>}
        </article>
      </section>
      <UnresolvedCosts onSettled={() => {
        void api<Record<string, unknown>>("/costs/summary").then(setCost)
          .catch(e => setError(errorText(e)));
      }} />
      {r && (
        <details className="technical-details">
          <summary>查看运行明细</summary>
          <pre>{JSON.stringify(r, null, 2)}</pre>
        </details>
      )}
      {cost && (
        <details className="technical-details">
          <summary>查看费用明细</summary>
          <pre>{JSON.stringify(cost, null, 2)}</pre>
        </details>
      )}
    </>
  );
}
