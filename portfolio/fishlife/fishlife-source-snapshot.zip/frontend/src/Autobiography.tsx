import { useEffect, useRef, useState } from "react";
import { api, errorText, when } from "./api";
import { Notice } from "./components";
import { createLatestReadGate } from "./latest_read";

type Snapshot = {
  id: string;
  status: "active" | "invalidated" | "deleted";
  created_at: string;
  segments: {
    text: string;
    reality_class: "user_claim" | "observed";
    occurred_at: string;
    source: { kind: "memory" | "event"; id: string; message_ids: string[]; event_ids: string[] };
  }[];
};

export function Autobiography({ characterId, revision }: { characterId: string; revision: string }) {
  const [items, setItems] = useState<Snapshot[]>([]);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [confirm, setConfirm] = useState<string | null>(null);
  const gate = useRef(createLatestReadGate());
  async function load(signal?: AbortSignal) {
    const ticket = gate.current.begin();
    if (ticket === null) return;
    try {
      const result = await api<{ items: Snapshot[] }>(
        `/characters/${characterId}/autobiographies`, "GET", undefined, undefined, signal,
      );
      if (!gate.current.current(ticket)) return;
      setItems(result.items);
      setError("");
    } catch (e) {
      if (!gate.current.current(ticket)) return;
      setItems([]);
      setError(errorText(e));
    }
  }
  useEffect(() => {
    const controller = new AbortController();
    void load(controller.signal);
    const timer = window.setInterval(() => {
      if (document.visibilityState === "visible") void load(controller.signal);
    }, 15000);
    return () => { gate.current.invalidate(); controller.abort(); window.clearInterval(timer); };
  }, [characterId, revision]);
  async function mutate(id?: string) {
    gate.current.pause();
    setItems([]);
    setBusy(true);
    setError("");
    try {
      if (id) await api(`/autobiographies/${id}`, "DELETE");
      else await api(`/characters/${characterId}/autobiographies`, "POST", {});
      setConfirm(null);
      gate.current.resume();
      await load();
    } catch (e) { gate.current.resume(); setError(errorText(e)); }
    finally { setBusy(false); }
  }
  return <section className="panel" aria-label="阶段自传摘要">
    <h2>共同经历的阶段摘要</h2>
    <p className="muted">只整理已有事实与核验活动；没有来源时保持空白，不编造生活。每次最多25条事实与25次活动，显示最近20份。</p>
    <p className="muted">来源纠错、删除、冲突或到期后，摘要失效。这里是来源整理，不是模型反思；不会自动送入聊天。</p>
    {error && <Notice error>{error}</Notice>}
    <div className="card-actions">
      <button disabled={busy} onClick={() => void mutate()}>生成当前阶段摘要</button>
      <button disabled={busy} onClick={() => void load()}>刷新来源状态</button>
    </div>
    {!items.length && <p className="muted">还没有阶段摘要。</p>}
    {items.map(item => <article className="card" key={item.id}>
      <h3>{when(item.created_at)} · {item.status === "active" ? "来源有效" : "来源已变化，摘要失效"}</h3>
      {item.status !== "active" && <p>旧内容已隐藏，可以基于当前有效来源生成新摘要。</p>}
      {item.segments.map(segment => <div key={segment.source.kind + segment.source.id}>
        <p>{segment.text}</p>
        <details><summary>{segment.reality_class === "user_claim" ? "用户陈述来源" : "实际执行证据"}</summary>
          <p>{when(segment.occurred_at)} · {segment.source.kind === "memory" ? "记忆" : "事件"} {segment.source.id}</p>
          {segment.source.message_ids.map(id => <p key={id}>消息 {id}</p>)}
          {segment.source.event_ids.map(id => <p key={id}>事件 {id}</p>)}
        </details>
      </div>)}
      {confirm === item.id ? <div className="card-actions">
        <span>只删除这份摘要记录，保留原事实与活动。</span>
        <button disabled={busy} onClick={() => setConfirm(null)}>取消</button>
        <button className="danger" disabled={busy} onClick={() => void mutate(item.id)}>确认删除摘要</button>
      </div> : <button disabled={busy} onClick={() => setConfirm(item.id)}>删除这份摘要</button>}
    </article>)}
  </section>;
}
