import { useEffect, useRef, useState, type FormEvent } from "react";
import { api, list, errorText, when, type Character } from "./api";
import { Notice } from "./components";
type Exchange = {
  id: string;
  from_character_id: string;
  to_character_id: string;
  topic: string;
  status: string;
  created_at: string;
  messages: { speaker_character_id: string; body: string; seq: number }[];
};
export function World({
  character,
  characters,
  onCreated,
}: {
  character: Character | null;
  characters: Character[];
  onCreated: (c: Character) => void;
}) {
  const [name, setName] = useState(""),
    [style, setStyle] = useState("温和、好奇，明确区分角色扮演与真实记录"),
    [to, setTo] = useState(""),
    [topic, setTopic] = useState(""),
    [items, setItems] = useState<Exchange[]>([]),
    [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  const pending = useRef<{ body: string; key: string } | null>(null);
  const [deleting, setDeleting] = useState<Exchange | null>(null);
  async function load(signal?: AbortSignal) {
    if (!character) return;
    const r = await list<Exchange>(
      `/characters/${character.id}/exchanges`,
      signal,
    );
    if (!signal?.aborted) setItems(r.items);
  }
  useEffect(() => {
    const c = new AbortController();
    setItems([]);
    void load(c.signal).catch((e) => {
      if (!c.signal.aborted) setError(errorText(e));
    });
    return () => c.abort();
  }, [character?.id]);
  async function create(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      const c = await api<Character>("/characters", "POST", {
        name,
        core_persona: {
          speaking_style: style,
          background: "用户创建的虚构角色设定",
        },
        interests: [],
      });
      setName("");
      onCreated(c);
    } catch (e) {
      setError(errorText(e));
    } finally {
      setBusy(false);
    }
  }
  async function exchange(e: FormEvent) {
    e.preventDefault();
    if (!character) return;
    setBusy(true);
    setError("");
    try {
      const body = JSON.stringify({
        from_character_id: character.id,
        to_character_id: to,
        topic,
      });
      if (pending.current?.body !== body)
        pending.current = { body, key: crypto.randomUUID() };
      const key = pending.current.key;
      await api(
        "/character-exchanges",
        "POST",
        { ...JSON.parse(body), client_request_id: key },
        { "Idempotency-Key": key },
      );
      pending.current = null;
      setTopic("");
      await load();
    } catch (e) {
      setError(errorText(e));
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <div className="page-heading">
        <div>
          <p className="eyebrow">A SMALL SHARED WORLD</p>
          <h1>不同伙伴，各有自己的故事</h1>
        </div>
      </div>
      <Notice>
        每个角色的聊天和记忆独立。这里的交流由你明确发起，固定一问一答，标记为模板角色扮演，不读取你的私人记忆，不自动互相唤醒。
      </Notice>
      {error && <Notice error>{error}</Notice>}
      <div className="life-columns">
        <form className="settings-form" onSubmit={create}>
          <h2>添加伙伴（最多 5 位）</h2>
          <label>
            名字
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
              maxLength={80}
            />
          </label>
          <label>
            说话风格
            <textarea
              value={style}
              onChange={(e) => setStyle(e.target.value)}
              required
              maxLength={1000}
              rows={3}
            />
          </label>
          <button disabled={busy || characters.length >= 5 || !name.trim()}>
            创建独立角色
          </button>
        </form>
        {character && (
          <form className="settings-form" onSubmit={exchange}>
            <h2>让{character.name}交流一次</h2>
            <label>
              对方
              <select
                value={to}
                onChange={(e) => setTo(e.target.value)}
                required
              >
                <option value="">选择另一位伙伴</option>
                {characters
                  .filter((c) => c.id !== character.id)
                  .map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
              </select>
            </label>
            <label>
              话题
              <textarea
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                required
                rows={3}
                maxLength={1000}
              />
            </label>
            <p>需先启用站内活动；全局停止后不能发起新交流。</p>
            <button className="primary" disabled={busy || !to || !topic.trim()}>
              发起一次有限角色扮演
            </button>
          </form>
        )}
      </div>
      <h2>保存的交流</h2>
      <div className="memory-grid">
        {items.map((x) => (
          <article className="memory-card" key={x.id}>
            <span className="tag">模板角色扮演 · 不写事实记忆</span>
            <small>{when(x.created_at)}</small>
            <h3>{x.topic}</h3>
            {x.messages?.map((m) => (
              <blockquote key={m.seq}>
                <strong>
                  {characters.find((c) => c.id === m.speaker_character_id)
                    ?.name ?? "伙伴"}
                </strong>
                <p>{m.body}</p>
              </blockquote>
            ))}
            <button
              className="danger"
              disabled={busy}
              onClick={() => setDeleting(x)}
            >
              清除这次交流
            </button>
          </article>
        ))}
        {!items.length && (
          <p className="empty-state">
            还没有交流记录。角色不会为了热闹无限对话。
          </p>
        )}
      </div>
      {deleting && (
        <div className="modal-scrim">
          <section
            className="modal"
            role="dialog"
            aria-modal="true"
            aria-label="清除角色交流"
          >
            <h2>清除这次交流</h2>
            <p>
              将清除话题和双方交流正文，保留无原文审计记录；此操作无法在页面撤销，历史备份仍需单独管理。
            </p>
            {error && <Notice error>{error}</Notice>}
            <div className="card-actions">
              <button disabled={busy} onClick={() => setDeleting(null)}>
                保留
              </button>
              <button
                className="danger"
                disabled={busy}
                onClick={() => {
                  void (async () => {
                    setBusy(true);
                    setError("");
                    try {
                      await api(
                        `/character-exchanges/${deleting.id}`,
                        "DELETE",
                      );
                      setDeleting(null);
                      await load();
                    } catch (e) {
                      setError(errorText(e));
                    } finally {
                      setBusy(false);
                    }
                  })();
                }}
              >
                确认清除交流正文
              </button>
            </div>
          </section>
        </div>
      )}
    </>
  );
}
