import { useEffect, useRef, useState } from "react";
import { api, errorText, when } from "./api";
import { Notice } from "./components";
import { QoderSettlementForm } from "./QoderSettlementForm";

type UnresolvedCost = {
  id: string;
  created_at: string;
  provider: string;
  model: string;
  reservation_id: string;
  run_id: string;
  estimated_cost_usd: string | number;
  provider_request_id: string | null;
  qoder_report: null | {
    request_id: string;
    session_id: string;
    reported_cost_usd: string | number;
    reported_credits: string | number | null;
    verification_status: "unverified";
    reported_at: string;
  };
};
type Page = { items: UnresolvedCost[]; next_cursor: string | null };

export function UnresolvedCosts({ onSettled }: { onSettled: () => void }) {
  const [items, setItems] = useState<UnresolvedCost[]>([]);
  const [cursor, setCursor] = useState<string | null>(null);
  const [opened, setOpened] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [confirmation, setConfirmation] = useState("");
  const pending = useRef<AbortController | null>(null);
  useEffect(() => () => {
    pending.current?.abort();
    pending.current = null;
  }, []);

  async function load(next?: string) {
    if (next && pending.current) return;
    pending.current?.abort();
    const request = new AbortController();
    pending.current = request;
    setOpened(true); setLoading(true); setError("");
    if (!next) { setItems([]); setCursor(null); }
    try {
      const query = next ? `&cursor=${encodeURIComponent(next)}` : "";
      const page = await api<Page>(`/costs/unresolved?limit=20${query}`, "GET",
        undefined, undefined, request.signal);
      if (pending.current !== request || request.signal.aborted) return;
      setItems(previous => next ? [...previous, ...page.items] : page.items);
      setCursor(page.next_cursor);
    } catch (e) {
      if (pending.current === request && !request.signal.aborted) setError(errorText(e));
    } finally {
      if (pending.current === request) { pending.current = null; setLoading(false); }
    }
  }

  return <section aria-label="待核对费用明细">
    <h2>待核对的调用</h2>
    <p>这里显示当前账号的未结算记录。预算预占不是已扣费用，未知金额也不代表零。
      请结合供应商账单核对；查看记录不会解除阻断或重发请求。</p>
    <button onClick={() => void load()} disabled={loading}>
      {opened ? "刷新待核对记录" : "查看待核对记录"}
    </button>
    {error && <Notice error>{error}</Notice>}
    {confirmation && <Notice>{confirmation}</Notice>}
    {loading && <p role="status">正在读取…</p>}
    {opened && !loading && !error && items.length === 0 && <p>当前账号没有待核对费用记录。</p>}
    {items.map(item => <article key={item.id} className="journal-entry">
      <h3>{item.model} · 费用待核对</h3>
      <p>{when(item.created_at)} · {item.provider}</p>
      <p>预算预占 ${String(item.estimated_cost_usd)} 美元，实际扣费未确认。</p>
      {item.provider === "codex" && <p>这是 Codex 订阅调用。本机预占是风险限额，不是 OpenAI 报价或已扣美元；订阅额度消耗不能换算成零费用。此处不提供 Qoder 账单结算操作。</p>}
      {item.qoder_report ? <>
        <p>供应商报告（尚未核实）：${String(item.qoder_report.reported_cost_usd)} 美元；
          Credits：{item.qoder_report.reported_credits === null
            ? "未提供" : String(item.qoder_report.reported_credits)}。</p>
        <p>报告金额不作为结算依据，Credits 不换算为美元。</p>
      </> : <p>没有可用的供应商用量报告。</p>}
      <details><summary>查看账单核对标识</summary>
        <p>预留记录：{item.reservation_id}</p>
        <p>任务运行：{item.run_id}</p>
        <p>请求：{item.qoder_report?.request_id ?? item.provider_request_id ?? "未取得"}</p>
        {item.qoder_report && <p>会话：{item.qoder_report.session_id}</p>}
      </details>
      {item.provider === "qoder" && <QoderSettlementForm reservation={item.reservation_id}
        reserved={item.estimated_cost_usd} onSettled={() => {
          setConfirmation("已保存用户人工确认，原始报告保留；模型开关没有改变。");
          onSettled(); void load();
        }} />}
    </article>)}
    {cursor && <button disabled={loading} onClick={() => void load(cursor)}>加载更早记录</button>}
  </section>;
}
