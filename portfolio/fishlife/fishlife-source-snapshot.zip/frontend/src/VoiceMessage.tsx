import {useEffect, useRef, useState} from "react";
import {errorText, messageAudio} from "./api";

export function VoiceMessage({messageId, text}: {messageId:string; text:string}) {
  const [url, setUrl] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const current = useRef<AbortController | null>(null);
  const objectUrl = useRef("");
  const player = useRef<HTMLAudioElement>(null);
  useEffect(() => {
    function clear() {
      current.current?.abort();current.current=null;
      player.current?.pause();
      if(objectUrl.current) URL.revokeObjectURL(objectUrl.current);
      objectUrl.current="";setUrl("");setBusy(false);
    }
    window.addEventListener("fishlife:safety-changed",clear);
    window.addEventListener("fishlife:unauthorized",clear);
    return () => {clear();window.removeEventListener("fishlife:safety-changed",clear);window.removeEventListener("fishlife:unauthorized",clear);};
  },[messageId,text]);
  async function generate() {
    if(current.current) return;
    const controller = new AbortController();current.current=controller;
    setBusy(true);setError("");
    try {
      const blob=await messageAudio(messageId,controller.signal);
      if(controller.signal.aborted || current.current!==controller) return;
      const next=URL.createObjectURL(blob);
      if(objectUrl.current) URL.revokeObjectURL(objectUrl.current);
      objectUrl.current=next;setUrl(next);
    } catch(e) {if(!controller.signal.aborted)setError(errorText(e));}
    finally {if(current.current===controller){current.current=null;setBusy(false);}}
  }
  return <div className="card-actions">
    {!url && <button type="button" disabled={busy || [...text].length>500} onClick={() => void generate()}>{busy ? "正在本机生成语音…" : "生成语音消息"}</button>}
    {[...text].length>500 && <small>这条回复较长，语音目前支持500字以内。</small>}
    {url && <><audio ref={player} controls preload="metadata" src={url} aria-label="大肥鱼语音消息"/><a href={url} download="大肥鱼语音.wav">保存语音</a></>}
    {error && <small role="alert">{error}</small>}
  </div>;
}
