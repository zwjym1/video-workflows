import { Component, type ReactNode } from "react";
export class ErrorBoundary extends Component<
  { children: ReactNode },
  { failed: boolean }
> {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  render() {
    if (this.state.failed)
      return (
        <main className="settings-form">
          <h1>页面遇到了一点问题</h1>
          <p>
            已经保存到服务器的记录仍会保留。请重新打开页面；如果再次出现，请查看运行日志。
          </p>
          <button onClick={() => window.location.reload()}>重新打开</button>
        </main>
      );
    return this.props.children;
  }
}
