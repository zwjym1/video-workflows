import { useEffect, useState } from "react";

/** Time spent waiting in this mounted view, not a provider ETA or task age. */
export function useWaitingSeconds(active: boolean, identity: string) {
  const [seconds, setSeconds] = useState(0);
  useEffect(() => {
    setSeconds(0);
    if (!active) return;
    const started = Date.now();
    const timer = window.setInterval(() => setSeconds(Math.max(0, Math.floor((Date.now() - started) / 1000))), 1000);
    return () => window.clearInterval(timer);
  }, [active, identity]);
  return seconds;
}
