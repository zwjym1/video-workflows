import { useEffect, useRef, useState } from "react";
import { api, ApiError, errorText, when } from "./api";
import { Notice } from "./components";

type Policy = {
  enabled: boolean;
  capability_enabled: boolean;
  daily_limit: number;
  version: number;
  local_day: string | null;
  calls_today: number;
  quiet_until: string | null;
};

export function PlanningPolicy({ characterId }: { characterId: string }) {
  const [policy, setPolicy] = useState<Policy | null>(null);
  const [consent, setConsent] = useState(false);
  const [limit, setLimit] = useState(4);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const alive = useRef(true);
  const path = `/characters/${characterId}/planning-policy`;
  useEffect(() => {
    alive.current = true;
    const controller = new AbortController();
    void api<Policy>(path, "GET", undefined, undefined, controller.signal)
      .then((value) => {
        if (!controller.signal.aborted) {
          setPolicy(value);
          setLimit(value.daily_limit);
        }
      })
      .catch((e) => {
        if (!controller.signal.aborted) {
          setError(e instanceof ApiError && e.status === 404
            ? "当前服务版本尚未开放模型选择。" : errorText(e));
        }
      });
    return () => { alive.current = false; controller.abort(); };
  }, [path]);

  async function save(enabled: boolean) {
    if (!policy || busy) return;
    setBusy(true); setError("");
    try {
      const value = await api<Policy>(path, "PATCH", {
        enabled, daily_limit: limit, expected_version: policy.version,
        ...(enabled ? {
          cloud_title_consent: "允许将候选目标标题发送给Qoder进行选择",
        } : {}),
      });
      if (alive.current) { setPolicy(value); setConsent(false); }
    } catch (e) {
      if (e instanceof ApiError && e.code === "PLANNING_POLICY_CHANGED") {
        try {
          const latest = await api<Policy>(path);
          if (alive.current) {
            setPolicy(latest); setLimit(latest.daily_limit); setConsent(false);
            setError("设置或使用次数已变化，已刷新。请核对后重新保存。");
          }
        } catch {
          if (alive.current) setError(errorText(e));
        }
      } else if (alive.current) setError(errorText(e));
    } finally {
      if (alive.current) setBusy(false);
    }
  }

  return <section className="settings-form planning-policy">
    <h2>让她选择下一件事</h2>
    <p>开启后，最多把三个候选目标的标题发给 Qoder，让她选择一个或保持安静。
      目标材料和聊天记忆不随这次选择发送；执行结果仍由本地程序核验。</p>
    <p>调用可能消耗模型额度。即使回执显示免费，未核实的费用记录也会保留。</p>
    {error && <Notice error>{error}</Notice>}
    {policy && <>
      <p>{policy.enabled ? "此角色已允许模型选择" : "此角色尚未开启模型选择"}
        {!policy.capability_enabled && "；服务端能力尚未开放"}</p>
      <label>每日最多选择次数（1–8）
        <input type="number" min={1} max={8} step={1} value={limit}
          disabled={busy || !policy.capability_enabled}
          onChange={(e) => setLimit(Number(e.target.value))} />
      </label>
      <p>记录日期：{policy.local_day ?? "尚无调用"}；已记录 {policy.calls_today} 次。
        {policy.quiet_until && ` 静默至 ${when(policy.quiet_until)}。`}</p>
      <label className="planning-consent"><input type="checkbox" checked={consent}
        disabled={busy || !policy.capability_enabled}
        onChange={(e) => setConsent(e.target.checked)} />
        我允许把候选目标标题发送给 Qoder，按此上限选择活动。</label>
      <div className="card-actions">
        <button disabled={busy || !policy.capability_enabled || !consent ||
          !Number.isInteger(limit) || limit < 1 || limit > 8}
          onClick={() => void save(true)}>{busy ? "保存中…" : "允许并保存上限"}</button>
        <button disabled={busy || !policy.enabled}
          onClick={() => void save(false)}>关闭模型选择</button>
      </div>
    </>}
  </section>;
}
