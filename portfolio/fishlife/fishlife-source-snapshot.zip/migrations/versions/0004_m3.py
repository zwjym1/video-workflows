"""Verified local artifacts and non-executing approval previews."""

from alembic import op

revision = "0004_m3"
down_revision = "0003_m2"
branch_labels = None
depends_on = None

SCHEMA = """
ALTER TABLE character_states ADD COLUMN tools_enabled boolean NOT NULL DEFAULT true;
CREATE TABLE tool_execution_logs (
 id uuid PRIMARY KEY,owner_id uuid NOT NULL,character_id uuid NOT NULL,goal_id uuid NOT NULL,
 tool_name text NOT NULL CHECK(tool_name='local_note'),request_key uuid NOT NULL,
 status text NOT NULL CHECK(status IN ('running','succeeded','failed','unknown')),
 error_code text,started_at timestamptz NOT NULL DEFAULT now(),finished_at timestamptz,
 FOREIGN KEY(owner_id,character_id,goal_id) REFERENCES goals(owner_id,character_id,id),
 UNIQUE(owner_id,request_key),UNIQUE(owner_id,character_id,id)
);
CREATE TABLE artifacts (
 id uuid PRIMARY KEY,owner_id uuid NOT NULL,character_id uuid NOT NULL,goal_id uuid NOT NULL,
 execution_id uuid NOT NULL,sha256 varchar(64) NOT NULL,byte_size integer NOT NULL
 CHECK(byte_size BETWEEN 1 AND 100000),status text NOT NULL DEFAULT 'available'
 CHECK(status IN ('available','invalidated')),created_at timestamptz NOT NULL DEFAULT now(),
 FOREIGN KEY(owner_id,character_id,goal_id) REFERENCES goals(owner_id,character_id,id),
 FOREIGN KEY(owner_id,character_id,execution_id)
 REFERENCES tool_execution_logs(owner_id,character_id,id),UNIQUE(execution_id)
);
CREATE INDEX ix_artifacts_owner ON artifacts(owner_id,character_id,created_at DESC);
CREATE TABLE tool_previews (
 id uuid PRIMARY KEY,owner_id uuid NOT NULL,character_id uuid NOT NULL,request_key uuid NOT NULL,
 action text NOT NULL CHECK(action IN ('publish','message','purchase','delete_files',
 'account_settings')),payload jsonb NOT NULL,payload_hash varchar(64) NOT NULL,
 status text NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved')),
 expires_at timestamptz NOT NULL,approved_at timestamptz,
 created_at timestamptz NOT NULL DEFAULT now(),
 FOREIGN KEY(owner_id,character_id) REFERENCES characters(owner_id,id),UNIQUE(owner_id,request_key)
);
GRANT SELECT,INSERT,UPDATE,DELETE ON tool_execution_logs,artifacts,tool_previews TO fishlife_app;
"""


def upgrade() -> None:
    for statement in SCHEMA.split(";"):
        if statement.strip():
            op.execute(statement)


def downgrade() -> None:
    raise RuntimeError("M3 has private artifacts; restore an audited backup instead")
