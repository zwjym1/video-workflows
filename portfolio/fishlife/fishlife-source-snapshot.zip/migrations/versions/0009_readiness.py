"""Allow the application to read migration metadata without modifying it."""

from alembic import op

revision = "0009_readiness"
down_revision = "0008_autobiography"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute("GRANT SELECT ON public.alembic_version TO fishlife_app")


def downgrade() -> None:
    op.execute("REVOKE SELECT ON public.alembic_version FROM fishlife_app")
