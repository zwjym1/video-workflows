"""Bounded same-owner character exchanges and optional presentation contracts."""

from alembic import op

revision = "0006_m5"
down_revision = "0005_m4"
branch_labels = None
depends_on = None

SCHEMA = """
DROP INDEX one_enabled_character;
ALTER TABLE users ADD COLUMN tools_paused boolean NOT NULL DEFAULT false;
CREATE TABLE character_exchanges (
 id uuid PRIMARY KEY,owner_id uuid NOT NULL,from_character_id uuid NOT NULL,
 to_character_id uuid NOT NULL,request_key uuid NOT NULL,request_hash varchar(64) NOT NULL,
 topic text NOT NULL,messages jsonb NOT NULL,status text NOT NULL DEFAULT 'completed'
 CHECK(status IN ('completed','deleted')),created_at timestamptz NOT NULL DEFAULT now(),
 CHECK(from_character_id<>to_character_id),
 FOREIGN KEY(owner_id,from_character_id) REFERENCES characters(owner_id,id),
 FOREIGN KEY(owner_id,to_character_id) REFERENCES characters(owner_id,id),
 UNIQUE(owner_id,request_key)
);
CREATE INDEX ix_exchanges_owner_time ON character_exchanges(owner_id,created_at DESC);
CREATE TABLE relationships (
 owner_id uuid NOT NULL,low_character_id uuid NOT NULL,high_character_id uuid NOT NULL,
 exchange_count integer NOT NULL DEFAULT 0 CHECK(exchange_count>=0),last_exchange_at timestamptz,
 PRIMARY KEY(owner_id,low_character_id,high_character_id),
 CHECK(low_character_id<high_character_id),
 FOREIGN KEY(owner_id,low_character_id) REFERENCES characters(owner_id,id),
 FOREIGN KEY(owner_id,high_character_id) REFERENCES characters(owner_id,id)
);
GRANT SELECT,INSERT,UPDATE,DELETE ON character_exchanges,relationships TO fishlife_app;
"""


def upgrade() -> None:
    for statement in SCHEMA.split(";"):
        if statement.strip():
            op.execute(statement)


def downgrade() -> None:
    raise RuntimeError("M5 includes private exchanges; restore an audited backup instead")
