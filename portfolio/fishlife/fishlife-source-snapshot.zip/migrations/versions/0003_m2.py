"""Bounded local activity, goals, schedules and sourced journals."""
from alembic import op

revision = "0003_m2"
down_revision = "0002_m1"
branch_labels = None
depends_on = None

SCHEMA = """
CREATE TABLE goals (
 id uuid PRIMARY KEY,owner_id uuid NOT NULL,character_id uuid NOT NULL,title varchar(120) NOT NULL,
 material text NOT NULL,priority smallint NOT NULL DEFAULT 3 CHECK(priority BETWEEN 1 AND 5),
 status text NOT NULL DEFAULT 'active'
 CHECK(status IN ('active','completed','cancelled','deleted')),
 version integer NOT NULL DEFAULT 1,created_at timestamptz NOT NULL DEFAULT now(),
 updated_at timestamptz NOT NULL DEFAULT now(),
 FOREIGN KEY(owner_id,character_id) REFERENCES characters(owner_id,id),
 UNIQUE(owner_id,character_id,id)
);
CREATE INDEX ix_goals_candidates ON goals(owner_id,character_id,status,priority,created_at);
CREATE TABLE wake_receipts (
 owner_id uuid NOT NULL,character_id uuid NOT NULL,request_key text NOT NULL,
 response jsonb NOT NULL,
 created_at timestamptz NOT NULL DEFAULT now(),PRIMARY KEY(owner_id,request_key),
 FOREIGN KEY(owner_id,character_id) REFERENCES characters(owner_id,id)
);
CREATE TABLE scheduled_jobs (
 id uuid PRIMARY KEY,owner_id uuid NOT NULL,character_id uuid NOT NULL,
 interval_seconds integer NOT NULL CHECK(interval_seconds BETWEEN 60 AND 86400),
 enabled boolean NOT NULL DEFAULT true,next_run_at timestamptz NOT NULL,
 last_enqueued_at timestamptz,version integer NOT NULL DEFAULT 1,
 created_at timestamptz NOT NULL DEFAULT now(),
 FOREIGN KEY(owner_id,character_id) REFERENCES characters(owner_id,id),
 UNIQUE(character_id),UNIQUE(owner_id,character_id,id)
);
CREATE INDEX ix_schedules_due ON scheduled_jobs(next_run_at) WHERE enabled;
ALTER TABLE tasks DROP CONSTRAINT tasks_kind_check;
ALTER TABLE tasks ADD CONSTRAINT tasks_kind_check CHECK(kind IN ('chat_reply','local_activity'));
ALTER TABLE tasks ADD COLUMN goal_id uuid;
ALTER TABLE tasks ADD COLUMN schedule_id uuid;
ALTER TABLE tasks ADD COLUMN result jsonb;
ALTER TABLE tasks ADD FOREIGN KEY(owner_id,character_id,goal_id)
REFERENCES goals(owner_id,character_id,id);
ALTER TABLE tasks ADD FOREIGN KEY(owner_id,character_id,schedule_id)
REFERENCES scheduled_jobs(owner_id,character_id,id);
CREATE UNIQUE INDEX one_goal_activity ON tasks(goal_id) WHERE kind='local_activity'
AND status IN ('queued','retry_wait','running','succeeded');
CREATE TABLE journal_entries (
 id uuid PRIMARY KEY,owner_id uuid NOT NULL,character_id uuid NOT NULL,task_id uuid NOT NULL,
 local_date date NOT NULL,timezone text NOT NULL,body text NOT NULL,
 status text NOT NULL DEFAULT 'published' CHECK(status IN ('published','invalidated')),
 created_at timestamptz NOT NULL DEFAULT now(),
 FOREIGN KEY(owner_id,character_id,task_id) REFERENCES tasks(owner_id,character_id,id),
 UNIQUE(task_id),UNIQUE(owner_id,character_id,id)
);
CREATE INDEX ix_journal_owner ON journal_entries(owner_id,character_id,created_at DESC);
CREATE TABLE journal_sources (
 owner_id uuid NOT NULL,character_id uuid NOT NULL,journal_id uuid NOT NULL,event_id uuid NOT NULL,
 PRIMARY KEY(journal_id,event_id),
 FOREIGN KEY(owner_id,character_id,journal_id) REFERENCES journal_entries(owner_id,character_id,id),
 FOREIGN KEY(owner_id,character_id,event_id) REFERENCES experience_events(owner_id,character_id,id)
);
GRANT SELECT,INSERT,UPDATE,DELETE ON
goals,scheduled_jobs,journal_entries,journal_sources,wake_receipts TO fishlife_app;
"""


def upgrade() -> None:
    for statement in SCHEMA.split(";"):
        if statement.strip():
            op.execute(statement)


def downgrade() -> None:
    raise RuntimeError("M2 contains personal material; restore an audited backup instead")
