"""Keep provider-reported usage separate from verified budget settlement."""

from alembic import op

revision = "0011_qoder_usage_reports"
down_revision = "0010_provider_dispatch"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute("""CREATE TABLE qoder_usage_reports (
      reservation_id uuid PRIMARY KEY REFERENCES budget_reservations(id),
      dispatch_id uuid NOT NULL UNIQUE REFERENCES provider_dispatches(id),
      owner_id uuid NOT NULL REFERENCES users(id),
      provider_model text NOT NULL CHECK(provider_model IN ('DeepSeek-Flash','Qwen3.8-Flash')),
      request_id uuid NOT NULL,session_id uuid NOT NULL,
      reported_cost_usd numeric NOT NULL CHECK(reported_cost_usd>=0),
      reported_credits numeric CHECK(reported_credits>=0),
      input_tokens bigint NOT NULL CHECK(input_tokens>=0),
      output_tokens bigint NOT NULL CHECK(output_tokens>=0),
      cache_read_tokens bigint NOT NULL CHECK(cache_read_tokens>=0),
      cache_creation_tokens bigint NOT NULL CHECK(cache_creation_tokens>=0),
      verification_status text NOT NULL DEFAULT 'unverified'
        CHECK(verification_status='unverified'),
      reported_at timestamptz NOT NULL DEFAULT clock_timestamp())""")
    op.execute("GRANT SELECT,INSERT ON qoder_usage_reports TO fishlife_app")


def downgrade() -> None:
    raise RuntimeError(
        "Provider usage evidence requires audited recovery, not destructive downgrade"
    )
