"""Source-only autobiography snapshots; no duplicated private prose."""

from alembic import op

revision = "0008_autobiography"
down_revision = "0007_r2_web"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute("""CREATE TABLE autobiography_snapshots (
      id uuid PRIMARY KEY,owner_id uuid NOT NULL,character_id uuid NOT NULL,
      memory_epoch bigint NOT NULL,source_digest varchar(64) NOT NULL,
      source_refs jsonb NOT NULL CHECK(jsonb_typeof(source_refs)='array'),
      status text NOT NULL DEFAULT 'active' CHECK(status IN ('active','deleted')),
      created_at timestamptz NOT NULL DEFAULT now(),
      FOREIGN KEY(owner_id,character_id) REFERENCES characters(owner_id,id))""")
    op.execute("""CREATE UNIQUE INDEX ix_autobiography_same_sources
      ON autobiography_snapshots(owner_id,character_id,memory_epoch,source_digest)
      WHERE status='active'""")
    op.execute("""CREATE INDEX ix_autobiography_character ON
      autobiography_snapshots(owner_id,character_id,created_at DESC)""")
    op.execute("GRANT SELECT,INSERT,UPDATE,DELETE ON autobiography_snapshots TO fishlife_app")


def downgrade() -> None:
    raise RuntimeError("User snapshots exist; restore an audited backup instead")
