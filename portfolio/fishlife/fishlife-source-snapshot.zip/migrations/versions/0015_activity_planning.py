"""Opt-in planning limits and original-goal source identities; no model execution."""

from alembic import op

revision = "0015_activity_planning"
down_revision = "0014_qoder_settlements"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute("ALTER TABLE tasks DROP CONSTRAINT tasks_kind_check")
    op.execute("""ALTER TABLE tasks ADD CONSTRAINT tasks_kind_check
        CHECK(kind IN ('chat_reply','local_activity','activity_plan'))""")
    op.execute("""CREATE TABLE activity_planning_preferences (
        owner_id uuid NOT NULL,character_id uuid NOT NULL,
        enabled boolean NOT NULL DEFAULT false,
        daily_limit integer NOT NULL DEFAULT 4 CHECK(daily_limit BETWEEN 1 AND 8),
        local_day date,calls_today integer NOT NULL DEFAULT 0 CHECK(calls_today>=0),
        quiet_until timestamptz,version integer NOT NULL DEFAULT 1 CHECK(version>0),
        PRIMARY KEY(owner_id,character_id),
        FOREIGN KEY(owner_id,character_id) REFERENCES characters(owner_id,id))""")
    op.execute("""CREATE TABLE activity_plan_sources (
        owner_id uuid NOT NULL,character_id uuid NOT NULL,task_id uuid NOT NULL,
        goal_id uuid NOT NULL,goal_version integer NOT NULL CHECK(goal_version>0),
        source_hash text NOT NULL CHECK(source_hash ~ '^[0-9a-f]{64}$'),
        PRIMARY KEY(task_id,goal_id),
        FOREIGN KEY(owner_id,character_id,task_id) REFERENCES tasks(owner_id,character_id,id),
        FOREIGN KEY(owner_id,character_id,goal_id) REFERENCES goals(owner_id,character_id,id))""")
    op.execute("""CREATE INDEX ix_activity_plan_sources_owner_character
        ON activity_plan_sources(owner_id,character_id,task_id)""")
    op.execute("""GRANT SELECT,INSERT,UPDATE,DELETE ON
        activity_planning_preferences,activity_plan_sources TO fishlife_app""")


def downgrade() -> None:
    raise RuntimeError("Planning source evidence requires audited recovery")
