"""Explicit, pinned HTTPS read policy and untrusted web documents."""

from alembic import op

revision = "0007_r2_web"
down_revision = "0006_m5"
branch_labels = None
depends_on = None

SCHEMA = """
ALTER TABLE character_states ADD COLUMN tools_epoch bigint NOT NULL DEFAULT 0;
CREATE TABLE web_policies (
 owner_id uuid NOT NULL,character_id uuid PRIMARY KEY,enabled boolean NOT NULL DEFAULT false,
 allowed_domains jsonb NOT NULL DEFAULT '[]',version integer NOT NULL DEFAULT 1,
 updated_at timestamptz NOT NULL DEFAULT now(),
 FOREIGN KEY(owner_id,character_id) REFERENCES characters(owner_id,id)
);
CREATE TABLE web_documents (
 id uuid PRIMARY KEY,owner_id uuid NOT NULL,character_id uuid NOT NULL,request_key uuid NOT NULL,
 request_hash varchar(64) NOT NULL,url text NOT NULL,final_url text NOT NULL DEFAULT '',
 text_content text NOT NULL DEFAULT '',text_sha256 varchar(64),raw_sha256 varchar(64),
 byte_size integer CHECK(byte_size BETWEEN 0 AND 262144),http_status integer,
 status text NOT NULL CHECK(status IN ('running','succeeded','failed','unknown','deleted')),
 untrusted boolean NOT NULL DEFAULT true CHECK(untrusted),policy_version integer NOT NULL,
 error_code text,created_at timestamptz NOT NULL DEFAULT now(),fetched_at timestamptz,
 FOREIGN KEY(owner_id,character_id) REFERENCES characters(owner_id,id),
 UNIQUE(owner_id,request_key),UNIQUE(owner_id,character_id,id)
);
CREATE INDEX ix_web_documents_owner ON web_documents(owner_id,created_at DESC);
GRANT SELECT,INSERT,UPDATE,DELETE ON web_policies,web_documents TO fishlife_app;
"""


def upgrade() -> None:
    for statement in SCHEMA.split(";"):
        if statement.strip():
            op.execute(statement)


def downgrade() -> None:
    raise RuntimeError("Web documents contain user data; restore an audited backup instead")
