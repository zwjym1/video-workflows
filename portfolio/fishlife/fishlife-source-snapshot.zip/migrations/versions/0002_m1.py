"""M1 identity, durable chat queue, sourced memory and budget ledger."""

from alembic import op

revision = "0002_m1"
down_revision = "0001_bootstrap"
branch_labels = None
depends_on = None

SCHEMA = """
CREATE TABLE users (
 id uuid PRIMARY KEY, username varchar(80) NOT NULL UNIQUE, password_hash text NOT NULL,
 timezone text NOT NULL DEFAULT 'Asia/Shanghai', disabled boolean NOT NULL DEFAULT false,
 daily_budget_usd numeric(16,8) NOT NULL DEFAULT .50 CHECK(daily_budget_usd>=0),
 monthly_budget_usd numeric(16,8) NOT NULL DEFAULT 10 CHECK(monthly_budget_usd>=0),
 autonomy_paused boolean NOT NULL DEFAULT true, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE sessions (
 id uuid PRIMARY KEY, owner_id uuid NOT NULL REFERENCES users(id), token_hash text NOT NULL
 UNIQUE,
 csrf_hash text NOT NULL, expires_at timestamptz NOT NULL, revoked_at timestamptz,
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ix_sessions_owner ON sessions(owner_id,expires_at);
CREATE TABLE auth_rate_limits(key text PRIMARY KEY,attempts integer NOT NULL,reset_at
timestamptz NOT NULL);
CREATE TABLE characters (
 id uuid PRIMARY KEY,owner_id uuid NOT NULL REFERENCES users(id),name varchar(80) NOT NULL,
 core_persona jsonb NOT NULL DEFAULT '{}', interests jsonb NOT NULL DEFAULT '[]',
 persona_version integer NOT NULL DEFAULT 1,version integer NOT NULL DEFAULT 1,
 enabled boolean NOT NULL DEFAULT true,created_at timestamptz NOT NULL DEFAULT now(),
 updated_at timestamptz NOT NULL DEFAULT now(),UNIQUE(owner_id,id)
);
CREATE UNIQUE INDEX one_enabled_character ON characters(owner_id) WHERE enabled;
CREATE TABLE character_states (
 character_id uuid PRIMARY KEY,owner_id uuid NOT NULL,mode text NOT NULL DEFAULT 'idle'
 CHECK(mode IN ('idle','active','paused','deleting','degraded')),
 memory_epoch bigint NOT NULL DEFAULT 0,state_version integer NOT NULL DEFAULT 1,
 last_active_at timestamptz,simulated_mood jsonb NOT NULL DEFAULT '{}',
 FOREIGN KEY(owner_id,character_id) REFERENCES characters(owner_id,id)
);
CREATE TABLE conversations (
 id uuid PRIMARY KEY,owner_id uuid NOT NULL,character_id uuid NOT NULL,title text NOT NULL,
 summary text,summary_epoch bigint NOT NULL DEFAULT 0,version integer NOT NULL DEFAULT 1,
 created_at timestamptz NOT NULL DEFAULT now(),updated_at timestamptz NOT NULL DEFAULT now(),
 FOREIGN KEY(owner_id,character_id) REFERENCES characters(owner_id,id),
 UNIQUE(owner_id,character_id,id)
);
CREATE INDEX ix_conversations_owner ON conversations(owner_id,character_id,created_at DESC);
CREATE TABLE messages (
 id uuid PRIMARY KEY,owner_id uuid NOT NULL,character_id uuid NOT NULL,conversation_id uuid NOT
 NULL,
 role text NOT NULL CHECK(role IN ('user','assistant','system','tool')),content text NOT NULL,
 content_kind text NOT NULL CHECK(content_kind IN ('real','roleplay','inference')),
 status text NOT NULL CHECK(status IN ('completed','failed','deleted')),seq bigint NOT NULL,
 client_request_id uuid,in_reply_to uuid REFERENCES messages(id),version integer NOT NULL
 DEFAULT 1,
 created_at timestamptz NOT NULL DEFAULT now(),
 FOREIGN KEY(owner_id,character_id,conversation_id) REFERENCES
 conversations(owner_id,character_id,id),
 UNIQUE(conversation_id,seq),UNIQUE(owner_id,client_request_id),UNIQUE(owner_id,character_id,id)
);
CREATE UNIQUE INDEX one_completed_reply ON messages(in_reply_to)
 WHERE role='assistant' AND status='completed';
CREATE TABLE tasks (
 id uuid PRIMARY KEY,owner_id uuid NOT NULL,character_id uuid NOT NULL,
 kind text NOT NULL CHECK(kind='chat_reply'),input jsonb NOT NULL,status text NOT NULL
 CHECK(status IN ('queued','running','retry_wait','succeeded','failed','unknown','cancelled')),
 idempotency_key text NOT NULL,attempt_count integer NOT NULL DEFAULT 0,
 max_attempts integer NOT NULL DEFAULT 3 CHECK(max_attempts BETWEEN 1 AND 3),
 not_before timestamptz NOT NULL DEFAULT now(),lease_until timestamptz,lease_owner text,
 fencing_token bigint NOT NULL DEFAULT 0,cancel_requested boolean NOT NULL DEFAULT false,
 result_message_id uuid REFERENCES messages(id),error_code text,
 created_at timestamptz NOT NULL DEFAULT now(),updated_at timestamptz NOT NULL DEFAULT now(),
 FOREIGN KEY(owner_id,character_id) REFERENCES characters(owner_id,id),
 UNIQUE(owner_id,idempotency_key),UNIQUE(owner_id,character_id,id)
);
CREATE INDEX ix_tasks_ready ON tasks(status,not_before,created_at);
CREATE UNIQUE INDEX one_running_per_character ON tasks(owner_id,character_id) WHERE
status='running';
CREATE TABLE task_runs (
 id uuid PRIMARY KEY,owner_id uuid NOT NULL,character_id uuid NOT NULL,task_id uuid NOT NULL,
 attempt_no integer NOT NULL,status text NOT NULL,node text NOT NULL DEFAULT 'claimed',
 memory_epoch bigint NOT NULL,fencing_token bigint NOT NULL,started_at timestamptz NOT NULL
 DEFAULT now(),
 heartbeat_at timestamptz NOT NULL DEFAULT now(),finished_at timestamptz,error_code text,
 FOREIGN KEY(owner_id,character_id,task_id) REFERENCES tasks(owner_id,character_id,id),
 UNIQUE(task_id,attempt_no),UNIQUE(owner_id,character_id,id)
);
CREATE TABLE experience_events (
 id uuid PRIMARY KEY,owner_id uuid NOT NULL,character_id uuid NOT NULL,event_type text NOT NULL,
 reality_class text NOT NULL CHECK(reality_class IN
 ('observed','user_claim','inferred','roleplay')),
 occurred_at timestamptz NOT NULL DEFAULT now(),payload jsonb NOT NULL DEFAULT '{}',
 source_message_id uuid,task_run_id uuid,dedupe_key text NOT NULL,
 created_at timestamptz NOT NULL DEFAULT now(),
 FOREIGN KEY(owner_id,character_id) REFERENCES characters(owner_id,id),
 FOREIGN KEY(owner_id,character_id,source_message_id) REFERENCES
 messages(owner_id,character_id,id),
 UNIQUE(owner_id,character_id,dedupe_key),UNIQUE(owner_id,character_id,id)
);
CREATE INDEX ix_events_timeline ON experience_events(owner_id,character_id,occurred_at DESC);
CREATE TABLE memory_items (
 id uuid PRIMARY KEY,owner_id uuid NOT NULL,character_id uuid NOT NULL,content text NOT NULL,
 kind text NOT NULL DEFAULT 'fact',status text NOT NULL DEFAULT 'active'
 CHECK(status IN ('active','candidate','disputed','superseded','expired','deleted')),
 reality_class text NOT NULL DEFAULT 'user_claim',subject text NOT NULL DEFAULT 'user',predicate
 text,
 object_value jsonb,confidence numeric(4,3) NOT NULL DEFAULT .85 CHECK(confidence BETWEEN 0 AND
 1),
 importance smallint NOT NULL DEFAULT 3 CHECK(importance BETWEEN 0 AND 5),
 observed_at timestamptz NOT NULL DEFAULT now(),valid_from timestamptz NOT NULL DEFAULT now(),
 valid_until timestamptz,expires_at timestamptz,deleted_at timestamptz,
 supersedes_id uuid REFERENCES memory_items(id),embedding vector(1536),embedding_model text,
 tags text[] NOT NULL DEFAULT '{}',version integer NOT NULL DEFAULT 1,
 created_at timestamptz NOT NULL DEFAULT now(),updated_at timestamptz NOT NULL DEFAULT now(),
 FOREIGN KEY(owner_id,character_id) REFERENCES characters(owner_id,id),
 UNIQUE(owner_id,character_id,id)
);
CREATE INDEX ix_memory_retrieval ON memory_items(owner_id,character_id,status,predicate);
CREATE TABLE memory_sources (
 id uuid PRIMARY KEY,owner_id uuid NOT NULL,character_id uuid NOT NULL,memory_id uuid NOT NULL,
 message_id uuid,event_id uuid,quote text NOT NULL,source_hash text NOT NULL,
 created_at timestamptz NOT NULL DEFAULT now(),CHECK(num_nonnulls(message_id,event_id)=1),
 FOREIGN KEY(owner_id,character_id,memory_id) REFERENCES memory_items(owner_id,character_id,id),
 FOREIGN KEY(owner_id,character_id,message_id) REFERENCES messages(owner_id,character_id,id),
 FOREIGN KEY(owner_id,character_id,event_id) REFERENCES
 experience_events(owner_id,character_id,id)
);
CREATE INDEX ix_memory_sources ON memory_sources(memory_id);
CREATE TABLE message_memory_links (
 owner_id uuid NOT NULL,character_id uuid NOT NULL,message_id uuid NOT NULL,memory_id uuid NOT
 NULL,
 PRIMARY KEY(message_id,memory_id),
 FOREIGN KEY(owner_id,character_id,message_id) REFERENCES messages(owner_id,character_id,id),
 FOREIGN KEY(owner_id,character_id,memory_id) REFERENCES memory_items(owner_id,character_id,id)
);
CREATE TABLE deletion_requests (
 id uuid PRIMARY KEY,owner_id uuid NOT NULL,character_id uuid NOT NULL,status text NOT NULL,
 epoch bigint NOT NULL,report jsonb NOT NULL DEFAULT '{}',created_at timestamptz NOT NULL
 DEFAULT now(),
 completed_at timestamptz,FOREIGN KEY(owner_id,character_id) REFERENCES characters(owner_id,id)
);
CREATE TABLE budget_accounts (
 id uuid PRIMARY KEY,owner_id uuid NOT NULL REFERENCES users(id),period_type text NOT NULL
 CHECK(period_type IN ('day','month')),period_start date NOT NULL,bucket text NOT NULL
 CHECK(bucket IN ('total','chat','autonomy')),limit_amount numeric(16,8) NOT NULL
 CHECK(limit_amount>=0),
 reserved_amount numeric(16,8) NOT NULL DEFAULT 0 CHECK(reserved_amount>=0),
 spent_amount numeric(16,8) NOT NULL DEFAULT 0 CHECK(spent_amount>=0),
 UNIQUE(owner_id,period_type,period_start,bucket)
);
CREATE TABLE budget_reservations (
 id uuid PRIMARY KEY,owner_id uuid NOT NULL REFERENCES users(id),run_id uuid NOT NULL REFERENCES
 task_runs(id),
 status text NOT NULL CHECK(status IN ('held','settled','unknown','released')),
 reserved_cost numeric(16,8) NOT NULL,settled_cost numeric(16,8),pricing_version text NOT NULL,
 created_at timestamptz NOT NULL DEFAULT now(),settled_at timestamptz,UNIQUE(run_id)
);
CREATE TABLE budget_reservation_accounts (
 reservation_id uuid NOT NULL REFERENCES budget_reservations(id),account_id uuid NOT NULL
 REFERENCES budget_accounts(id),
 reserved_amount numeric(16,8) NOT NULL,PRIMARY KEY(reservation_id,account_id)
);
CREATE TABLE model_usage_logs (
 id uuid PRIMARY KEY,owner_id uuid NOT NULL REFERENCES users(id),character_id uuid NOT NULL,
 run_id uuid NOT NULL REFERENCES task_runs(id),reservation_id uuid NOT NULL REFERENCES
 budget_reservations(id),
 provider text NOT NULL,model text NOT NULL,purpose text NOT NULL DEFAULT 'chat',
 input_tokens bigint,output_tokens bigint,estimated_cost_usd numeric(16,8) NOT NULL,
 actual_cost_usd numeric(16,8),status text NOT NULL,pricing_version text NOT NULL,
 provider_request_id text,created_at timestamptz NOT NULL DEFAULT now(),UNIQUE(run_id)
);
CREATE INDEX ix_usage_owner ON model_usage_logs(owner_id,created_at);
GRANT SELECT,INSERT,UPDATE,DELETE ON ALL TABLES IN SCHEMA public TO fishlife_app;
REVOKE ALL ON alembic_version FROM fishlife_app;"""


def upgrade() -> None:
    for statement in SCHEMA.split(";"):
        if statement.strip():
            op.execute(statement)


def downgrade() -> None:
    raise RuntimeError("M1 downgrade destroys personal data; restore a reviewed backup instead")
