"""Opt-in sourced in-app notifications and owner-wide safety controls."""

from alembic import op

revision = "0005_m4"
down_revision = "0004_m3"
branch_labels = None
depends_on = None

SCHEMA = """
CREATE TABLE notification_preferences (
 owner_id uuid PRIMARY KEY REFERENCES users(id),enabled boolean NOT NULL DEFAULT false,
 timezone text NOT NULL DEFAULT 'Asia/Shanghai',quiet_start_hour integer NOT NULL DEFAULT 22
 CHECK(quiet_start_hour BETWEEN 0 AND 23),quiet_end_hour integer NOT NULL DEFAULT 8
 CHECK(quiet_end_hour BETWEEN 0 AND 23),daily_limit integer NOT NULL DEFAULT 2
 CHECK(daily_limit BETWEEN 1 AND 5),min_interval_minutes integer NOT NULL DEFAULT 240
 CHECK(min_interval_minutes BETWEEN 60 AND 1440),version integer NOT NULL DEFAULT 1,
 updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE notifications (
 id uuid PRIMARY KEY,owner_id uuid NOT NULL,character_id uuid NOT NULL,
 source_event_id uuid NOT NULL,body text NOT NULL,status text NOT NULL DEFAULT 'unread'
 CHECK(status IN ('unread','read','invalidated')),created_at timestamptz NOT NULL DEFAULT now(),
 local_date date NOT NULL,read_at timestamptz,
 FOREIGN KEY(owner_id,character_id) REFERENCES characters(owner_id,id),
 FOREIGN KEY(owner_id,character_id,source_event_id)
 REFERENCES experience_events(owner_id,character_id,id),UNIQUE(owner_id,source_event_id)
);
CREATE INDEX ix_notifications_owner_time ON notifications(owner_id,created_at DESC);
GRANT SELECT,INSERT,UPDATE,DELETE ON notification_preferences,notifications TO fishlife_app;
"""


def upgrade() -> None:
    for statement in SCHEMA.split(";"):
        if statement.strip():
            op.execute(statement)


def downgrade() -> None:
    raise RuntimeError("M4 contains personal notifications; restore an audited backup instead")
