"""Durable pre-dispatch records, without private prompts or automatic replay."""

from alembic import op

revision = "0010_provider_dispatch"
down_revision = "0009_readiness"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute("""CREATE TABLE provider_dispatches (
      id uuid PRIMARY KEY,owner_id uuid NOT NULL,character_id uuid NOT NULL,
      task_id uuid NOT NULL UNIQUE,run_id uuid NOT NULL UNIQUE,
      reservation_id uuid NOT NULL UNIQUE REFERENCES budget_reservations(id),
      provider text NOT NULL CHECK(provider='qoder'),
      model text NOT NULL CHECK(model IN ('DeepSeek-Flash','Qwen3.8-Flash')),
      status text NOT NULL CHECK(status IN ('started','unknown')),
      started_at timestamptz NOT NULL DEFAULT now(),finished_at timestamptz,
      FOREIGN KEY(owner_id,character_id,task_id) REFERENCES tasks(owner_id,character_id,id),
      FOREIGN KEY(owner_id,character_id,run_id) REFERENCES task_runs(owner_id,character_id,id),
      CHECK((status='started' AND finished_at IS NULL)
         OR (status='unknown' AND finished_at IS NOT NULL)))""")
    op.execute("""CREATE INDEX ix_dispatch_owner_time ON
      provider_dispatches(owner_id,started_at DESC)""")
    op.execute("GRANT SELECT,INSERT,UPDATE ON provider_dispatches TO fishlife_app")


def downgrade() -> None:
    raise RuntimeError(
        "Dispatch evidence must not be erased to enable retries; use audited recovery"
    )
