"""Immutable user-attested Qoder billing settlements, separate from reports."""

from alembic import op

revision = "0014_qoder_settlements"
down_revision = "0013_qoder_account_scope"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute("""ALTER TABLE budget_reservations ADD CONSTRAINT uq_reservation_owner_id
        UNIQUE(owner_id,id)""")
    op.execute("""ALTER TABLE provider_dispatches ADD CONSTRAINT uq_dispatch_settlement_identity
        UNIQUE(owner_id,reservation_id,id)""")
    op.execute("""CREATE TABLE qoder_settlements (
      reservation_id uuid PRIMARY KEY REFERENCES budget_reservations(id),
      dispatch_id uuid NOT NULL UNIQUE REFERENCES provider_dispatches(id),
      owner_id uuid NOT NULL REFERENCES users(id),
      idempotency_key uuid NOT NULL,
      actual_cost_usd numeric NOT NULL CHECK(actual_cost_usd BETWEEN 0 AND 1000000
        AND actual_cost_usd=round(actual_cost_usd,8)),
      actual_credits numeric NOT NULL CHECK(actual_credits BETWEEN 0 AND 1000000
        AND actual_credits=round(actual_credits,8)),
      expected_reserved_usd numeric NOT NULL CHECK(expected_reserved_usd BETWEEN 0 AND 1000000
        AND expected_reserved_usd=round(expected_reserved_usd,8)),
      evidence_sha256 text NOT NULL CHECK(evidence_sha256 ~ '^[0-9a-f]{64}$'),
      confirmed_at timestamptz NOT NULL DEFAULT clock_timestamp(),
      verification_source text NOT NULL DEFAULT 'user_attested'
        CHECK(verification_source='user_attested'),
      UNIQUE(owner_id,idempotency_key),
      FOREIGN KEY(owner_id,reservation_id) REFERENCES budget_reservations(owner_id,id),
      FOREIGN KEY(owner_id,reservation_id,dispatch_id)
        REFERENCES provider_dispatches(owner_id,reservation_id,id))""")
    op.execute("""CREATE FUNCTION reject_qoder_settlement_mutation() RETURNS trigger
        LANGUAGE plpgsql AS $$ BEGIN
        RAISE EXCEPTION 'Qoder settlement evidence is immutable'; END $$""")
    op.execute("""CREATE TRIGGER qoder_settlement_immutable BEFORE UPDATE OR DELETE
        ON qoder_settlements FOR EACH ROW EXECUTE FUNCTION reject_qoder_settlement_mutation()""")
    op.execute("GRANT SELECT,INSERT ON qoder_settlements TO fishlife_app")


def downgrade() -> None:
    raise RuntimeError("Settlement evidence requires audited recovery")
