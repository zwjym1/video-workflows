"""M0 runtime heartbeat and checkpoint namespace; no M1 business tables."""

from alembic import op

revision = "0001_bootstrap"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute("CREATE EXTENSION IF NOT EXISTS vector")
    op.execute("CREATE SCHEMA IF NOT EXISTS agent_runtime")
    op.execute(
        "CREATE TABLE service_heartbeats ("
        "service_name text PRIMARY KEY, heartbeat_at timestamptz NOT NULL)"
    )
    op.execute("GRANT SELECT, INSERT, UPDATE ON service_heartbeats TO fishlife_app")


def downgrade() -> None:
    op.drop_table("service_heartbeats")
    # checkpoint data and extension are deliberately preserved; no cascade deletion.
