"""One provider receipt cannot be reused for another reservation."""

from alembic import op

revision = "0012_qoder_receipt_identity"
down_revision = "0011_qoder_usage_reports"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Existing duplicates deliberately fail migration for human investigation;
    # never erase billing evidence to make the constraint fit.
    op.execute("""ALTER TABLE qoder_usage_reports ADD CONSTRAINT qoder_receipt_identity
        UNIQUE(session_id,request_id)""")


def downgrade() -> None:
    raise RuntimeError("Receipt replay protection requires audited recovery")
