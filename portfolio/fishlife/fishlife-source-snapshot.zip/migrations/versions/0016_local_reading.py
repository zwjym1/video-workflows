"""Owner-scoped local reading sources, resumable segments and sourced notes."""

from alembic import op

revision = "0016_local_reading"
down_revision = "0015_activity_planning"
branch_labels = None
depends_on = None

SCHEMA = """
CREATE TABLE books (
 id uuid PRIMARY KEY,owner_id uuid NOT NULL,character_id uuid NOT NULL,
 title varchar(120) NOT NULL CHECK(char_length(btrim(title)) BETWEEN 1 AND 120),
 status text NOT NULL DEFAULT 'active' CHECK(status IN ('active','completed','deleted')),
 source_hash text CHECK(source_hash ~ '^[0-9a-f]{64}$'),
 total_chars integer NOT NULL CHECK(total_chars BETWEEN 0 AND 200000),
 segment_count integer NOT NULL CHECK(segment_count BETWEEN 0 AND 100),
 cursor integer NOT NULL DEFAULT 0 CHECK(cursor BETWEEN 0 AND segment_count),
 auto_enabled boolean NOT NULL DEFAULT false,
 interval_seconds integer NOT NULL DEFAULT 1800 CHECK(interval_seconds BETWEEN 60 AND 86400),
 next_read_at timestamptz,version integer NOT NULL DEFAULT 1 CHECK(version>0),
 import_key uuid NOT NULL,request_hash text CHECK(request_hash ~ '^[0-9a-f]{64}$'),
 created_at timestamptz NOT NULL DEFAULT now(),updated_at timestamptz NOT NULL DEFAULT now(),
 FOREIGN KEY(owner_id,character_id) REFERENCES characters(owner_id,id),
 UNIQUE(owner_id,character_id,id),UNIQUE(owner_id,character_id,import_key),
 CHECK((status IN ('active','completed') AND source_hash IS NOT NULL
        AND total_chars>0 AND segment_count>0)
    OR (status='deleted' AND source_hash IS NULL AND request_hash IS NULL
        AND title='已删除' AND total_chars=0 AND segment_count=0 AND cursor=0
        AND auto_enabled=false)),
 CHECK(status<>'completed' OR cursor=segment_count)
);
CREATE INDEX ix_books_owner_character ON books(owner_id,character_id,created_at DESC);
CREATE INDEX ix_books_reading_due ON books(next_read_at)
 WHERE auto_enabled AND status='active';
CREATE TABLE reading_segments (
 owner_id uuid NOT NULL,character_id uuid NOT NULL,book_id uuid NOT NULL,
 ordinal integer NOT NULL CHECK(ordinal BETWEEN 0 AND 99),
 start_offset integer NOT NULL,end_offset integer NOT NULL,content text NOT NULL,
 source_hash text CHECK(source_hash ~ '^[0-9a-f]{64}$'),deleted boolean NOT NULL DEFAULT false,
 PRIMARY KEY(book_id,ordinal),UNIQUE(owner_id,character_id,book_id,ordinal),
 FOREIGN KEY(owner_id,character_id,book_id) REFERENCES books(owner_id,character_id,id),
 CHECK((NOT deleted AND source_hash IS NOT NULL AND start_offset>=0
        AND end_offset<=200000 AND end_offset>start_offset
        AND char_length(content)=end_offset-start_offset AND char_length(content)<=2500)
    OR (deleted AND source_hash IS NULL AND content='' AND start_offset=0 AND end_offset=0))
);
ALTER TABLE tasks DROP CONSTRAINT tasks_kind_check;
ALTER TABLE tasks ADD CONSTRAINT tasks_kind_check
 CHECK(kind IN ('chat_reply','local_activity','activity_plan','reading_step'));
ALTER TABLE tasks ADD COLUMN reading_book_id uuid;
ALTER TABLE tasks ADD COLUMN reading_ordinal integer;
ALTER TABLE tasks ADD CONSTRAINT tasks_reading_segment_fk
 FOREIGN KEY(owner_id,character_id,reading_book_id,reading_ordinal)
 REFERENCES reading_segments(owner_id,character_id,book_id,ordinal);
ALTER TABLE tasks ADD CONSTRAINT tasks_reading_identity_check
 CHECK((kind='reading_step' AND reading_book_id IS NOT NULL AND reading_ordinal IS NOT NULL)
    OR (kind<>'reading_step' AND reading_book_id IS NULL AND reading_ordinal IS NULL));
ALTER TABLE tasks ADD CONSTRAINT uq_task_reading_identity
 UNIQUE(owner_id,character_id,reading_book_id,reading_ordinal,id);
CREATE UNIQUE INDEX one_reading_segment_task ON tasks(reading_book_id,reading_ordinal)
 WHERE kind='reading_step' AND status IN ('queued','retry_wait','running','succeeded');
ALTER TABLE task_runs ADD CONSTRAINT uq_task_run_reading_identity
 UNIQUE(owner_id,character_id,task_id,id);
ALTER TABLE experience_events ADD CONSTRAINT uq_event_reading_run_identity
 UNIQUE(owner_id,character_id,task_run_id,id);
CREATE TABLE reading_notes (
 id uuid PRIMARY KEY,owner_id uuid NOT NULL,character_id uuid NOT NULL,book_id uuid NOT NULL,
 ordinal integer NOT NULL,task_id uuid NOT NULL,run_id uuid NOT NULL,event_id uuid NOT NULL,
 source_hash text CHECK(source_hash ~ '^[0-9a-f]{64}$'),excerpts jsonb NOT NULL,
 status text NOT NULL DEFAULT 'active' CHECK(status IN ('active','deleted')),
 created_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(book_id,ordinal),UNIQUE(task_id),UNIQUE(owner_id,character_id,id),
 FOREIGN KEY(owner_id,character_id,book_id,ordinal)
 REFERENCES reading_segments(owner_id,character_id,book_id,ordinal),
 FOREIGN KEY(owner_id,character_id,book_id,ordinal,task_id)
 REFERENCES tasks(owner_id,character_id,reading_book_id,reading_ordinal,id),
 FOREIGN KEY(owner_id,character_id,task_id,run_id)
 REFERENCES task_runs(owner_id,character_id,task_id,id),
 FOREIGN KEY(owner_id,character_id,run_id,event_id)
 REFERENCES experience_events(owner_id,character_id,task_run_id,id),
 CHECK((status='deleted' AND source_hash IS NULL AND excerpts='[]'::jsonb)
    OR (status='active' AND source_hash IS NOT NULL AND
        CASE WHEN jsonb_typeof(excerpts)='array' THEN
            jsonb_array_length(excerpts) BETWEEN 1 AND 3
            AND jsonb_typeof(excerpts->0) IS NOT DISTINCT FROM 'string'
            AND char_length(excerpts->>0) BETWEEN 1 AND 220
            AND (jsonb_array_length(excerpts)<2 OR
                (jsonb_typeof(excerpts->1) IS NOT DISTINCT FROM 'string'
                 AND char_length(excerpts->>1) BETWEEN 1 AND 220))
            AND (jsonb_array_length(excerpts)<3 OR
                (jsonb_typeof(excerpts->2) IS NOT DISTINCT FROM 'string'
                 AND char_length(excerpts->>2) BETWEEN 1 AND 220))
        ELSE false END))
);
CREATE INDEX ix_reading_notes_book ON reading_notes(owner_id,character_id,book_id,ordinal);
GRANT SELECT,INSERT,UPDATE,DELETE ON books,reading_segments,reading_notes TO fishlife_app;
"""


def upgrade() -> None:
    op.execute(SCHEMA)


def downgrade() -> None:
    raise RuntimeError("Reading source evidence requires audited recovery")
