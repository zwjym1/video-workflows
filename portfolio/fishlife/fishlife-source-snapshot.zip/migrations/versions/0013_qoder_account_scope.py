"""Serialize unresolved sends by trusted account scope, including across owners."""

from alembic import op

revision = "0013_qoder_account_scope"
down_revision = "0012_qoder_receipt_identity"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Unknown legacy account identity cannot safely be guessed from owner IDs.
    # Preserve the records and make them block all accounts until audited.
    op.execute("""ALTER TABLE provider_dispatches ADD COLUMN account_scope text NOT NULL
        DEFAULT 'unverified'
        CHECK(account_scope='unverified' OR account_scope ~ '^[0-9a-f]{64}$')""")
    op.execute("""CREATE INDEX ix_dispatch_account_time ON
        provider_dispatches(account_scope,started_at DESC)""")


def downgrade() -> None:
    raise RuntimeError("Account replay boundaries require audited recovery")
