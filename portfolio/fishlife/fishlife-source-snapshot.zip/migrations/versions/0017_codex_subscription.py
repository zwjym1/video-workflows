"""Subscription dispatch evidence, without invented dollar receipts."""

from alembic import op

revision = "0017_codex_dispatches"
down_revision = "0016_local_reading"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute("""CREATE TABLE codex_dispatches (
      id uuid PRIMARY KEY,owner_id uuid NOT NULL,character_id uuid NOT NULL,
      task_id uuid NOT NULL UNIQUE,run_id uuid NOT NULL UNIQUE,
      reservation_id uuid NOT NULL UNIQUE REFERENCES budget_reservations(id),
      model text NOT NULL CHECK(char_length(model) BETWEEN 1 AND 100),
      status text NOT NULL CHECK(status IN ('started','succeeded','unknown')),
      started_at timestamptz NOT NULL DEFAULT now(),finished_at timestamptz,
      FOREIGN KEY(owner_id,character_id,task_id) REFERENCES tasks(owner_id,character_id,id),
      FOREIGN KEY(owner_id,character_id,run_id) REFERENCES task_runs(owner_id,character_id,id),
      CHECK((status='started' AND finished_at IS NULL)
         OR (status IN ('succeeded','unknown') AND finished_at IS NOT NULL)))""")
    op.execute("CREATE INDEX ix_codex_dispatch_time ON codex_dispatches(owner_id,started_at)")
    op.execute("GRANT SELECT,INSERT,UPDATE ON codex_dispatches TO fishlife_app")


def downgrade() -> None:
    raise RuntimeError("Subscription dispatch evidence must not be erased to enable retries")
