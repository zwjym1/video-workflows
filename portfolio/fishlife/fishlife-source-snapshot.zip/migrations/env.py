from alembic import context
from sqlalchemy import create_engine

from app.config import Settings


def run_migrations() -> None:
    url = Settings().migration_database_url.get_secret_value()
    if context.is_offline_mode():
        context.configure(url=url, literal_binds=True)
        with context.begin_transaction():
            context.run_migrations()
        return
    engine = create_engine(url)
    with engine.connect() as connection:
        context.configure(connection=connection)
        with context.begin_transaction():
            context.run_migrations()
    engine.dispose()


run_migrations()
