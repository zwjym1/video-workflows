"""Bounded planning sources and local-day limits, without dispatch or billing authority."""

import hashlib
import json
from collections.abc import Sequence
from datetime import datetime
from uuid import UUID
from zoneinfo import ZoneInfo

from sqlalchemy import Connection

from app.errors import BusinessError
from app.repository import Row, execute, one, rows


def _reject() -> BusinessError:
    # Do not disclose source text or whether another owner's object exists.
    return BusinessError("ACTIVITY_PLAN_UNAVAILABLE", "规划来源或许可已失效", 409)


def _task(conn: Connection, owner: UUID, character: UUID, task: UUID) -> Row:
    current = one(
        conn,
        """SELECT * FROM tasks WHERE owner_id=:o AND character_id=:c
        AND id=:t FOR UPDATE""",
        {"o": owner, "c": character, "t": task},
    )
    if not current or current["kind"] != "activity_plan" or current["max_attempts"] != 1:
        raise _reject()
    return current


def _hash(goal: Row) -> str:
    canonical = json.dumps(
        {key: goal[key] for key in ("title", "material", "priority", "version")},
        ensure_ascii=True,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    )
    return hashlib.sha256(canonical.encode("utf8")).hexdigest()


def _source_binding(sources: Sequence[Row]) -> Row:
    canonical = json.dumps(
        sorted(
            (str(source["goal_id"]), source["goal_version"], source["source_hash"])
            for source in sources
        ),
        separators=(",", ":"),
        allow_nan=False,
    )
    return {"count": len(sources), "digest": hashlib.sha256(canonical.encode("utf8")).hexdigest()}


def _check_binding(task_input: Row, sources: Sequence[Row]) -> None:
    binding = task_input.get("activity_plan_sources")
    if (
        not isinstance(binding, dict)
        or type(binding.get("count")) is not int
        or binding != _source_binding(sources)
    ):
        raise _reject()


def _goal(conn: Connection, owner: UUID, character: UUID, identifier: UUID) -> Row:
    goal = one(
        conn,
        """SELECT * FROM goals WHERE owner_id=:o AND character_id=:c
        AND id=:g FOR SHARE""",
        {"o": owner, "c": character, "g": identifier},
    )
    if not goal or goal["status"] != "active" or goal["version"] < 1:
        raise _reject()
    blocked = one(
        conn,
        """SELECT id FROM tasks WHERE owner_id=:o AND character_id=:c
        AND goal_id=:g AND kind='local_activity'
        AND status IN ('queued','retry_wait','running','succeeded','failed','unknown') LIMIT 1""",
        {"o": owner, "c": character, "g": identifier},
    )
    if blocked:
        raise _reject()
    return goal


def snapshot_candidates(
    conn: Connection,
    owner: UUID,
    character: UUID,
    task: UUID,
    candidates: Sequence[Row],
) -> None:
    """Bind 1–3 exact database rows to a queued, single-attempt planning task."""
    current = _task(conn, owner, character, task)
    if (
        current["status"] != "queued"
        or not isinstance(current["input"], dict)
        or not 1 <= len(candidates) <= 3
    ):
        raise _reject()
    sources: list[Row] = []
    seen: set[UUID] = set()
    for candidate in candidates:
        identifier = candidate.get("id")
        if not isinstance(identifier, UUID) or identifier in seen:
            raise _reject()
        seen.add(identifier)
        goal = _goal(conn, owner, character, identifier)
        if candidate != goal or any(
            type(candidate[key]) is not type(value) for key, value in goal.items()
        ):
            raise _reject()
        sources.append(
            {"goal_id": identifier, "goal_version": goal["version"], "source_hash": _hash(goal)}
        )
    existing = rows(
        conn,
        """SELECT goal_id,goal_version,source_hash FROM activity_plan_sources
        WHERE task_id=:t""",
        {"t": task},
    )
    if existing or "activity_plan_sources" in current["input"]:
        _check_binding(current["input"], existing)
        _check_binding(current["input"], sources)
        return
    for source in sources:
        execute(
            conn,
            """INSERT INTO activity_plan_sources
            (owner_id,character_id,task_id,goal_id,goal_version,source_hash)
            VALUES (:o,:c,:t,:goal_id,:goal_version,:source_hash)""",
            {"o": owner, "c": character, "t": task, **source},
        )
    execute(
        conn,
        "UPDATE tasks SET input=input || CAST(:binding AS jsonb) WHERE id=:t",
        {"t": task, "binding": json.dumps({"activity_plan_sources": _source_binding(sources)})},
    )


def load_candidates(conn: Connection, owner: UUID, character: UUID, task: UUID) -> list[Row]:
    """Re-read every original source. Any stale source invalidates the whole selection."""
    current = _task(conn, owner, character, task)
    sources = rows(
        conn,
        """SELECT goal_id,goal_version,source_hash FROM activity_plan_sources
        WHERE task_id=:t""",
        {"t": task},
    )
    if not isinstance(current["input"], dict) or not 1 <= len(sources) <= 3:
        raise _reject()
    _check_binding(current["input"], sources)
    candidates = []
    for source in sources:
        goal = _goal(conn, owner, character, source["goal_id"])
        if goal["version"] != source["goal_version"] or _hash(goal) != source["source_hash"]:
            raise _reject()
        candidates.append(goal)
    return sorted(candidates, key=lambda g: (-g["priority"], g["created_at"], g["id"]))


def claim_daily_allowance(
    conn: Connection,
    owner: UUID,
    character: UUID,
    now: datetime,
) -> None:
    """Consume one planning attempt; this grants no provider/tool/budget permission."""
    if now.utcoffset() is None:
        raise _reject()
    user = one(conn, "SELECT * FROM users WHERE id=:o FOR UPDATE", {"o": owner})
    if not user or user["disabled"] or user["autonomy_paused"]:
        raise _reject()
    prefs = one(
        conn,
        """SELECT * FROM activity_planning_preferences
        WHERE owner_id=:o AND character_id=:c FOR UPDATE""",
        {"o": owner, "c": character},
    )
    if not prefs or not prefs["enabled"] or (prefs["quiet_until"] and prefs["quiet_until"] > now):
        raise _reject()
    day = now.astimezone(ZoneInfo(user["timezone"])).date()
    calls = prefs["calls_today"] if prefs["local_day"] == day else 0
    if calls >= prefs["daily_limit"]:
        raise _reject()
    execute(
        conn,
        """UPDATE activity_planning_preferences SET local_day=:d,calls_today=:n,
        version=version+1 WHERE owner_id=:o AND character_id=:c""",
        {"o": owner, "c": character, "d": day, "n": calls + 1},
    )
