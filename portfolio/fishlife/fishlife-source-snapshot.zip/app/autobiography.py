"""Deterministic autobiography projections over still-valid, owned evidence."""

import hashlib
import json
from uuid import UUID, uuid4

from sqlalchemy import Connection

from app.errors import BusinessError
from app.memory import assert_character, memory_view
from app.repository import Row, execute, one, rows


def digest(value: object) -> str:
    data = json.dumps(value, ensure_ascii=False, sort_keys=True, default=str).encode()
    return hashlib.sha256(data).hexdigest()


def sources(
    conn: Connection,
    owner: UUID,
    character: UUID,
    refs: list[Row] | None = None,
    include_facts: bool = True,
) -> tuple[list[Row], list[Row]]:
    """A snapshot resolves its own IDs, never a moving 'latest N' window."""
    memory_ids = [UUID(x["id"]) for x in refs or [] if x["kind"] == "memory"]
    event_ids = [UUID(x["id"]) for x in refs or [] if x["kind"] == "event"]
    params = {
        "o": owner,
        "c": character,
        "memory_ids": memory_ids,
        "event_ids": event_ids,
        "include_facts": include_facts,
    }
    facts = rows(
        conn,
        """SELECT m.* FROM memory_items m WHERE m.owner_id=:o AND m.character_id=:c
        AND :include_facts
        AND m.status='active' AND m.deleted_at IS NULL
        AND m.kind='fact' AND m.reality_class='user_claim' AND m.valid_from<=statement_timestamp()
        AND (m.valid_until IS NULL OR m.valid_until>statement_timestamp())
        AND (m.expires_at IS NULL OR m.expires_at>statement_timestamp())
        AND EXISTS (SELECT 1 FROM memory_sources s
          LEFT JOIN messages msg ON msg.id=s.message_id AND msg.owner_id=s.owner_id
          LEFT JOIN experience_events e ON e.id=s.event_id AND e.owner_id=s.owner_id
          WHERE s.memory_id=m.id AND s.owner_id=m.owner_id
          AND ((msg.status='completed' AND msg.role='user' AND msg.content_kind='real')
            OR (e.event_type='memory_corrected' AND e.reality_class='user_claim'
              AND e.payload->>'content'=m.content)))"""
        + (" AND m.id=ANY(:memory_ids)" if refs is not None else "")
        + " ORDER BY m.created_at DESC,m.id LIMIT 25",
        params,
    )
    segments: list[Row] = []
    for fact in facts:
        value = memory_view(conn, fact)
        segments.append(
            {
                "text": "用户曾表示：" + fact["content"],
                "reality_class": "user_claim",
                "occurred_at": fact["created_at"].isoformat(),
                "source": {
                    "kind": "memory",
                    "id": str(fact["id"]),
                    "version": fact["version"],
                    "message_ids": sorted(
                        str(x["message_id"]) for x in value["sources"] if x["message_id"]
                    ),
                    "event_ids": sorted(
                        str(x["event_id"]) for x in value["sources"] if x["event_id"]
                    ),
                },
            }
        )
    events = rows(
        conn,
        """SELECT e.id,e.occurred_at,e.payload,t.result,g.material
        FROM experience_events e JOIN task_runs r ON r.id=e.task_run_id
          AND r.owner_id=e.owner_id AND r.character_id=e.character_id
        JOIN tasks t ON t.id=r.task_id AND t.owner_id=e.owner_id
        JOIN goals g ON g.id=t.goal_id AND g.owner_id=e.owner_id
        WHERE e.owner_id=:o AND e.character_id=:c
          AND e.event_type='local_activity_completed' AND e.reality_class='observed'
          AND r.status='succeeded' AND t.status='succeeded' AND g.status='completed'
          AND e.payload->>'task_id'=t.id::text AND e.payload->>'goal_id'=g.id::text
          AND t.result->'verification'->>'all_excerpts_in_source'='true'"""
        + (" AND e.id=ANY(:event_ids)" if refs is not None else "")
        + " ORDER BY e.occurred_at DESC,e.id LIMIT 25",
        params,
    )
    for event in events:
        result, payload = event["result"], event["payload"]
        excerpts = result.get("excerpt_lines", [])
        actual = hashlib.sha256(event["material"].encode()).hexdigest()
        if (
            not excerpts
            or not all(isinstance(x, str) and x in event["material"] for x in excerpts)
            or payload.get("source_hash") != actual
            or result.get("source_hash") != actual
        ):
            continue
        segments.append(
            {
                "text": f"我完成了一次站内材料整理，核验了{len(excerpts)}个摘录；未进行外部操作。",
                "reality_class": "observed",
                "occurred_at": event["occurred_at"].isoformat(),
                "source": {
                    "kind": "event",
                    "id": str(event["id"]),
                    "event_ids": [str(event["id"])],
                    "message_ids": [],
                    "evidence_hash": digest({"payload": payload, "result": result}),
                },
            }
        )
    segments.sort(key=lambda x: (x["source"]["kind"], x["source"]["id"]))
    references = [
        {"kind": x["source"]["kind"], "id": x["source"]["id"], "sha256": digest(x)}
        for x in segments
    ]
    return references, segments


def view(conn: Connection, item: Row, state: Row) -> Row:
    result = {k: item[k] for k in ("id", "character_id", "created_at", "memory_epoch")}
    result.update(generator="source_projection_v1", status=item["status"], segments=[])
    if item["status"] != "active":
        return result
    if item["memory_epoch"] != state["memory_epoch"]:
        result["status"] = "invalidated"
        return result
    current, segments = sources(conn, item["owner_id"], item["character_id"], item["source_refs"])
    if not current or current != item["source_refs"]:
        result["status"] = "invalidated"
        return result
    result["segments"] = segments
    return result


def create(conn: Connection, owner: UUID, character: UUID) -> Row:
    state = assert_character(conn, owner, character, lock=True)
    refs, _ = sources(conn, owner, character)
    if not refs:
        raise BusinessError("NO_VERIFIED_SOURCES", "没有可用事实或已核验活动，暂不生成自传", 409)
    fingerprint = digest(refs)
    params = {"o": owner, "c": character, "e": state["memory_epoch"], "d": fingerprint}
    item = one(
        conn,
        """SELECT * FROM autobiography_snapshots WHERE owner_id=:o
        AND character_id=:c AND memory_epoch=:e AND source_digest=:d AND status='active'""",
        params,
    )
    if not item:
        item = one(
            conn,
            """INSERT INTO autobiography_snapshots
          (id,owner_id,character_id,memory_epoch,source_digest,source_refs)
          VALUES (:id,:o,:c,:e,:d,CAST(:refs AS jsonb)) RETURNING *""",
            {**params, "id": uuid4(), "refs": json.dumps(refs)},
        )
    assert item
    return view(conn, item, state)


def get(conn: Connection, owner: UUID, identity: UUID, delete: bool = False) -> Row:
    item = one(
        conn,
        "SELECT * FROM autobiography_snapshots WHERE id=:id AND owner_id=:o",
        {"id": identity, "o": owner},
    )
    if not item:
        raise BusinessError("NOT_FOUND", "自传摘要不存在", 404)
    state = assert_character(conn, owner, item["character_id"], lock=True)
    # Re-read after the character lock to serialize deletion and generation.
    item = one(
        conn,
        "SELECT * FROM autobiography_snapshots WHERE id=:id AND owner_id=:o",
        {"id": identity, "o": owner},
    )
    assert item
    if delete:
        execute(
            conn,
            "UPDATE autobiography_snapshots SET status='deleted',source_refs='[]' WHERE id=:id",
            {"id": identity},
        )
        item.update(status="deleted", source_refs=[])
    return view(conn, item, state)


def listing(conn: Connection, owner: UUID, character: UUID) -> list[Row]:
    state = assert_character(conn, owner, character, lock=True)
    items = rows(
        conn,
        """SELECT * FROM autobiography_snapshots
      WHERE owner_id=:o AND character_id=:c AND status<>'deleted'
      ORDER BY created_at DESC,id DESC LIMIT 20""",
        {"o": owner, "c": character},
    )
    return [view(conn, item, state) for item in items]
