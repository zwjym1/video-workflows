"""Bounded POSIX execution for trusted internal callers, without a shell."""

import math
import os
import selectors
import signal
import subprocess
import sys
import time
from collections.abc import Callable, Mapping, Sequence
from pathlib import Path


class BoundedProcessError(Exception):
    """Only a generic code and outcome uncertainty are exposed."""

    def __init__(
        self, code: str, *, uncertain: bool = True, exit_code: int | None = None
    ) -> None:
        self.code = code
        self.uncertain = uncertain
        self.exit_code = exit_code
        super().__init__(code)


def _valid_text(value: object) -> bool:
    return isinstance(value, str) and "\0" not in value


def _kill_group(pid: int) -> None:
    if sys.platform == "win32":
        return
    try:
        os.killpg(pid, signal.SIGKILL)
    except ProcessLookupError:
        pass


def _exit_status(pid: int) -> int | None:
    if sys.platform == "win32":
        raise BoundedProcessError("unsupported_platform", uncertain=False)
    status = os.waitid(os.P_PID, pid, os.WEXITED | os.WNOHANG | os.WNOWAIT)
    if status is None:
        return None
    return status.si_status if status.si_code == os.CLD_EXITED else -status.si_status


def run_bounded_process(
    *,
    executable: str,
    args: Sequence[str],
    cwd: str,
    env: Mapping[str, str],
    stdin: str = "",
    timeout: float = 10,
    max_output_bytes: int = 1024 * 1024,
) -> str:
    """Return successful UTF-8 stdout; discard stderr and fail closed otherwise.

    The caller supplies the allowlisted executable, isolated working directory,
    arguments, and minimal environment. This function is not a security sandbox.
    """
    if os.name != "posix" or not all(
        hasattr(os, name) for name in ("waitid", "P_PID", "WEXITED", "WNOHANG", "WNOWAIT")
    ):
        raise BoundedProcessError("unsupported_platform", uncertain=False)
    try:
        valid = (
            _valid_text(executable)
            and Path(executable).is_absolute()
            and Path(executable).is_file()
            and os.access(executable, os.X_OK)
            and _valid_text(cwd)
            and Path(cwd).is_absolute()
            and Path(cwd).is_dir()
            and isinstance(args, Sequence)
            and not isinstance(args, (str, bytes))
            and all(_valid_text(arg) for arg in args)
            and isinstance(env, Mapping)
            and all(_valid_text(k) and k and "=" not in k and _valid_text(v)
                    for k, v in env.items())
            and isinstance(stdin, str)
            and len(stdin) <= 64 * 1024
            and type(timeout) in (int, float)
            and math.isfinite(timeout)
            and 0 < timeout <= 60
            and type(max_output_bytes) is int
            and 0 < max_output_bytes <= 1024 * 1024
        )
        payload = stdin.encode("utf-8") if valid else b""
        if not valid or len(payload) > 64 * 1024:
            raise ValueError
    except (ValueError, TypeError, OSError, OverflowError, UnicodeError):
        raise BoundedProcessError("invalid_configuration", uncertain=False) from None

    deadline = time.monotonic() + timeout
    try:
        process = subprocess.Popen(
            [executable, *args],
            cwd=cwd,
            env=dict(env),
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            shell=False,
            start_new_session=True,
        )
    except (OSError, ValueError):
        raise BoundedProcessError("start_failed", uncertain=False) from None

    killed = False

    def kill_once() -> None:
        nonlocal killed
        if not killed:
            killed = True
            _kill_group(process.pid)

    try:
        return _collect(process, payload, deadline, max_output_bytes, kill_once)
    except BoundedProcessError:
        raise
    except (OSError, ValueError, UnicodeError):
        raise BoundedProcessError("process_failed") from None
    finally:
        # WNOWAIT keeps the leader's PID reserved until group cleanup. No
        # signal may target the original group after the leader is reaped.
        kill_once()
        process.wait()
        for stream in (process.stdin, process.stdout, process.stderr):
            if stream is not None:
                stream.close()


def _collect(
    process: subprocess.Popen[bytes], payload: bytes, deadline: float, limit: int,
    kill_once: Callable[[], None],
) -> str:
    assert process.stdin is not None and process.stdout is not None and process.stderr is not None
    output = bytearray()
    total = 0
    offset = 0
    leader_exited = False
    with selectors.DefaultSelector() as selector:
        for stream, kind in ((process.stdout, "stdout"), (process.stderr, "stderr")):
            os.set_blocking(stream.fileno(), False)
            selector.register(stream, selectors.EVENT_READ, kind)
        if payload:
            os.set_blocking(process.stdin.fileno(), False)
            selector.register(process.stdin, selectors.EVENT_WRITE, "stdin")
        else:
            process.stdin.close()
        while selector.get_map() or not leader_exited:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise BoundedProcessError("timeout")
            if not leader_exited:
                exit_code = _exit_status(process.pid)
                if exit_code is not None:
                    leader_exited = True
                    kill_once()
                    if exit_code != 0:
                        raise BoundedProcessError("process_failed", exit_code=exit_code)
            for key, _ in selector.select(min(remaining, 0.02)):
                if key.data == "stdin":
                    try:
                        offset += os.write(key.fd, payload[offset:offset + 4096])
                    except BrokenPipeError:
                        offset = len(payload)
                    if offset == len(payload):
                        selector.unregister(key.fileobj)
                        process.stdin.close()
                    continue
                chunk = os.read(key.fd, min(65536, limit - total + 1))
                if not chunk:
                    selector.unregister(key.fileobj)
                    continue
                total += len(chunk)
                if total > limit:
                    raise BoundedProcessError("output_limit")
                if key.data == "stdout":
                    output.extend(chunk)
    return output.decode("utf-8")
