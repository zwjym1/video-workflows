"""Explicit opt-in to cloud title selection; this router never invokes a model."""

from typing import Literal
from uuid import UUID

from fastapi import APIRouter, Request
from pydantic import BaseModel, ConfigDict, Field, model_validator
from sqlalchemy import Connection, Engine

from app.config import Settings
from app.errors import BusinessError
from app.memory import assert_character
from app.repository import Row, execute, one
from app.security import authenticate


class PlanningPolicyBody(BaseModel):
    model_config = ConfigDict(extra="forbid")
    enabled: bool
    daily_limit: int = Field(ge=1, le=8, strict=True)
    expected_version: int = Field(ge=0, strict=True)
    cloud_title_consent: Literal["允许将候选目标标题发送给Qoder进行选择"] | None = None

    @model_validator(mode="after")
    def require_consent(self) -> "PlanningPolicyBody":
        if self.enabled and self.cloud_title_consent is None:
            raise ValueError("Explicit cloud-title consent required")
        return self


def _installed(conn: Connection) -> bool:
    value = one(conn, "SELECT to_regclass('public.activity_planning_preferences') AS name")
    return bool(value and value["name"] is not None)


def _view(row: Row | None, capability: bool) -> Row:
    return {
        "enabled": bool(row and row["enabled"]),
        "capability_enabled": capability,
        "daily_limit": row["daily_limit"] if row else 4,
        "version": row["version"] if row else 0,
        "local_day": row["local_day"] if row else None,
        "calls_today": row["calls_today"] if row else 0,
        "quiet_until": row["quiet_until"] if row else None,
        "input_scope": "candidate_goal_titles_only",
    }


def activity_planning_router(engine: Engine, settings: Settings) -> APIRouter:
    routes = APIRouter()
    capability = (
        settings.model_planning_enabled
        and settings.model_provider == "qoder"
        and settings.allow_real_model_calls
    )

    @routes.get("/characters/{character_id}/planning-policy")
    def policy(character_id: UUID, request: Request) -> Row:
        user = authenticate(request, engine, settings)
        with engine.connect() as conn:
            assert_character(conn, user["id"], character_id)
            row = (
                one(
                    conn,
                    """SELECT * FROM activity_planning_preferences
                    WHERE owner_id=:o AND character_id=:c""",
                    {"o": user["id"], "c": character_id},
                )
                if _installed(conn)
                else None
            )
        return _view(row, capability)

    @routes.patch("/characters/{character_id}/planning-policy")
    def change_policy(character_id: UUID, request: Request, body: PlanningPolicyBody) -> Row:
        user = authenticate(request, engine, settings, True)
        params = {"o": user["id"], "c": character_id, "e": body.enabled, "limit": body.daily_limit}
        with engine.begin() as conn:
            one(conn, "SELECT id FROM users WHERE id=:o FOR UPDATE", params)
            assert_character(conn, user["id"], character_id, lock=True)
            if body.enabled and not capability:
                raise BusinessError("MODEL_PLANNING_UNAVAILABLE", "当前服务尚未开放模型选择", 409)
            if not _installed(conn):
                raise BusinessError("MODEL_PLANNING_UNAVAILABLE", "规划存储尚未安装", 409)
            old = one(
                conn,
                """SELECT * FROM activity_planning_preferences
                WHERE owner_id=:o AND character_id=:c FOR UPDATE""",
                params,
            )
            if (old["version"] if old else 0) != body.expected_version:
                raise BusinessError("PLANNING_POLICY_CHANGED", "规划设置已变化，请刷新后重试", 409)
            row = one(
                conn,
                """INSERT INTO activity_planning_preferences
                (owner_id,character_id,enabled,daily_limit)
                VALUES (:o,:c,:e,:limit) ON CONFLICT(owner_id,character_id) DO UPDATE
                SET enabled=EXCLUDED.enabled,daily_limit=EXCLUDED.daily_limit,
                version=activity_planning_preferences.version+1 RETURNING *""",
                params,
            )
            if not body.enabled:
                execute(
                    conn,
                    """UPDATE task_runs SET status='cancelled',finished_at=now(),
                    error_code='PLANNING_DISABLED'
                    WHERE owner_id=:o AND character_id=:c AND status='running' AND task_id IN
                    (SELECT id FROM tasks WHERE owner_id=:o AND character_id=:c
                    AND kind='activity_plan')""",
                    params,
                )
                execute(
                    conn,
                    """UPDATE tasks SET status='cancelled',cancel_requested=true,
                    fencing_token=fencing_token+1,lease_until=NULL,error_code='PLANNING_DISABLED'
                    WHERE owner_id=:o AND character_id=:c AND kind='activity_plan'
                    AND status IN ('queued','retry_wait','running')""",
                    params,
                )
        return _view(row, capability)

    return routes
