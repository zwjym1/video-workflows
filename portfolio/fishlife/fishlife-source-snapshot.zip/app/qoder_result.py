"""Offline validation of the official SDK result envelope; no execution or settlement."""

import json
from dataclasses import dataclass
from decimal import Decimal
from typing import Any
from uuid import UUID

from app.memory import extract_claims
from app.model_client import ModelFailure, ModelResult, QoderUsageReport


@dataclass(frozen=True)
class QoderReceipt:
    reply: ModelResult
    session_id: str
    model: str
    reported_cost_usd: Decimal
    reported_credits: Decimal | None
    cache_read_tokens: int
    cache_creation_tokens: int


def _object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    value: dict[str, Any] = {}
    for key, item in pairs:
        if key in value:
            raise ValueError("Duplicate JSON key")
        value[key] = item
    return value


def _invalid_constant(_: str) -> None:
    raise ValueError("Non-finite JSON number")


def _json(raw: str) -> Any:
    return json.loads(
        raw, object_pairs_hook=_object, parse_float=Decimal, parse_constant=_invalid_constant
    )


def _tokens(value: Any) -> int:
    if type(value) is not int or not 0 <= value <= 10_000_000:
        raise ValueError("Invalid usage")
    return value


def _money(value: Any) -> Decimal:
    if type(value) not in (int, Decimal):
        raise ValueError("Invalid reported amount")
    amount = Decimal(value)
    if not amount.is_finite() or not 0 <= amount <= 1_000_000:
        raise ValueError("Invalid reported amount")
    return amount


def _database_text(value: str) -> None:
    if "\0" in value:
        raise ValueError("NUL is not database text")
    value.encode("utf8", errors="strict")


def parse_model_output(raw: str, *, expected_model: str) -> ModelResult:
    """Validate one official final receipt, leaving task-specific JSON to its caller.

    No claims or execution authority are inferred from the model's text. The
    provider report remains unverified billing even after a valid response.
    """
    try:
        if expected_model not in ("DeepSeek-Flash", "Qwen3.8-Flash"):
            raise ValueError("Unexpected model")
        if not isinstance(raw, str) or len(raw.encode("utf8")) > 262144:
            raise ValueError("Oversized result")
        data = _json(raw)
        if not isinstance(data, dict):
            raise ValueError("Missing result")
        if (
            data.get("type") != "result"
            or data.get("subtype") != "success"
            or data.get("is_error") is not False
            or type(data.get("num_turns")) is not int
            or data["num_turns"] != 1
            or data.get("stop_reason") != "end_turn"
            or data.get("terminal_reason") is not None
            or data.get("permission_denials") != []
            or data.get("deferred_tool_use") is not None
        ):
            raise ValueError("Unconfirmed completion")
        session, receipt = data.get("session_id"), data.get("uuid")
        if not isinstance(session, str) or not isinstance(receipt, str):
            raise ValueError("Missing identity")
        UUID(session)
        UUID(receipt)
        cost = _money(data.get("total_cost_usd"))
        credits = _money(data["total_credits"]) if "total_credits" in data else None
        usage, models = data.get("usage"), data.get("modelUsage")
        if not isinstance(usage, dict) or not isinstance(models, dict):
            raise ValueError("Missing usage")
        internal = {"DeepSeek-Flash": "dfmodel", "Qwen3.8-Flash": "qfmodel"}[expected_model]
        model_key = expected_model if set(models) == {expected_model} else internal
        if set(models) != {model_key} or not isinstance(models[model_key], dict):
            raise ValueError("Unexpected model usage")
        model = models[model_key]
        fields = (
            ("input_tokens", "inputTokens"),
            ("output_tokens", "outputTokens"),
            ("cache_read_input_tokens", "cacheReadInputTokens"),
            ("cache_creation_input_tokens", "cacheCreationInputTokens"),
        )
        counts = [_tokens(usage.get(key)) for key, _ in fields]
        if counts != [_tokens(model.get(key)) for _, key in fields]:
            raise ValueError("Inconsistent usage")
        if _tokens(model.get("webSearchRequests")) != 0 or _money(model.get("costUSD")) != cost:
            raise ValueError("Inconsistent cost or tool usage")
        tools = usage.get("server_tool_use")
        if not isinstance(tools, dict) or any(
            _tokens(tools.get(key)) != 0 for key in ("web_fetch_requests", "web_search_requests")
        ):
            raise ValueError("Unexpected server tool usage")
        text = data.get("result")
        if not isinstance(text, str):
            raise ValueError("Missing reply")
        _database_text(text)
        return ModelResult(
            text,
            [],
            counts[0],
            counts[1],
            receipt,
            QoderUsageReport(expected_model, session, cost, credits, counts[2], counts[3]),
        )
    except (ValueError, TypeError, KeyError, RecursionError, ArithmeticError):
        raise ModelFailure("QODER_RESULT_UNVERIFIED", uncertain=True) from None


def parse_result(
    raw: str, *, expected_model: str, source_content: str, source_kind: str
) -> QoderReceipt:
    """Apply the chat schema and sourced-memory policy after receipt validation."""
    output = parse_model_output(raw, expected_model=expected_model)
    try:
        body = _json(output.text)
        if not isinstance(body, dict) or set(body) != {"reply", "memory_quotes"}:
            raise ValueError("Invalid structured reply")
        reply, quotes = body["reply"], body["memory_quotes"]
        if not isinstance(reply, str) or not reply.strip() or len(reply) > 12000:
            raise ValueError("Invalid reply text")
        _database_text(reply)
        if (
            not isinstance(quotes, list)
            or len(quotes) > 5
            or any(not isinstance(quote, str) or len(quote) > 300 for quote in quotes)
        ):
            raise ValueError("Invalid source quotes")
        for quote in quotes:
            _database_text(quote)
        claims = [c for c in extract_claims(source_content, source_kind) if c.quote in quotes]
        report = output.qoder_usage
        assert report is not None
        return QoderReceipt(
            ModelResult(
                reply,
                claims,
                output.input_tokens,
                output.output_tokens,
                output.request_id,
                report,
            ),
            report.session_id,
            expected_model,
            report.reported_cost_usd,
            report.reported_credits,
            report.cache_read_tokens,
            report.cache_creation_tokens,
        )
    except (ValueError, TypeError, KeyError, RecursionError, ArithmeticError):
        raise ModelFailure("QODER_RESULT_UNVERIFIED", uncertain=True) from None
