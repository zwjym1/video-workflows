"""Stable local title matching inside the already bounded goal candidate set."""

from collections.abc import Sequence

from app.repository import Row


def rank_candidates(candidates: Sequence[Row], interests: object) -> list[Row]:
    """Keep priority authoritative; literal interests only break existing ties.

    The caller supplies the existing three SQL-ranked candidates. No material,
    memories, network or model calls are inspected, and equal scores retain the
    SQL created_at/id order. Bad or oversized interests are ignored.
    """
    if not isinstance(interests, list):
        return list(candidates)
    terms = {
        value.strip().casefold()
        for value in interests[:20]
        if isinstance(value, str) and 0 < len(value) <= 120 and value.strip()
    }
    if not terms:
        return list(candidates)

    def score(candidate: Row) -> tuple[int, int]:
        title = candidate["title"].casefold()
        return -candidate["priority"], -sum(term in title for term in terms)

    return sorted(candidates, key=score)
