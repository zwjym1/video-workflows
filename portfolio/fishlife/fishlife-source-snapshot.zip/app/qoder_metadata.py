"""Read-only SDK metadata transport. No prompt, inference or account approval."""

import json
import math
import re
from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import PurePosixPath
from types import MappingProxyType
from typing import Any

from app.model_client import ModelFailure
from app.qoder_executor import QoderMetadata
from app.qoder_invocation import QoderInvocation
from app.qoder_platform import Platform, minimal_environment, run_native_process, validate_path
from app.qoder_routing import cli_model_name

ROOT_KEYS = {
    "schema_version",
    "protocol_mode",
    "status",
    "queried_at",
    "plan",
    "account_scope",
    "selected_models",
    "ds_free_remaining",
    "prompt_sent",
    "inference_requested",
    "cleanup_complete",
}
MODEL_KEYS = {"id", "name", "source", "enabled", "free", "price_factor"}


def _object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    value: dict[str, Any] = {}
    for key, item in pairs:
        if key in value:
            raise ValueError("Duplicate metadata key")
        value[key] = item
    return value


def _constant(_: str) -> None:
    raise ValueError("Non-finite metadata")


def parse_metadata(raw: str, *, now: datetime) -> QoderMetadata:
    """Validate sanitized bridge output, never an API client's supplied snapshot."""
    try:
        if not isinstance(raw, str) or len(raw.encode("utf8")) > 16384:
            raise ValueError("Invalid metadata size")
        data = json.loads(raw, object_pairs_hook=_object, parse_constant=_constant)
        if not isinstance(data, dict) or set(data) != ROOT_KEYS:
            raise ValueError("Unexpected metadata fields")
        if (
            type(data["schema_version"]) is not int
            or data["schema_version"] != 1
            or data["protocol_mode"] != "metadata_only"
            or data["status"] != "received"
            or data["prompt_sent"] is not False
            or data["inference_requested"] is not False
            or data["cleanup_complete"] is not True
            or data["ds_free_remaining"] is not None
        ):
            raise ValueError("Unconfirmed read-only metadata")
        scope, plan, at = data["account_scope"], data["plan"], data["queried_at"]
        if not isinstance(scope, str) or re.fullmatch(r"[0-9a-f]{64}", scope) is None:
            raise ValueError("Unverified account")
        if (
            not isinstance(plan, str)
            or not plan.strip()
            or len(plan) > 80
            or any(ord(c) < 32 for c in plan)
        ):
            raise ValueError("Invalid plan")
        if not isinstance(at, str) or len(at) > 80:
            raise ValueError("Missing query time")
        queried = datetime.fromisoformat(at)
        if (
            now.tzinfo is None
            or now.utcoffset() is None
            or queried.tzinfo is None
            or queried.utcoffset() is None
            or not 0 <= (now - queried).total_seconds() <= 30
        ):
            raise ValueError("Expired metadata")
        models = data["selected_models"]
        if not isinstance(models, list) or len(models) > 2:
            raise ValueError("Invalid model projection")
        identities = set()
        for item in models:
            if not isinstance(item, dict) or set(item) != MODEL_KEYS:
                raise ValueError("Unexpected model fields")
            identity = item["id"]
            if identity not in ("dfmodel", "qfmodel") or identity in identities:
                raise ValueError("Unexpected or duplicate model")
            identities.add(identity)
            if item["name"] != cli_model_name(identity):
                raise ValueError("Unexpected model name")
            if any(
                item[key] is not None and type(item[key]) is not bool for key in ("enabled", "free")
            ):
                raise ValueError("Invalid model flags")
            price = item["price_factor"]
            if price is not None and (
                type(price) not in (int, float)
                or not math.isfinite(price)
                or not 0 <= price <= 1_000_000
            ):
                raise ValueError("Invalid model price")
            source = item["source"]
            if source is not None and (
                not isinstance(source, str) or len(source) > 40 or any(ord(c) < 32 for c in source)
            ):
                raise ValueError("Invalid model source")
        snapshot = {key: data[key] for key in ("status", "queried_at", "plan", "selected_models")}
        return QoderMetadata(snapshot, scope, None)
    except (ValueError, TypeError, KeyError, RecursionError, ArithmeticError):
        raise ModelFailure("QODER_METADATA_UNVERIFIED") from None


@dataclass(frozen=True)
class MetadataPaths:
    node: str
    bridge: str
    cwd: str
    config_dir: str
    cli: str
    platform: Platform = "posix"

    def __post_init__(self) -> None:
        for value in (self.node, self.bridge, self.cwd, self.config_dir, self.cli):
            validate_path(value, self.platform)


def _run(invocation: QoderInvocation) -> str:
    return run_native_process(
        executable=invocation.executable,
        args=invocation.args,
        cwd=invocation.cwd,
        env=invocation.env,
        stdin=invocation.stdin,
        timeout=invocation.timeout,
        max_output_bytes=invocation.max_output_bytes,
    )


class MetadataTransport:
    def __init__(
        self,
        paths: MetadataPaths,
        *,
        runner: Callable[[QoderInvocation], str] = _run,
        clock: Callable[[], datetime] = lambda: datetime.now(UTC),
    ) -> None:
        self.paths, self.runner, self.clock = paths, runner, clock

    def __call__(self) -> QoderMetadata:
        paths = self.paths
        invocation = QoderInvocation(
            paths.node,
            (paths.bridge,),
            paths.cwd,
            MappingProxyType(
                {
                    "LANG": "C.UTF-8",
                    "HOME": paths.cwd,
                    "PATH": str(PurePosixPath(paths.node).parent),
                    "QODERCN_CONFIG_DIR": paths.config_dir,
                    "FISHLIFE_QODER_CLI": paths.cli,
                    **minimal_environment(paths.node, paths.cwd, paths.config_dir, paths.platform),
                }
            ),
            "",
            timeout=30,
            max_output_bytes=16384,
        )
        try:
            return parse_metadata(self.runner(invocation), now=self.clock())
        except ModelFailure:
            raise
        except Exception:
            raise ModelFailure("QODER_METADATA_UNAVAILABLE") from None
