from datetime import UTC, datetime, timedelta
from typing import Literal
from uuid import UUID, uuid4

from fastapi import APIRouter, Query, Request
from pydantic import BaseModel, Field, field_validator
from sqlalchemy import Engine

from app.config import Settings
from app.errors import BusinessError
from app.life_service import check_version, owned
from app.living import autonomy, cancel_local, delete_goal, journal_view, set_autonomy, wake
from app.memory import assert_character
from app.pagination import decode_cursor, encode_cursor
from app.repository import Row, one, rows
from app.security import authenticate
from app.tool_service import invalidate_goal_files


class GoalBody(BaseModel):
    title: str = Field(min_length=1, max_length=120)
    material: str = Field(min_length=1, max_length=6000)
    priority: int = Field(default=3, ge=1, le=5)

    @field_validator("title", "material")
    @classmethod
    def not_blank(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("Blank material/title is not allowed")
        return value.strip()


class GoalPatch(BaseModel):
    status: Literal["active", "cancelled"]


class ScheduleBody(BaseModel):
    interval_seconds: int = Field(default=3600, ge=60, le=86400)
    enabled: bool = True


class AutonomyBody(BaseModel):
    enabled: bool


def living_router(engine: Engine, settings: Settings) -> APIRouter:
    routes = APIRouter()

    def user(request: Request, write: bool = False) -> Row:
        return authenticate(request, engine, settings, write)

    @routes.get("/characters/{character_id}/goals")
    def goals(
        character_id: UUID,
        request: Request,
        limit: int = Query(default=100, ge=1, le=100),
        cursor: str | None = Query(default=None, max_length=512),
    ) -> Row:
        return history(character_id, request, "goals", limit, cursor)

    @routes.post("/characters/{character_id}/goals", status_code=201)
    def new_goal(character_id: UUID, body: GoalBody, request: Request) -> Row:
        current = user(request, True)
        with engine.begin() as conn:
            assert_character(conn, current["id"], character_id, lock=True)
            count = one(
                conn,
                "SELECT count(*) AS n FROM goals WHERE character_id=:c AND status='active'",
                {"c": character_id},
            )
            if count and count["n"] >= 100:
                raise BusinessError("GOAL_LIMIT", "最多保留100个待处理目标", 409)
            result = one(
                conn,
                """INSERT INTO goals(id,owner_id,character_id,title,material,priority)
                VALUES (:id,:o,:c,:t,:m,:p) RETURNING *""",
                {
                    "id": uuid4(),
                    "o": current["id"],
                    "c": character_id,
                    "t": body.title,
                    "m": body.material,
                    "p": body.priority,
                },
            )
            assert result
            return result

    @routes.patch("/goals/{goal_id}")
    def patch_goal(goal_id: UUID, body: GoalPatch, request: Request) -> Row:
        current = user(request, True)
        with engine.begin() as conn:
            before = owned(conn, "goals", current["id"], goal_id)
            assert_character(conn, current["id"], before["character_id"], lock=True)
            before = owned(conn, "goals", current["id"], goal_id, lock=True)
            check_version(before, request.headers.get("if-match"))
            if before["status"] in ("deleted", "completed"):
                raise BusinessError(
                    "GOAL_FINISHED", "已完成或删除的目标不能重新启动，请创建新目标", 409
                )
            if body.status == "cancelled":
                cancel_local(conn, current["id"], before["character_id"], goal_id)
            result = one(
                conn,
                """UPDATE goals SET status=:s,version=version+1,updated_at=now()
                WHERE id=:id RETURNING *""",
                {"s": body.status, "id": goal_id},
            )
            assert result
            return result

    @routes.delete("/goals/{goal_id}")
    def forget_goal(goal_id: UUID, request: Request) -> Row:
        owner = user(request, True)["id"]
        result = delete_goal(engine, owner, goal_id)
        invalidate_goal_files(engine, settings, owner, goal_id)
        return result

    @routes.get("/characters/{character_id}/autonomy")
    def get_autonomy(character_id: UUID, request: Request) -> Row:
        current = user(request)
        with engine.connect() as conn:
            return autonomy(conn, current["id"], character_id, settings)

    @routes.patch("/characters/{character_id}/autonomy")
    def patch_autonomy(character_id: UUID, body: AutonomyBody, request: Request) -> Row:
        return set_autonomy(engine, user(request, True)["id"], character_id, body.enabled, settings)

    @routes.post("/characters/{character_id}/wake", status_code=202)
    def wake_character(character_id: UUID, request: Request) -> Row:
        current = user(request, True)
        try:
            key = UUID(request.headers.get("idempotency-key", ""))
        except ValueError as exc:
            raise BusinessError("IDEMPOTENCY_REQUIRED", "请提供UUID请求标识", 400) from exc
        return wake(engine, current["id"], character_id, str(key), settings)

    @routes.get("/characters/{character_id}/schedules")
    def schedules(character_id: UUID, request: Request) -> Row:
        current = user(request)
        with engine.connect() as conn:
            assert_character(conn, current["id"], character_id)
            return {
                "items": rows(
                    conn,
                    "SELECT * FROM scheduled_jobs WHERE owner_id=:o AND character_id=:c",
                    {"o": current["id"], "c": character_id},
                ),
                "next_cursor": None,
            }

    @routes.post("/characters/{character_id}/schedules", status_code=201)
    def new_schedule(character_id: UUID, body: ScheduleBody, request: Request) -> Row:
        current = user(request, True)
        with engine.begin() as conn:
            assert_character(conn, current["id"], character_id, lock=True)
            if one(
                conn, "SELECT id FROM scheduled_jobs WHERE character_id=:c", {"c": character_id}
            ):
                raise BusinessError("SCHEDULE_EXISTS", "角色已有日程，请编辑原日程", 409)
            result = one(
                conn,
                """INSERT INTO scheduled_jobs
                (id,owner_id,character_id,interval_seconds,enabled,next_run_at)
                VALUES (:id,:o,:c,:i,:e,:n) RETURNING *""",
                {
                    "id": uuid4(),
                    "o": current["id"],
                    "c": character_id,
                    "i": body.interval_seconds,
                    "e": body.enabled,
                    "n": datetime.now(UTC) + timedelta(seconds=body.interval_seconds),
                },
            )
            assert result
            return result

    @routes.patch("/schedules/{schedule_id}")
    def patch_schedule(schedule_id: UUID, body: ScheduleBody, request: Request) -> Row:
        current = user(request, True)
        with engine.begin() as conn:
            before = owned(conn, "scheduled_jobs", current["id"], schedule_id)
            assert_character(conn, current["id"], before["character_id"], lock=True)
            before = owned(conn, "scheduled_jobs", current["id"], schedule_id, lock=True)
            check_version(before, request.headers.get("if-match"))
            result = one(
                conn,
                """UPDATE scheduled_jobs SET interval_seconds=:i,enabled=:e,
                next_run_at=:n,version=version+1 WHERE id=:id RETURNING *""",
                {
                    "i": body.interval_seconds,
                    "e": body.enabled,
                    "n": datetime.now(UTC) + timedelta(seconds=body.interval_seconds),
                    "id": schedule_id,
                },
            )
            assert result
            return result

    def history(
        character_id: UUID,
        request: Request,
        kind: Literal["activities", "journals", "goals"],
        limit: int,
        cursor: str | None,
    ) -> Row:
        current = user(request)
        with engine.connect() as conn:
            assert_character(conn, current["id"], character_id)
            params = {"o": current["id"], "c": character_id, "n": limit + 1}
            sql = (
                "SELECT id,kind,goal_id,schedule_id,status,result,attempt_count,"
                "max_attempts,error_code,created_at,updated_at FROM tasks "
                "WHERE owner_id=:o AND character_id=:c "
                "AND kind IN ('local_activity','activity_plan')"
                if kind == "activities"
                else "SELECT * FROM journal_entries WHERE owner_id=:o AND character_id=:c"
            )
            if kind == "goals":
                sql = (
                    "SELECT * FROM goals WHERE owner_id=:o AND character_id=:c "
                    "AND status<>'deleted'"
                )
            if cursor:
                params["at"], params["last_id"] = decode_cursor(cursor)
                sql += " AND (created_at,id)<(:at,:last_id)"
            found = rows(conn, sql + " ORDER BY created_at DESC,id DESC LIMIT :n", params)
            more = len(found) > limit
            found = found[:limit]
            next_cursor = encode_cursor(found[-1]["created_at"], found[-1]["id"]) if more else None
            return {
                "items": [journal_view(conn, x) for x in found] if kind == "journals" else found,
                "next_cursor": next_cursor,
            }

    @routes.get("/characters/{character_id}/activities")
    def activities(
        character_id: UUID,
        request: Request,
        limit: int = Query(default=100, ge=1, le=100),
        cursor: str | None = Query(default=None, max_length=512),
    ) -> Row:
        return history(character_id, request, "activities", limit, cursor)

    @routes.get("/characters/{character_id}/journals")
    def journals(
        character_id: UUID,
        request: Request,
        limit: int = Query(default=100, ge=1, le=100),
        cursor: str | None = Query(default=None, max_length=512),
    ) -> Row:
        return history(character_id, request, "journals", limit, cursor)

    @routes.get("/journals/{journal_id}")
    def journal(journal_id: UUID, request: Request) -> Row:
        current = user(request)
        with engine.connect() as conn:
            return journal_view(conn, owned(conn, "journal_entries", current["id"], journal_id))

    return routes
