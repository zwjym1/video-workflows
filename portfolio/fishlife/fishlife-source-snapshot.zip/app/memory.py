import hashlib
import re
from dataclasses import dataclass
from typing import Any
from uuid import UUID, uuid4

from sqlalchemy import Connection

from app.repository import Row, execute, one, rows


@dataclass
class Claim:
    content: str
    quote: str
    predicate: str
    value: Any


def extract_claims(content: str, content_kind: str = "real") -> list[Claim]:
    if content_kind != "real":
        return []
    result: list[Claim] = []
    for sentence in re.split(r"[。！？!？\n]", content):
        quote = sentence.strip().strip("，,；;")
        if not quote or len(quote) > 300:
            continue
        match = re.fullmatch(r"我(不)?喜欢(.{1,100})", quote)
        if match:
            obj = match.group(2).strip()
            result.append(Claim(quote, quote, "preference:" + obj, not bool(match.group(1))))
        elif re.fullmatch(r"我叫.{1,60}", quote):
            result.append(Claim(quote, quote, "name", quote[2:]))
        elif re.fullmatch(r"我的.{1,50}是.{1,100}", quote):
            key, value = quote[2:].split("是", 1)
            result.append(Claim(quote, quote, key, value))
    return result[:5]


def retrieve(conn: Connection, owner: UUID, character: UUID, query: str) -> list[Row]:
    # Explicit keyword/recent fallback; no fake embedding is generated in mock mode.
    return rows(
        conn,
        """SELECT id,content,predicate,object_value,status FROM memory_items
        WHERE owner_id=:o AND character_id=:c AND status='active' AND deleted_at IS NULL
        AND (expires_at IS NULL OR expires_at>now()) ORDER BY
        CASE WHEN content ILIKE :q THEN 0 ELSE 1 END, created_at DESC LIMIT 8""",
        {"o": owner, "c": character, "q": "%" + query.replace("%", "").replace("_", "")[:80] + "%"},
    )


def save_claims(
    conn: Connection, owner: UUID, character: UUID, message: Row, claims: list[Claim]
) -> None:
    import json

    for claim in claims:
        if claim.quote not in message["content"] or claim.content != claim.quote:
            continue
        existing = rows(
            conn,
            """SELECT id,object_value FROM memory_items WHERE owner_id=:o
            AND character_id=:c AND predicate=:p AND status IN ('active','disputed')
            AND deleted_at IS NULL""",
            {"o": owner, "c": character, "p": claim.predicate},
        )
        matching = next((x for x in existing if x["object_value"] == claim.value), None)
        if matching:
            add_message_source(conn, owner, character, matching["id"], message, claim.quote)
            continue
        conflict = bool(existing)
        if conflict:
            execute(
                conn,
                """UPDATE memory_items SET status='disputed',version=version+1
                WHERE owner_id=:o AND character_id=:c AND predicate=:p
                AND status IN ('active','disputed')""",
                {"o": owner, "c": character, "p": claim.predicate},
            )
        memory_id = uuid4()
        execute(
            conn,
            """INSERT INTO memory_items(id,owner_id,character_id,content,predicate,
            object_value,status) VALUES (:id,:o,:c,:content,:p,CAST(:value AS jsonb),:status)""",
            {
                "id": memory_id,
                "o": owner,
                "c": character,
                "content": claim.content,
                "p": claim.predicate,
                "value": json.dumps(claim.value),
                "status": "disputed" if conflict else "active",
            },
        )
        add_message_source(conn, owner, character, memory_id, message, claim.quote)


def add_message_source(
    conn: Connection, owner: UUID, character: UUID, memory_id: UUID, message: Row, quote: str
) -> None:
    execute(
        conn,
        """INSERT INTO memory_sources(id,owner_id,character_id,memory_id,message_id,
        quote,source_hash) SELECT :id,:o,:c,:m,:msg,:q,:h WHERE NOT EXISTS
        (SELECT 1 FROM memory_sources WHERE memory_id=:m AND message_id=:msg)""",
        {
            "id": uuid4(),
            "o": owner,
            "c": character,
            "m": memory_id,
            "msg": message["id"],
            "q": quote,
            "h": hashlib.sha256(message["content"].encode()).hexdigest(),
        },
    )


def memory_view(conn: Connection, memory: Row) -> Row:
    memory["sources"] = rows(
        conn,
        """SELECT message_id,event_id,quote FROM memory_sources
        WHERE memory_id=:m AND owner_id=:o ORDER BY created_at""",
        {"m": memory["id"], "o": memory["owner_id"]},
    )
    memory["source_message_id"] = next(
        (x["message_id"] for x in memory["sources"] if x["message_id"]), None
    )
    return memory


def assert_character(conn: Connection, owner: UUID, character: UUID, lock: bool = False) -> Row:
    from app.errors import BusinessError

    state = one(
        conn,
        """SELECT s.*,c.name,c.core_persona,c.interests,c.enabled
        FROM character_states s JOIN characters c ON c.id=s.character_id
        WHERE s.owner_id=:o AND s.character_id=:c"""
        + (" FOR UPDATE OF s" if lock else ""),
        {"o": owner, "c": character},
    )
    if not state:
        raise BusinessError("NOT_FOUND", "角色不存在", 404)
    return state
