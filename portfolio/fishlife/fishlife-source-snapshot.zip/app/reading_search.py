"""Local literal keyword lookup with verified original-source excerpts."""

from uuid import UUID

from sqlalchemy import Engine

from app.config import Settings
from app.errors import BusinessError
from app.reading_service import capability, owned_book, read_snapshot, verified
from app.repository import Row


def _terms(query: str) -> list[str]:
    if not isinstance(query, str) or not 1 <= len(query) <= 120 or "\0" in query:
        raise BusinessError("READING_QUERY_INVALID", "请输入1至120字符的关键词", 422)
    try:
        query.encode("utf8")
    except UnicodeError:
        raise BusinessError("READING_QUERY_INVALID", "关键词包含无效字符", 422) from None
    tokens = query.split()
    if not tokens or len(tokens) > 10:
        raise BusinessError("READING_QUERY_INVALID", "请提供1至10个以空白分隔的关键词", 422)
    seen: set[str] = set()
    result = []
    for token in tokens:
        folded = token.casefold()
        if folded not in seen:
            seen.add(folded)
            result.append(token)
    return result


def _matches(content: str, terms: list[str]) -> tuple[list[str], int]:
    # Case folding may expand one original character into several (ß -> ss).
    # Keep original offsets rather than slicing the source with folded indexes.
    folded_parts: list[str] = []
    positions: list[int] = []
    for index, char in enumerate(content):
        folded = char.casefold()
        folded_parts.append(folded)
        positions.extend([index] * len(folded))
    text = "".join(folded_parts)
    matches = []
    first = len(content)
    for term in terms:
        offset = text.find(term.casefold())
        if offset >= 0:
            matches.append(term)
            first = min(first, positions[offset])
    return matches, first


def search_book(
    engine: Engine, settings: Settings, owner: UUID, book: UUID, query: str
) -> Row:
    capability(settings)
    terms = _terms(query)
    with read_snapshot(engine) as conn:
        value = owned_book(conn, owner, book)
        segments, _ = verified(conn, value)
        matches: list[Row] = []
        for segment in segments:
            content = segment["content"]
            found, first = _matches(content, terms)
            if not found:
                continue
            start = max(0, min(first - 120, len(content) - 400))
            matches.append(
                {
                    "ordinal": segment["ordinal"],
                    "source_hash": segment["source_hash"],
                    "start_offset": segment["start_offset"],
                    "end_offset": segment["end_offset"],
                    "excerpt": content[start : start + 400],
                    "matched_terms": found,
                }
            )
        matches.sort(key=lambda item: (-len(item["matched_terms"]), item["ordinal"]))
        return {
            "items": matches[:10],
            "total_matches": len(matches),
            "mode": "literal_keywords",
        }
