from uuid import UUID

from fastapi import APIRouter, Request
from pydantic import BaseModel, Field, field_validator
from sqlalchemy import Engine

from app.config import Settings
from app.errors import BusinessError
from app.exchanges import (
    create_exchange,
    delete_exchange,
    get_exchange,
    list_exchanges,
    relationships,
)
from app.presentation import capabilities
from app.repository import Row
from app.security import authenticate


class ExchangeBody(BaseModel):
    from_character_id: UUID
    to_character_id: UUID
    topic: str = Field(min_length=1, max_length=1000)
    client_request_id: UUID

    @field_validator("topic")
    @classmethod
    def not_blank(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("Topic cannot be blank")
        return value.strip()


def exchanges_router(engine: Engine, settings: Settings) -> APIRouter:
    routes = APIRouter()

    def user(request: Request, write: bool = False) -> Row:
        return authenticate(request, engine, settings, write)

    @routes.post("/character-exchanges", status_code=201)
    def create(body: ExchangeBody, request: Request) -> Row:
        current = user(request, True)
        if request.headers.get("idempotency-key") != str(body.client_request_id):
            raise BusinessError("IDEMPOTENCY_REQUIRED", "请求标识不匹配", 400)
        return create_exchange(
            engine,
            current["id"],
            body.from_character_id,
            body.to_character_id,
            body.topic,
            body.client_request_id,
        )

    @routes.get("/character-exchanges/{exchange_id}")
    def detail(exchange_id: UUID, request: Request) -> Row:
        return get_exchange(engine, user(request)["id"], exchange_id)

    @routes.delete("/character-exchanges/{exchange_id}")
    def remove(exchange_id: UUID, request: Request) -> Row:
        return delete_exchange(engine, user(request, True)["id"], exchange_id)

    @routes.get("/characters/{character_id}/exchanges")
    def history(character_id: UUID, request: Request) -> Row:
        return {
            "items": list_exchanges(engine, user(request)["id"], character_id),
            "next_cursor": None,
        }

    @routes.get("/characters/{character_id}/relationships")
    def relations(character_id: UUID, request: Request) -> Row:
        return {
            "items": relationships(engine, user(request)["id"], character_id),
            "next_cursor": None,
        }

    @routes.get("/presentation/capabilities")
    def presentation(request: Request) -> dict[str, object]:
        user(request)
        return capabilities()

    return routes
