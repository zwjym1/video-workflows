"""Build a fixed CLI invocation; this module never starts a process or authorizes billing."""

import json
from collections.abc import Mapping
from dataclasses import dataclass, field
from datetime import datetime
from types import MappingProxyType

from app.qoder_platform import Platform, minimal_environment, validate_path
from app.qoder_routing import choose_model, cli_model_name


@dataclass(frozen=True)
class QoderInvocation:
    executable: str
    args: tuple[str, ...]
    cwd: str
    env: Mapping[str, str]
    stdin: str = field(repr=False)
    timeout: float = 45
    max_output_bytes: int = 262144


def build_invocation(
    *,
    now: datetime,
    ds_free_available: bool | None,
    qwen_free_verified: bool,
    prompt: str,
    node: str,
    cli: str,
    cwd: str,
    config_dir: str,
    platform: Platform = "posix",
) -> QoderInvocation:
    model = cli_model_name(
        choose_model(
            now,
            ds_free_available=ds_free_available,
            qwen_free_verified=qwen_free_verified,
        )
    )
    for value in (node, cli, cwd, config_dir):
        validate_path(value, platform)
    if not isinstance(prompt, str) or not prompt.strip() or len(prompt) > 16000:
        raise ValueError("Invalid bounded prompt")
    try:
        payload = json.dumps({"context": prompt}, ensure_ascii=False)
        if len(payload.encode("utf8")) > 64000:
            raise ValueError("Invalid bounded prompt")
    except UnicodeError:
        raise ValueError("Invalid bounded prompt") from None
    args = (
        cli,
        "--print",
        "--model",
        model,
        "--output-format",
        "json",
        "--tools",
        "",
        "--disallowed-tools",
        "*",
        "--permission-mode",
        "dont_ask",
        "--mcp-config",
        '{"mcpServers":{}}',
        "--strict-mcp-config",
        "--setting-sources",
        "",
        "--no-session-persistence",
        "--max-model-request-retries",
        "0",
        "--max-output-tokens",
        "800",
    )
    return QoderInvocation(
        executable=node,
        args=args,
        cwd=cwd,
        env=MappingProxyType(minimal_environment(node, cwd, config_dir, platform)),
        stdin=payload,
    )
