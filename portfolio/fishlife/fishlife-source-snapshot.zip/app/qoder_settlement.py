"""Record an explicit manual billing attestation without changing dispatch evidence."""

import re
from decimal import Decimal
from uuid import UUID

from sqlalchemy import Engine

from app.errors import BusinessError
from app.qoder_dispatch import _account_key
from app.repository import Row, execute, one, rows

_RESULT = (
    "reservation_id",
    "dispatch_id",
    "actual_cost_usd",
    "actual_credits",
    "evidence_sha256",
    "confirmed_at",
    "verification_source",
)
_TERMINAL = {"succeeded", "failed", "unknown", "cancelled"}


def _invalid() -> BusinessError:
    return BusinessError("QODER_SETTLEMENT_INVALID", "调用尚不可人工确认或费用预留已变化", 409)


def _amount(value: Decimal) -> None:
    if (
        not isinstance(value, Decimal)
        or not value.is_finite()
        or value < 0
        or value > 1000000
        or not isinstance(value.as_tuple().exponent, int)
        or int(value.as_tuple().exponent) < -8
    ):
        raise BusinessError(
            "QODER_SETTLEMENT_INPUT_INVALID", "金额必须是非负且最多8位小数的有效数值", 422
        )


def settle_qoder(
    engine: Engine,
    owner: UUID,
    reservation_id: UUID,
    *,
    idempotency_key: UUID,
    actual_cost_usd: Decimal,
    actual_credits: Decimal,
    evidence_sha256: str,
    expected_reserved_usd: Decimal,
) -> Row:
    """Atomically settle only a terminal unknown call, attributed to its owner.

    The hash identifies the user's evidence; it does not verify supplier billing.
    Credits and dollars remain independent. An over-reservation charge is recorded
    in full against the original budget periods, with later requests budget-gated.
    """
    for amount in (actual_cost_usd, actual_credits, expected_reserved_usd):
        _amount(amount)
    if (
        not isinstance(idempotency_key, UUID)
        or not isinstance(evidence_sha256, str)
        or re.fullmatch(r"[0-9a-f]{64}", evidence_sha256) is None
    ):
        raise BusinessError("QODER_SETTLEMENT_INPUT_INVALID", "确认标识或证据摘要无效", 422)
    p = {
        "o": owner,
        "b": reservation_id,
        "key": idempotency_key,
        "cost": actual_cost_usd,
        "credits": actual_credits,
        "evidence": evidence_sha256,
        "expected": expected_reserved_usd,
    }
    with engine.begin() as conn:
        # Read only to discover the account lock. Recheck all identities under locks.
        candidate = one(
            conn,
            """SELECT d.* FROM provider_dispatches d
            JOIN budget_reservations b ON b.id=d.reservation_id AND b.owner_id=d.owner_id
            WHERE b.id=:b AND b.owner_id=:o""",
            p,
        )
        if not candidate:
            raise BusinessError("QODER_SETTLEMENT_NOT_FOUND", "调用记录不存在", 404)
        try:
            key = _account_key(candidate["account_scope"])
        except ValueError:
            raise _invalid() from None
        p.update(
            {
                "d": candidate["id"],
                "c": candidate["character_id"],
                "t": candidate["task_id"],
                "r": candidate["run_id"],
            }
        )
        execute(conn, "SELECT pg_advisory_xact_lock(:account_key)", {"account_key": key})
        user = one(conn, "SELECT id,disabled FROM users WHERE id=:o FOR UPDATE", p)
        if not user or user["disabled"]:
            raise _invalid()
        state = one(
            conn,
            """SELECT character_id FROM character_states
            WHERE owner_id=:o AND character_id=:c FOR UPDATE""",
            p,
        )
        # The owner lock serializes keys even across different account scopes.
        existing = one(
            conn,
            """SELECT * FROM qoder_settlements
            WHERE owner_id=:o AND (reservation_id=:b OR idempotency_key=:key)""",
            p,
        )
        if existing:
            if (
                existing["reservation_id"] == reservation_id
                and existing["idempotency_key"] == idempotency_key
                and existing["actual_cost_usd"] == actual_cost_usd
                and existing["actual_credits"] == actual_credits
                and existing["expected_reserved_usd"] == expected_reserved_usd
                and existing["evidence_sha256"] == evidence_sha256
            ):
                return {k: existing[k] for k in _RESULT}
            raise BusinessError(
                "QODER_SETTLEMENT_CONFLICT", "确认记录或幂等标识已存在且内容不同", 409
            )
        task = one(
            conn,
            """SELECT t.status,t.lease_until,r.status AS run_status,
            (t.lease_until>clock_timestamp()) AS active_lease
            FROM tasks t JOIN task_runs r ON r.task_id=t.id AND r.owner_id=t.owner_id
            AND r.character_id=t.character_id WHERE t.id=:t AND t.owner_id=:o
            AND t.character_id=:c AND r.id=:r FOR UPDATE OF t,r""",
            p,
        )
        dispatch = one(
            conn,
            """SELECT * FROM provider_dispatches WHERE id=:d
            AND owner_id=:o AND reservation_id=:b AND task_id=:t AND run_id=:r
            AND character_id=:c FOR UPDATE""",
            p,
        )
        reservation = one(
            conn,
            """SELECT * FROM budget_reservations
            WHERE id=:b AND owner_id=:o AND run_id=:r FOR UPDATE""",
            p,
        )
        usage = one(
            conn,
            """SELECT * FROM model_usage_logs WHERE reservation_id=:b
            AND owner_id=:o AND run_id=:r AND character_id=:c FOR UPDATE""",
            p,
        )
        if (
            not user
            or not state
            or not task
            or task["status"] not in _TERMINAL
            or task["run_status"] not in _TERMINAL
            or task["active_lease"]
            or not dispatch
            or dispatch["status"] != "unknown"
            or dispatch["account_scope"] != candidate["account_scope"]
            or not reservation
            or reservation["status"] != "unknown"
            or reservation["reserved_cost"] != expected_reserved_usd
            or not usage
            or usage["status"] != "unknown"
            or usage["provider"] != "qoder"
            or usage["model"] != dispatch["model"]
        ):
            raise _invalid()
        accounts = rows(
            conn,
            """SELECT a.*,m.reserved_amount AS held
            FROM budget_accounts a JOIN budget_reservation_accounts m ON m.account_id=a.id
            WHERE m.reservation_id=:b ORDER BY a.id FOR UPDATE OF a""",
            p,
        )
        if not accounts or any(
            a["owner_id"] != owner
            or a["held"] != expected_reserved_usd
            or a["reserved_amount"] < a["held"]
            for a in accounts
        ):
            raise _invalid()
        for account in accounts:
            execute(
                conn,
                """UPDATE budget_accounts SET reserved_amount=reserved_amount-:held,
                spent_amount=spent_amount+:cost WHERE id=:id""",
                {"held": account["held"], "cost": actual_cost_usd, "id": account["id"]},
            )
        execute(
            conn,
            """UPDATE budget_reservations SET status='settled',settled_cost=:cost,
            settled_at=clock_timestamp() WHERE id=:b""",
            p,
        )
        execute(
            conn,
            """UPDATE model_usage_logs SET status='succeeded',actual_cost_usd=:cost
            WHERE id=:u""",
            {**p, "u": usage["id"]},
        )
        result = one(
            conn,
            """INSERT INTO qoder_settlements(reservation_id,dispatch_id,
            owner_id,idempotency_key,actual_cost_usd,actual_credits,evidence_sha256,
            expected_reserved_usd) VALUES (:b,:d,:o,:key,:cost,:credits,:evidence,:expected)
            RETURNING *""",
            p,
        )
        assert result is not None
        return {k: result[k] for k in _RESULT}
