"""Cancel local reading generations without touching unrelated goals or billing."""

from uuid import UUID

from sqlalchemy import Connection

from app.repository import execute, one


def cancel_reading(
    conn: Connection,
    owner: UUID,
    character: UUID,
    book: UUID | None = None,
    *,
    bump_versions: bool = True,
) -> None:
    installed = one(conn, "SELECT to_regclass('public.books') AS name")
    if not installed or installed["name"] is None:
        return
    p = {"o": owner, "c": character, "b": book}
    selected = """SELECT id FROM tasks WHERE owner_id=:o AND character_id=:c
        AND kind='reading_step' AND (CAST(:b AS uuid) IS NULL OR reading_book_id=:b)"""
    execute(
        conn,
        """UPDATE task_runs SET status='cancelled',finished_at=now(),
        error_code='READING_PAUSED' WHERE owner_id=:o AND character_id=:c
        AND status='running' AND task_id IN ("""
        + selected
        + ")",
        p,
    )
    execute(
        conn,
        """UPDATE tasks SET status='cancelled',cancel_requested=true,
        fencing_token=fencing_token+1,lease_until=NULL,error_code='READING_PAUSED'
        WHERE id IN ("""
        + selected
        + ") AND status IN ('queued','retry_wait','running')",
        p,
    )
    if bump_versions:
        execute(
            conn,
            """UPDATE books SET version=version+1,updated_at=now()
            WHERE owner_id=:o AND character_id=:c AND status<>'deleted'
            AND (CAST(:b AS uuid) IS NULL OR id=:b)""",
            p,
        )
