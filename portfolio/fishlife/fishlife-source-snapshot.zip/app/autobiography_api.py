from uuid import UUID

from fastapi import APIRouter, Request
from sqlalchemy import Engine

from app import autobiography
from app.config import Settings
from app.repository import Row
from app.security import authenticate


def autobiography_router(engine: Engine, settings: Settings) -> APIRouter:
    routes = APIRouter()

    @routes.post("/characters/{character_id}/autobiographies", status_code=201)
    def generate(character_id: UUID, request: Request) -> Row:
        user = authenticate(request, engine, settings, True)
        with engine.begin() as conn:
            return autobiography.create(conn, user["id"], character_id)

    @routes.get("/characters/{character_id}/autobiographies")
    def listing(character_id: UUID, request: Request) -> Row:
        user = authenticate(request, engine, settings)
        with engine.begin() as conn:
            return {
                "items": autobiography.listing(conn, user["id"], character_id),
                "next_cursor": None,
            }

    @routes.get("/autobiographies/{identity}")
    def detail(identity: UUID, request: Request) -> Row:
        user = authenticate(request, engine, settings)
        with engine.begin() as conn:
            return autobiography.get(conn, user["id"], identity)

    @routes.delete("/autobiographies/{identity}")
    def delete(identity: UUID, request: Request) -> Row:
        user = authenticate(request, engine, settings, True)
        with engine.begin() as conn:
            return autobiography.get(conn, user["id"], identity, delete=True)

    return routes
