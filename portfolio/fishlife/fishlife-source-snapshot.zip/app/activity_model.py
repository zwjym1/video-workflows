"""One guarded model choice. It does not execute goals, create facts or settle billing."""

from collections.abc import Callable, Mapping
from copy import deepcopy
from dataclasses import dataclass, field
from datetime import UTC, datetime
from decimal import Decimal
from types import MappingProxyType

from sqlalchemy import Engine

from app.activity_choice import ActivityChoice, build_choice_prompt, parse_choice
from app.activity_plan_sources import load_candidates
from app.config import Settings
from app.errors import BusinessError
from app.memory import assert_character
from app.model_client import ModelFailure, ModelResult, validate_qoder_configuration
from app.qoder_catalog import select_free_model
from app.qoder_dispatch import begin_dispatch, mark_unknown, revalidate_dispatch
from app.qoder_executor import QoderMetadata
from app.qoder_invocation import QoderInvocation, build_invocation
from app.qoder_metadata import MetadataPaths, MetadataTransport
from app.qoder_platform import run_native_process
from app.qoder_result import parse_model_output
from app.qoder_routing import cli_model_name
from app.repository import Row, one


def _load_context(engine: Engine, task: Row) -> list[Row]:
    with engine.begin() as conn:
        params = {"o": task["owner_id"], "c": task["character_id"]}
        user = one(
            conn, "SELECT disabled,autonomy_paused FROM users WHERE id=:o FOR UPDATE", params
        )
        if not user or user["disabled"] or user["autonomy_paused"]:
            raise BusinessError("AUTONOMY_PAUSED", "自主活动尚未授权或已暂停", 409)
        assert_character(conn, task["owner_id"], task["character_id"], lock=True)
        policy = one(
            conn,
            """SELECT enabled FROM activity_planning_preferences
            WHERE owner_id=:o AND character_id=:c
            AND (quiet_until IS NULL OR quiet_until<=clock_timestamp())""",
            params,
        )
        if not policy or not policy["enabled"]:
            raise BusinessError("ACTIVITY_PLAN_UNAVAILABLE", "模型选择未开启或处于静默期", 409)
        return load_candidates(conn, task["owner_id"], task["character_id"], task["id"])


def _run(invocation: QoderInvocation) -> str:
    return run_native_process(
        executable=invocation.executable,
        args=invocation.args,
        cwd=invocation.cwd,
        env=invocation.env,
        stdin=invocation.stdin,
        timeout=invocation.timeout,
        max_output_bytes=invocation.max_output_bytes,
    )


@dataclass(frozen=True)
class ActivityModelOutcome:
    result: ModelResult = field(repr=False)
    choice: ActivityChoice | None
    error_code: str | None = None


@dataclass(frozen=True)
class ActivityChoiceCall:
    model_settings: Settings = field(repr=False)
    estimated_usd: Decimal
    engine: Engine = field(repr=False)
    task: Row = field(repr=False)
    candidates: tuple[Mapping[str, object], ...] = field(repr=False)
    metadata: QoderMetadata = field(repr=False)
    runner: Callable[[QoderInvocation], str] = field(repr=False)
    clock: Callable[[], datetime] = field(repr=False)

    def generate(self) -> ActivityModelOutcome:
        dispatch = None
        attempted, entered = False, False
        settings, task = self.model_settings, self.task
        try:
            validate_qoder_configuration(settings)
            if not settings.model_planning_enabled or not settings.autonomy_enabled:
                raise ModelFailure("ACTIVITY_PLAN_UNAVAILABLE")
            if self.metadata.account_scope != settings.qoder_account_scope:
                raise ModelFailure("QODER_ACCOUNT_MISMATCH")
            selected = select_free_model(
                self.metadata.snapshot,
                self.clock(),
                ds_free_remaining=self.metadata.ds_free_remaining,
            )
            if cli_model_name(selected) != settings.chat_model:
                raise ModelFailure("QODER_FREE_STATE_EXPIRED")
            invocation = build_invocation(
                now=self.clock(),
                ds_free_available=selected == "dfmodel",
                qwen_free_verified=selected == "qfmodel",
                prompt=build_choice_prompt(self.candidates),
                node=settings.qoder_node,
                cli=settings.qoder_cli,
                cwd=settings.qoder_cwd,
                config_dir=settings.qoder_config_dir,
                platform=settings.qoder_platform,
            )
            attempted = True
            dispatch = begin_dispatch(
                self.engine,
                task["owner_id"],
                task["id"],
                task["run_id"],
                expected_model=settings.chat_model,
                account_scope=self.metadata.account_scope,
                allow_reported_free=settings.qoder_continue_reported_free,
                expected_kind="activity_plan",
            )
            revalidate_dispatch(
                self.engine,
                task["owner_id"],
                dispatch,
                task["id"],
                task["run_id"],
                expected_model=settings.chat_model,
                account_scope=self.metadata.account_scope,
                allow_reported_free=settings.qoder_continue_reported_free,
                expected_kind="activity_plan",
            )
            if (
                select_free_model(
                    self.metadata.snapshot,
                    self.clock(),
                    ds_free_remaining=self.metadata.ds_free_remaining,
                )
                != selected
            ):
                raise ModelFailure("QODER_FREE_STATE_EXPIRED")
            entered = True
            result = parse_model_output(self.runner(invocation), expected_model=settings.chat_model)
            try:
                choice = parse_choice(result.text, self.candidates)
            except ValueError:
                return ActivityModelOutcome(result, None, "ACTIVITY_CHOICE_INVALID")
            return ActivityModelOutcome(result, choice)
        except Exception as error:
            if dispatch is not None:
                try:
                    mark_unknown(self.engine, task["owner_id"], dispatch)
                except Exception:
                    raise ModelFailure("QODER_OUTCOME_RECORDING_FAILED", uncertain=True) from None
            if isinstance(error, BusinessError) and not entered:
                raise
            if isinstance(error, ModelFailure):
                raise ModelFailure(error.code, uncertain=entered or error.uncertain) from None
            raise ModelFailure("ACTIVITY_PLAN_UNVERIFIED", uncertain=attempted or entered) from None


def prepare_activity_choice(
    engine: Engine,
    settings: Settings,
    task: Row,
    *,
    metadata: Callable[[], QoderMetadata] | None = None,
    runner: Callable[[QoderInvocation], str] = _run,
    clock: Callable[[], datetime] = lambda: datetime.now(UTC),
) -> ActivityChoiceCall:
    validate_qoder_configuration(settings, require_model=False)
    if (
        not settings.model_planning_enabled
        or not settings.autonomy_enabled
        or task.get("kind") != "activity_plan"
    ):
        raise ModelFailure("ACTIVITY_PLAN_UNAVAILABLE")
    candidates = _load_context(engine, task)
    if not candidates:
        raise ModelFailure("ACTIVITY_PLAN_NO_CANDIDATES")
    projected = tuple(
        MappingProxyType(
            {key: row[key] for key in ("id", "version", "title", "priority", "created_at")}
        )
        for row in candidates
    )
    prompt = build_choice_prompt(projected)
    if len(prompt.encode("utf8")) > 24000:
        raise ModelFailure("CONTEXT_TOO_LARGE")
    transport = metadata or MetadataTransport(
        MetadataPaths(
            settings.qoder_node,
            settings.qoder_bridge,
            settings.qoder_cwd,
            settings.qoder_config_dir,
            settings.qoder_cli,
            settings.qoder_platform,
        )
    )
    value = transport()
    trusted = QoderMetadata(deepcopy(value.snapshot), value.account_scope, value.ds_free_remaining)
    if trusted.account_scope != settings.qoder_account_scope:
        raise ModelFailure("QODER_ACCOUNT_MISMATCH")
    selected = select_free_model(
        trusted.snapshot, clock(), ds_free_remaining=trusted.ds_free_remaining
    )
    chosen = settings.model_copy(update={"chat_model": cli_model_name(selected)})
    validate_qoder_configuration(chosen)
    return ActivityChoiceCall(
        chosen, chosen.qoder_uncertainty_hold_usd, engine, task, projected, trusted, runner, clock
    )
