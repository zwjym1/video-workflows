import hashlib
import json
from datetime import UTC, datetime, timedelta
from uuid import UUID, uuid4

from sqlalchemy import Engine

from app.artifact_store import read_verified, remove_note, write_note
from app.config import Settings
from app.errors import BusinessError
from app.life_service import owned
from app.memory import assert_character
from app.repository import Row, execute, one, rows

ACTIONS = {"publish", "message", "purchase", "delete_files", "account_settings"}


def payload_hash(action: str, payload: Row) -> str:
    return hashlib.sha256(
        json.dumps(
            {"action": action, "payload": payload},
            sort_keys=True,
            ensure_ascii=False,
            separators=(",", ":"),
        ).encode()
    ).hexdigest()


def artifact_view(value: Row) -> Row:
    return {**value, "download_url": f"/api/v1/artifacts/{value['id']}/download"}


def preview_view(value: Row, *, now: datetime | None = None) -> Row:
    status = value["status"]
    if status == "pending" and value["expires_at"] <= (now or datetime.now(UTC)):
        status = "expired"
    return {**value, "status": status, "execution_supported": False}


def export_note(
    engine: Engine,
    settings: Settings,
    owner: UUID,
    character: UUID,
    goal_id: UUID,
    request_key: UUID,
) -> Row:
    # Persisted execution ID also identifies a possible file left by a crash.
    identity = execution = uuid4()
    with engine.begin() as conn:
        state = assert_character(conn, owner, character, lock=True)
        started_epoch = state["tools_epoch"]
        if not state["tools_enabled"]:
            raise BusinessError("TOOLS_PAUSED", "本地工具已暂停", 409)
        goal = owned(conn, "goals", owner, goal_id)
        if goal["character_id"] != character or goal["status"] != "completed":
            raise BusinessError("GOAL_NOT_READY", "仅能导出本角色已完成目标", 409)
        prior = one(
            conn,
            "SELECT * FROM tool_execution_logs WHERE owner_id=:o AND request_key=:k",
            {"o": owner, "k": request_key},
        )
        if prior:
            if prior["goal_id"] != goal_id:
                raise BusinessError("IDEMPOTENCY_CONFLICT", "请求标识已绑定其他目标", 409)
            artifact = one(
                conn, "SELECT * FROM artifacts WHERE execution_id=:e", {"e": prior["id"]}
            )
            if not artifact or artifact["status"] != "available":
                raise BusinessError(
                    "TOOL_RESULT_UNKNOWN", "此前操作没有可核验产物，禁止重复执行", 409
                )
            read_verified(
                settings.artifact_root, artifact["id"], artifact["sha256"], artifact["byte_size"]
            )
            return artifact_view(artifact)
        task = one(
            conn,
            """SELECT result FROM tasks WHERE goal_id=:g
                   AND kind='local_activity' AND status='succeeded'""",
            {"g": goal_id},
        )
        if not task or not task["result"]:
            raise BusinessError("GOAL_NOT_VERIFIED", "目标没有核验完成结果", 409)
        result = task["result"]
        source_hash = hashlib.sha256(goal["material"].encode()).hexdigest()
        excerpts = result.get("excerpt_lines", [])
        if (
            result.get("source_hash") != source_hash
            or not excerpts
            or not all(isinstance(x, str) and x in goal["material"] for x in excerpts)
        ):
            raise BusinessError("SOURCE_VERIFICATION_FAILED", "目标来源核验失败", 409)
        content = (
            f"# {goal['title']}\n\n## 用户材料摘录\n\n"
            + "\n\n".join(excerpts)
            + "\n\n## 模板建议\n\n- 复核摘录是否符合原意。\n"
            "- 由用户确认下一步；未执行外部行动。\n\n"
            + f"来源目标：{goal_id}\n\n来源SHA256：{source_hash}\n"
        )
        execute(
            conn,
            """INSERT INTO tool_execution_logs
                (id,owner_id,character_id,goal_id,tool_name,request_key,status)
                VALUES (:id,:o,:c,:g,'local_note',:k,'running')""",
            {"id": execution, "o": owner, "c": character, "g": goal_id, "k": request_key},
        )
    try:
        evidence = write_note(settings.artifact_root, identity, content)
        with engine.begin() as conn:
            state = assert_character(conn, owner, character, lock=True)
            current = owned(conn, "goals", owner, goal_id)
            if (
                not state["tools_enabled"]
                or state["tools_epoch"] != started_epoch
                or current["status"] != "completed"
            ):
                raise BusinessError("TOOL_CONTEXT_INVALIDATED", "源已删除或工具已暂停", 409)
            # Re-read actual bytes independently of writer output before claiming success.
            read_verified(
                settings.artifact_root, identity, evidence["sha256"], evidence["byte_size"]
            )
            artifact = one(
                conn,
                """INSERT INTO artifacts
                (id,owner_id,character_id,goal_id,execution_id,sha256,byte_size)
                VALUES (:id,:o,:c,:g,:e,:sha,:size) RETURNING *""",
                {
                    "id": identity,
                    "o": owner,
                    "c": character,
                    "g": goal_id,
                    "e": execution,
                    "sha": evidence["sha256"],
                    "size": evidence["byte_size"],
                },
            )
            execute(
                conn,
                """UPDATE tool_execution_logs SET status='succeeded',finished_at=now()
                    WHERE id=:id""",
                {"id": execution},
            )
            assert artifact
            return artifact_view(artifact)
    except Exception:
        try:
            remove_note(settings.artifact_root, identity)
        except OSError:
            pass
        with engine.begin() as conn:
            execute(
                conn,
                """UPDATE tool_execution_logs SET status='unknown',
                    error_code='LOCAL_WRITE_UNCONFIRMED',finished_at=now() WHERE id=:id""",
                {"id": execution},
            )
        raise


def download_note(engine: Engine, settings: Settings, owner: UUID, identity: UUID) -> bytes:
    with engine.begin() as conn:
        artifact = owned(conn, "artifacts", owner, identity)
        assert_character(conn, owner, artifact["character_id"], lock=True)
        goal = owned(conn, "goals", owner, artifact["goal_id"])
        if artifact["status"] != "available" or goal["status"] == "deleted":
            raise BusinessError("ARTIFACT_INVALIDATED", "产物来源已清理", 410)
        return read_verified(
            settings.artifact_root, identity, artifact["sha256"], artifact["byte_size"]
        )


def invalidate_goal_files(engine: Engine, settings: Settings, owner: UUID, goal_id: UUID) -> None:
    with engine.begin() as conn:
        artifacts = rows(
            conn,
            """SELECT id FROM artifacts WHERE owner_id=:o AND goal_id=:g
            UNION SELECT id FROM tool_execution_logs WHERE owner_id=:o AND goal_id=:g""",
            {"o": owner, "g": goal_id},
        )
        execute(
            conn,
            "UPDATE artifacts SET status='invalidated' WHERE owner_id=:o AND goal_id=:g",
            {"o": owner, "g": goal_id},
        )
    for artifact in artifacts:
        try:
            remove_note(settings.artifact_root, artifact["id"])
        except (OSError, BusinessError):
            with engine.begin() as conn:
                execute(
                    conn,
                    "UPDATE tool_execution_logs SET error_code='CLEANUP_PENDING' WHERE id=:id",
                    artifact,
                )
            continue
        with engine.begin() as conn:
            execute(
                conn,
                """UPDATE tool_execution_logs SET error_code='SOURCE_DELETED',
                    status=CASE WHEN status='running' THEN 'unknown' ELSE status END
                    WHERE id=:id""",
                artifact,
            )


def reconcile_tool_files(engine: Engine, settings: Settings) -> int:
    """Bounded cleanup for interrupted exports, including files without artifact metadata."""
    with engine.begin() as conn:
        stale = rows(
            conn,
            """UPDATE tool_execution_logs SET status='unknown',
            error_code='EXECUTION_INTERRUPTED',finished_at=now()
            WHERE id IN (SELECT id FROM tool_execution_logs WHERE status='running'
            AND started_at<now()-interval '5 minutes' ORDER BY started_at LIMIT 20
            FOR UPDATE SKIP LOCKED) RETURNING id""",
        )
        invalid = rows(
            conn,
            """SELECT l.id FROM tool_execution_logs l JOIN goals g ON g.id=l.goal_id
            WHERE (g.status='deleted' AND l.error_code IS DISTINCT FROM 'SOURCE_DELETED')
            OR l.error_code='CLEANUP_PENDING' ORDER BY l.started_at LIMIT 20""",
        )
        for item in invalid:
            execute(conn, "UPDATE artifacts SET status='invalidated' WHERE id=:id", item)
    for item in [*stale, *invalid]:
        try:
            remove_note(settings.artifact_root, item["id"])
        except (OSError, BusinessError):
            with engine.begin() as conn:
                execute(
                    conn,
                    "UPDATE tool_execution_logs SET error_code='CLEANUP_PENDING' WHERE id=:id",
                    item,
                )
            continue
        with engine.begin() as conn:
            execute(
                conn,
                "UPDATE tool_execution_logs SET error_code='SOURCE_DELETED' WHERE id=:id",
                item,
            )
    return len(stale) + len(invalid)


def create_preview(
    engine: Engine, owner: UUID, character: UUID, action: str, payload: Row, request_key: UUID
) -> Row:
    if action not in ACTIONS:
        raise BusinessError("TOOL_DENIED", "工具不在白名单内", 403)
    digest = payload_hash(action, payload)
    with engine.begin() as conn:
        assert_character(conn, owner, character, lock=True)
        old = one(
            conn,
            "SELECT * FROM tool_previews WHERE owner_id=:o AND request_key=:k",
            {"o": owner, "k": request_key},
        )
        if old:
            if old["payload_hash"] != digest or old["character_id"] != character:
                raise BusinessError("IDEMPOTENCY_CONFLICT", "预览标识已绑定其他参数", 409)
            return preview_view(old)
        value = one(
            conn,
            """INSERT INTO tool_previews
                (id,owner_id,character_id,request_key,action,payload,payload_hash,expires_at)
                VALUES (:id,:o,:c,:k,:a,CAST(:p AS jsonb),:h,:expiry) RETURNING *""",
            {
                "id": uuid4(),
                "o": owner,
                "c": character,
                "k": request_key,
                "a": action,
                "p": json.dumps(payload),
                "h": digest,
                "expiry": datetime.now(UTC) + timedelta(minutes=15),
            },
        )
        assert value
        return preview_view(value)


def approve_preview(engine: Engine, owner: UUID, identity: UUID, digest: str) -> Row:
    with engine.begin() as conn:
        value = owned(conn, "tool_previews", owner, identity, lock=True)
        if (
            value["status"] != "pending"
            or value["expires_at"] <= datetime.now(UTC)
            or value["payload_hash"] != digest
        ):
            raise BusinessError("APPROVAL_INVALID", "审批已过期、已处理或参数不匹配", 409)
        execute(
            conn,
            "UPDATE tool_previews SET status='approved',approved_at=now() WHERE id=:id",
            {"id": identity},
        )
        value["status"] = "approved"
        return preview_view(value)
