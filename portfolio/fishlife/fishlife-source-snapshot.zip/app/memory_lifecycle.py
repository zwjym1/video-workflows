"""Bounded ordinary-program expiry and context fencing, with no model calls."""

from datetime import datetime
from uuid import UUID

from sqlalchemy import Connection, Engine

from app.errors import BusinessError
from app.life_service import check_version, owned
from app.memory import assert_character, memory_view
from app.repository import Row, execute, one, rows


def invalidate_context(conn: Connection, state: Row) -> None:
    owner, character = state["owner_id"], state["character_id"]
    updated = one(
        conn,
        """UPDATE character_states SET memory_epoch=memory_epoch+1,
        state_version=state_version+1 WHERE character_id=:c RETURNING memory_epoch""",
        {"c": character},
    )
    assert updated
    state["memory_epoch"] = updated["memory_epoch"]
    params = {"o": owner, "c": character, "e": state["memory_epoch"]}
    execute(
        conn,
        """UPDATE conversations SET summary=NULL,summary_epoch=:e
        WHERE owner_id=:o AND character_id=:c""",
        params,
    )
    # Once the run is cancelled recovery will no longer scan it. Preserve unknown
    # charges explicitly rather than leave an orphaned "in progress" reservation.
    pending = rows(
        conn,
        """UPDATE budget_reservations SET status='unknown'
        WHERE owner_id=:o AND status='held' AND run_id IN (
          SELECT id FROM task_runs WHERE owner_id=:o AND character_id=:c AND status='running')
        RETURNING id""",
        params,
    )
    if pending:
        execute(
            conn,
            "UPDATE model_usage_logs SET status='unknown' WHERE reservation_id=ANY(:ids)",
            {"ids": [x["id"] for x in pending]},
        )
    execute(
        conn,
        """UPDATE tasks SET status='cancelled',cancel_requested=true,
        fencing_token=fencing_token+1,lease_until=NULL,lease_owner=NULL,
        error_code='CONTEXT_EXPIRED',updated_at=statement_timestamp()
        WHERE owner_id=:o AND character_id=:c AND status IN ('queued','retry_wait','running')""",
        params,
    )
    execute(
        conn,
        """UPDATE task_runs SET status='cancelled',finished_at=statement_timestamp(),
        error_code='CONTEXT_EXPIRED' WHERE owner_id=:o AND character_id=:c AND status='running'""",
        params,
    )


def expire_due(conn: Connection, state: Row) -> int:
    """Caller owns the character-state lock; time is checked after acquiring it."""
    changed = rows(
        conn,
        """UPDATE memory_items SET status='expired',version=version+1,
        updated_at=statement_timestamp() WHERE id IN (
          SELECT id FROM memory_items WHERE owner_id=:o AND character_id=:c
          AND status IN ('active','disputed') AND deleted_at IS NULL
          AND (expires_at<=statement_timestamp() OR valid_until<=statement_timestamp())
          ORDER BY created_at,id LIMIT 100) RETURNING id""",
        {"o": state["owner_id"], "c": state["character_id"]},
    )
    if changed:
        invalidate_context(conn, state)
    return len(changed)


def expire_memories_tick(engine: Engine) -> int:
    with engine.connect() as conn:
        candidates = rows(
            conn,
            """SELECT DISTINCT owner_id,character_id FROM memory_items
          WHERE status IN ('active','disputed') AND deleted_at IS NULL
          AND (expires_at<=statement_timestamp() OR valid_until<=statement_timestamp())
          ORDER BY owner_id,character_id LIMIT 20""",
        )
    count = 0
    for candidate in candidates:
        with engine.begin() as conn:
            state = one(
                conn,
                """SELECT * FROM character_states WHERE owner_id=:owner_id
                AND character_id=:character_id FOR UPDATE SKIP LOCKED""",
                candidate,
            )
            if state:
                count += expire_due(conn, state)
    return count


def set_expiration(
    engine: Engine, owner: UUID, identity: UUID, value: datetime | None, expected: str | None
) -> Row:
    with engine.begin() as conn:
        memory = owned(conn, "memory_items", owner, identity)
        state = assert_character(conn, owner, memory["character_id"], lock=True)
        memory = owned(conn, "memory_items", owner, identity, lock=True)
        check_version(memory, expected)
        if memory["status"] not in {"active", "disputed"}:
            raise BusinessError(
                "MEMORY_NOT_ACTIVE", "只能设置当前事实的期限，过期记录不能自动复活", 409
            )
        if memory["expires_at"] == value:
            return memory_view(conn, memory)
        updated = one(
            conn,
            """UPDATE memory_items SET expires_at=:expiry,version=version+1,
          status=CASE WHEN :expiry<=statement_timestamp() OR valid_until<=statement_timestamp()
            THEN 'expired' ELSE status END,updated_at=statement_timestamp()
          WHERE id=:id RETURNING *""",
            {"expiry": value, "id": identity},
        )
        assert updated
        invalidate_context(conn, state)
        return memory_view(conn, updated)
