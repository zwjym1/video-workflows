"""Bounded keyset cursors contain ordering values, never permissions."""

import base64
import binascii
import json
from datetime import datetime
from uuid import UUID

from app.errors import BusinessError


def encode_cursor(occurred_at: datetime, identity: UUID) -> str:
    raw = json.dumps([occurred_at.isoformat(), str(identity)]).encode()
    return base64.urlsafe_b64encode(raw).decode().rstrip("=")


def decode_cursor(value: str) -> tuple[datetime, UUID]:
    try:
        if len(value) > 512:
            raise ValueError("Oversized cursor")
        payload = json.loads(
            base64.b64decode(value + "=" * (-len(value) % 4), altchars=b"-_", validate=True)
        )
        if not isinstance(payload, list) or len(payload) != 2:
            raise ValueError("Invalid cursor shape")
        if not all(isinstance(item, str) for item in payload):
            raise ValueError("Invalid cursor values")
        at, identity = datetime.fromisoformat(payload[0]), UUID(payload[1])
        if at.tzinfo is None or at.utcoffset() is None:
            raise ValueError("Timezone required")
        return at, identity
    except (ValueError, TypeError, binascii.Error, UnicodeError) as exc:
        raise BusinessError("INVALID_CURSOR", "分页位置无效，请重新打开列表", 400) from exc
