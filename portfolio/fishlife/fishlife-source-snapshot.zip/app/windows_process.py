"""Bounded Windows execution for trusted callers; a Job Object is not a sandbox."""

import codecs
import ctypes
import importlib
import math
import os
import subprocess
import sys
import threading
import time
from collections.abc import Mapping, Sequence
from ctypes import wintypes
from pathlib import Path
from typing import Any

from app.bounded_process import BoundedProcessError


class _BasicLimit(ctypes.Structure):
    _fields_ = [
        ("per_process", ctypes.c_int64), ("per_job", ctypes.c_int64),
        ("flags", wintypes.DWORD), ("min_working_set", ctypes.c_size_t),
        ("max_working_set", ctypes.c_size_t), ("active_processes", wintypes.DWORD),
        ("affinity", ctypes.c_size_t), ("priority", wintypes.DWORD),
        ("scheduling", wintypes.DWORD),
    ]


class _IoCounters(ctypes.Structure):
    _fields_ = [(name, ctypes.c_uint64) for name in
                ("read_ops", "write_ops", "other_ops", "read_bytes", "write_bytes", "other_bytes")]


class _ExtendedLimit(ctypes.Structure):
    _fields_ = [
        ("basic", _BasicLimit), ("io", _IoCounters),
        ("process_memory", ctypes.c_size_t), ("job_memory", ctypes.c_size_t),
        ("peak_process", ctypes.c_size_t), ("peak_job", ctypes.c_size_t),
    ]


def _kernel_api() -> Any:
    ctypes_windows: Any = ctypes
    kernel = ctypes_windows.WinDLL("kernel32", use_last_error=True)
    signatures = {
        "CreateJobObjectW": ([ctypes.c_void_p, wintypes.LPCWSTR], wintypes.HANDLE),
        "SetInformationJobObject": (
            [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD], wintypes.BOOL),
        "AssignProcessToJobObject": ([wintypes.HANDLE, wintypes.HANDLE], wintypes.BOOL),
        "TerminateJobObject": ([wintypes.HANDLE, wintypes.UINT], wintypes.BOOL),
        "ResumeThread": ([wintypes.HANDLE], wintypes.DWORD),
    }
    for name, (args, result) in signatures.items():
        function = getattr(kernel, name)
        function.argtypes = args
        function.restype = result
    return kernel


def _validate(
    executable: str, args: Sequence[str], cwd: str, env: Mapping[str, str],
    stdin: str, timeout: float, max_output_bytes: int,
) -> bytes:
    def text(value: object) -> bool:
        return isinstance(value, str) and "\0" not in value

    try:
        valid = (
            text(executable) and Path(executable).is_absolute() and Path(executable).is_file()
            and text(cwd) and Path(cwd).is_absolute() and Path(cwd).is_dir()
            and isinstance(args, Sequence) and not isinstance(args, (str, bytes))
            and all(text(arg) for arg in args)
            and isinstance(env, Mapping)
            and all(text(k) and k and "=" not in k and text(v) for k, v in env.items())
            and isinstance(stdin, str) and len(stdin) <= 65536
            and type(timeout) in (int, float) and math.isfinite(timeout) and 0 < timeout <= 60
            and type(max_output_bytes) is int and 0 < max_output_bytes <= 1048576
        )
        if not valid:
            raise ValueError
        # Windows receives UTF-16 arguments, but reject text that cannot also be
        # represented by the bridge's strict UTF-8 input/output contract.
        for value in (executable, cwd, *args, *env.keys(), *env.values()):
            value.encode("utf-8", errors="strict")
        payload = stdin.encode("utf-8", errors="strict")
        if len(payload) > 65536 or len(subprocess.list2cmdline([executable, *args])) >= 32767:
            raise ValueError
        return payload
    except (ValueError, TypeError, OSError, OverflowError, UnicodeError):
        raise BoundedProcessError("invalid_configuration", uncertain=False) from None


def run_windows_process(
    *, executable: str, args: Sequence[str], cwd: str, env: Mapping[str, str],
    stdin: str = "", timeout: float = 10, max_output_bytes: int = 1048576,
) -> str:
    """Return strict UTF-8 stdout, with a deadline and shared stdout/stderr limit.

    Only the three pipe handles are inherited. The initial thread stays suspended
    until the child belongs to a kill-on-close job, so it cannot spawn children
    before assignment. No shell, breakaway flag, or ambient environment is used.
    This uses CPython's Windows CreateProcess wrapper for STARTUPINFOEX and its
    explicit handle list; Job Objects do not restrict filesystem/network access.
    """
    if sys.platform != "win32":
        raise BoundedProcessError("unsupported_platform", uncertain=False)
    payload = _validate(executable, args, cwd, env, stdin, timeout, max_output_bytes)
    win = importlib.import_module("_winapi")
    kernel = _kernel_api()
    deadline = time.monotonic() + timeout
    handles: set[int] = set()
    process: int | None = None
    job: int | None = None
    assigned = False
    resumed = False
    threads: list[threading.Thread] = []
    lock = threading.Lock()
    failed = threading.Event()
    output = bytearray()
    total = 0
    failure: str | None = None

    def close(handle: int) -> None:
        with lock:
            if handle not in handles:
                return
            handles.remove(handle)
        win.CloseHandle(handle)

    def fail(code: str) -> None:
        nonlocal failure
        with lock:
            if failure is None:
                failure = code
        failed.set()

    def read(handle: int, keep: bool) -> None:
        nonlocal total
        decoder = codecs.getincrementaldecoder("utf-8")("strict")
        try:
            while True:
                try:
                    chunk, _ = win.ReadFile(handle, 65536)
                except OSError as exc:
                    if exc.winerror == 109:  # ERROR_BROKEN_PIPE means EOF.
                        break
                    raise
                if not chunk:
                    break
                with lock:
                    total += len(chunk)
                    exceeded = total > max_output_bytes
                    if keep and not exceeded:
                        output.extend(chunk)
                if exceeded:
                    fail("output_limit")
                    return
                decoder.decode(chunk, final=False)
            decoder.decode(b"", final=True)
        except (OSError, UnicodeError):
            fail("process_failed")
        finally:
            close(handle)

    def write(handle: int) -> None:
        try:
            offset = 0
            while offset < len(payload):
                written, _ = win.WriteFile(handle, payload[offset:offset + 4096])
                offset += written
        except OSError as exc:
            if exc.winerror not in (109, 232):
                fail("process_failed")
        finally:
            close(handle)

    try:
        job = kernel.CreateJobObjectW(None, None)
        if not job:
            raise OSError
        handles.add(job)
        limits = _ExtendedLimit()
        limits.basic.flags = 0x2000  # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
        if not kernel.SetInformationJobObject(job, 9, ctypes.byref(limits), ctypes.sizeof(limits)):
            raise OSError
        input_read, input_write = win.CreatePipe(None, 0)
        handles.update((input_read, input_write))
        output_read, output_write = win.CreatePipe(None, 0)
        handles.update((output_read, output_write))
        error_read, error_write = win.CreatePipe(None, 0)
        handles.update((error_read, error_write))
        child_handles = [input_read, output_write, error_write]
        for handle in child_handles:
            os.set_handle_inheritable(handle, True)
        startup = subprocess.STARTUPINFO()
        startup.dwFlags = subprocess.STARTF_USESTDHANDLES
        startup.hStdInput, startup.hStdOutput, startup.hStdError = child_handles
        startup.lpAttributeList = {"handle_list": child_handles}
        process, thread, _, _ = win.CreateProcess(
            executable, subprocess.list2cmdline([executable, *args]), None, None,
            True, 0x4 | 0x8000000, dict(env), cwd, startup,
        )  # CREATE_SUSPENDED | CREATE_NO_WINDOW; wrapper supplies EXTENDED_STARTUPINFO_PRESENT.
        handles.update((process, thread))
        for handle in child_handles:
            close(handle)
        if not kernel.AssignProcessToJobObject(job, process):
            raise OSError
        assigned = True
        for target, arguments in ((read, (output_read, True)), (read, (error_read, False)),
                                  (write, (input_write,))):
            worker = threading.Thread(target=target, args=arguments, daemon=True)
            worker.start()
            threads.append(worker)
        if kernel.ResumeThread(thread) == 0xFFFFFFFF:
            raise OSError
        resumed = True
        close(thread)
        while True:
            if failed.is_set():
                raise BoundedProcessError(failure or "process_failed")
            if time.monotonic() >= deadline:
                raise BoundedProcessError("timeout")
            if win.WaitForSingleObject(process, 0) == 0:
                exit_code = win.GetExitCodeProcess(process)
                # Kill descendants even after a successful leader exit. They
                # may retain pipe handles and must not extend the call's life.
                if not kernel.TerminateJobObject(job, 1):
                    raise OSError
                for worker in threads:
                    worker.join(max(0, deadline - time.monotonic()))
                if any(worker.is_alive() for worker in threads):
                    raise BoundedProcessError("timeout")
                if exit_code != 0:
                    raise BoundedProcessError("process_failed", exit_code=exit_code)
                if failure is not None:
                    raise BoundedProcessError(failure)
                return output.decode("utf-8", errors="strict")
            failed.wait(min(0.005, max(0, deadline - time.monotonic())))
    except BoundedProcessError:
        raise
    except (OSError, ValueError, UnicodeError):
        raise BoundedProcessError(
            "process_failed" if resumed else "start_failed", uncertain=resumed,
        ) from None
    finally:
        if process is not None:
            if assigned:
                kernel.TerminateJobObject(job, 1)
            else:
                win.TerminateProcess(process, 1)
            win.WaitForSingleObject(process, 5000)
        if job is not None:
            close(job)  # Also kill the job if explicit termination failed.
        for worker in threads:
            worker.join(5)
        for handle in list(handles):
            close(handle)
