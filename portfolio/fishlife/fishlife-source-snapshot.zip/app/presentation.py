"""Optional presentation contracts; never fabricate audio or execution evidence."""

from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Literal, Protocol

from pydantic import AwareDatetime, BaseModel, ConfigDict, Field


@dataclass
class SpeechArtifact:
    audio_ref: str
    duration_seconds: float
    provider: str


class SpeechSynthesizer(Protocol):
    def synthesize(self, text: str, voice: str, format: str) -> SpeechArtifact: ...


class SpeechUnavailable(RuntimeError):
    pass


class UnavailableSpeechSynthesizer:
    def synthesize(self, text: str, voice: str, format: str) -> SpeechArtifact:
        raise SpeechUnavailable("Server TTS is not configured; no audio was generated")


class PresentationEvent(BaseModel):
    model_config = ConfigDict(extra="forbid")
    kind: Literal["idle", "working", "speaking", "stopped"]
    mood: str = Field(default="calm", max_length=40)
    gesture: str = Field(default="idle", max_length=40)
    audio_ref: str | None = Field(default=None, max_length=300)
    simulated: Literal[True] = True
    occurred_at: AwareDatetime = Field(default_factory=lambda: datetime.now(UTC))


def capabilities() -> dict[str, object]:
    return {
        "tts_provider": "browser_local_optional",
        "server_tts_available": False,
        "animation": "css",
        "live2d": False,
        "three_d": False,
    }
