"""Bounded local source processing. No model, network, filesystem or invented facts."""

import json
from datetime import UTC, datetime, timedelta
from uuid import uuid4

from sqlalchemy import Connection, Engine

from app.config import Settings
from app.errors import BusinessError
from app.queue import claim_task, recover_expired
from app.reading_service import enqueue_locked, lock_book, permitted, source_error, verified
from app.repository import Row, execute, one, rows


def _failed(conn: Connection, task: Row, code: str) -> None:
    execute(
        conn,
        """UPDATE tasks SET status='failed',error_code=:code,lease_until=NULL,
        updated_at=now() WHERE id=:t""",
        {"t": task["id"], "code": code},
    )
    execute(
        conn,
        """UPDATE task_runs SET status='failed',error_code=:code,finished_at=now()
        WHERE id=:r""",
        {"r": task["run_id"], "code": code},
    )
    execute(
        conn,
        """UPDATE books SET auto_enabled=false,version=version+1,updated_at=now()
        WHERE id=:b AND status<>'deleted'""",
        {"b": task["reading_book_id"]},
    )


def finish_reading(engine: Engine, task: Row, settings: Settings) -> bool:
    if not settings.reading_enabled:
        return False
    with engine.begin() as conn:
        try:
            user, state, book = lock_book(conn, task["owner_id"], task["reading_book_id"])
        except BusinessError:
            return False
        p = {
            "t": task["id"],
            "r": task["run_id"],
            "o": task["owner_id"],
            "c": task["character_id"],
            "b": book["id"],
        }
        current = one(
            conn,
            """SELECT t.*,r.status AS run_status,r.fencing_token AS run_fence,
            r.memory_epoch AS run_epoch FROM tasks t JOIN task_runs r ON r.task_id=t.id
            AND r.owner_id=t.owner_id AND r.character_id=t.character_id
            WHERE t.id=:t AND r.id=:r AND t.owner_id=:o AND t.character_id=:c
            FOR UPDATE OF t,r""",
            p,
        )
        if (
            not current
            or current["kind"] != "reading_step"
            or current["status"] != "running"
            or current["run_status"] != "running"
            or current["fencing_token"] != task["fencing_token"]
            or current["run_fence"] != task["fencing_token"]
        ):
            return False
        try:
            permitted(user, state, settings)
            if (
                current["cancel_requested"]
                or current["reading_book_id"] != book["id"]
                or current["reading_ordinal"] != book["cursor"]
                or current["run_epoch"] != task["memory_epoch"]
                or state["memory_epoch"] != task["memory_epoch"]
                or current["input"].get("book_version") != book["version"]
                or book["status"] != "active"
            ):
                raise source_error()
            segments, _ = verified(conn, book)
            segment = segments[book["cursor"]]
            if current["input"].get("source_hash") != segment["source_hash"]:
                raise source_error()
            excerpts = list(
                dict.fromkeys(
                    line.strip()[:220] for line in segment["content"].splitlines() if line.strip()
                )
            )[:3]
            if not excerpts or any(quote not in segment["content"] for quote in excerpts):
                raise source_error()
            # Lock waits above must not turn an expired lease into success.
            if not one(
                conn, "SELECT id FROM tasks WHERE id=:t AND lease_until>clock_timestamp()", p
            ):
                raise BusinessError("READING_LEASE_EXPIRED", "阅读任务租约已过期", 409)
        except BusinessError as error:
            _failed(conn, task, error.code)
            return False
        note_id, event_id = uuid4(), uuid4()
        payload = {
            "book_id": str(book["id"]),
            "ordinal": book["cursor"],
            "source_hash": segment["source_hash"],
        }
        execute(
            conn,
            """INSERT INTO experience_events(id,owner_id,character_id,event_type,
            reality_class,task_run_id,dedupe_key,payload)
            VALUES (:e,:o,:c,'reading_segment_processed','observed',:r,:key,
            CAST(:payload AS jsonb))""",
            {
                **p,
                "e": event_id,
                "key": "reading:" + str(book["id"]) + ":" + str(book["cursor"]),
                "payload": json.dumps(payload),
            },
        )
        execute(
            conn,
            """INSERT INTO reading_notes(id,owner_id,character_id,book_id,ordinal,
            task_id,run_id,event_id,source_hash,excerpts) VALUES
            (:n,:o,:c,:b,:ordinal,:t,:r,:e,:hash,CAST(:excerpts AS jsonb))""",
            {
                **p,
                "n": note_id,
                "ordinal": book["cursor"],
                "e": event_id,
                "hash": segment["source_hash"],
                "excerpts": json.dumps(excerpts, ensure_ascii=False),
            },
        )
        complete = book["cursor"] + 1 == book["segment_count"]
        execute(
            conn,
            """UPDATE books SET cursor=cursor+1,version=version+1,updated_at=now(),
            status=:status,auto_enabled=CASE WHEN :done THEN false ELSE auto_enabled END
            WHERE id=:b""",
            {**p, "status": "completed" if complete else "active", "done": complete},
        )
        execute(
            conn,
            """UPDATE tasks SET status='succeeded',lease_until=NULL,lease_owner=NULL,
            error_code=NULL,updated_at=now(),result=CAST(:result AS jsonb) WHERE id=:t""",
            {
                **p,
                "result": json.dumps(
                    {**payload, "note_id": str(note_id), "method": "local_extract"}
                ),
            },
        )
        execute(
            conn,
            """UPDATE task_runs SET status='succeeded',node='reading_persist',
            finished_at=now(),error_code=NULL WHERE id=:r""",
            p,
        )
        return True


def process_reading_once(engine: Engine, settings: Settings) -> bool:
    if not settings.reading_enabled or not settings.autonomy_enabled:
        return False
    recover_expired(engine, settings)
    task = claim_task(engine, "reading_step")
    if not task:
        return False
    # DB errors propagate: the lease recovers an interrupted transaction;
    # no fresh task or false success is manufactured.
    finish_reading(engine, task, settings)
    return True


def reading_tick(engine: Engine, settings: Settings, now: datetime | None = None) -> int:
    if not settings.reading_enabled or not settings.autonomy_enabled:
        return 0
    now = now or datetime.now(UTC)
    if now.utcoffset() is None:
        raise ValueError("Aware scheduler time required")
    with engine.connect() as conn:
        due = rows(
            conn,
            """SELECT b.id,b.owner_id FROM books b JOIN users u ON u.id=b.owner_id
            WHERE b.status='active' AND b.auto_enabled AND b.next_read_at<=:now
            AND NOT u.disabled AND NOT u.autonomy_paused
            ORDER BY b.next_read_at,b.id LIMIT 10""",
            {"now": now},
        )
    count = 0
    for candidate in due:
        with engine.begin() as conn:
            user, state, book = lock_book(conn, candidate["owner_id"], candidate["id"])
            if not book["auto_enabled"] or book["status"] != "active" or book["next_read_at"] > now:
                continue
            try:
                result = enqueue_locked(
                    conn,
                    settings,
                    user,
                    state,
                    book,
                    f"reading-auto:{book['id']}:{book['cursor']}:{book['version']}:"
                    f"{state['memory_epoch']}",
                    book["version"],
                )
            except BusinessError:
                execute(
                    conn,
                    "UPDATE books SET auto_enabled=false,version=version+1 WHERE id=:b",
                    {"b": book["id"]},
                )
                continue
            if result["status"] in ("failed", "unknown", "quiet"):
                execute(
                    conn,
                    "UPDATE books SET auto_enabled=false,version=version+1 WHERE id=:b",
                    {"b": book["id"]},
                )
            execute(
                conn,
                "UPDATE books SET next_read_at=:next WHERE id=:b",
                {"b": book["id"], "next": now + timedelta(seconds=book["interval_seconds"])},
            )
            count += int(result.get("task_id") is not None)
    return count
