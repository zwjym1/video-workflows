from collections.abc import Mapping
from typing import Any

from sqlalchemy import Connection, Engine, create_engine, text

from app.config import Settings

Row = dict[str, Any]


def business_engine(settings: Settings) -> Engine:
    return create_engine(
        settings.database_url.get_secret_value(),
        pool_pre_ping=True,
        connect_args={
            "connect_timeout": 2,
            "options": "-c statement_timeout=10000 -c lock_timeout=3000",
        },
    )


def one(conn: Connection, sql: str, params: Mapping[str, Any] | None = None) -> Row | None:
    value = conn.execute(text(sql), dict(params or {})).mappings().first()
    return dict(value) if value else None


def rows(conn: Connection, sql: str, params: Mapping[str, Any] | None = None) -> list[Row]:
    return [dict(x) for x in conn.execute(text(sql), dict(params or {})).mappings()]


def execute(conn: Connection, sql: str, params: Mapping[str, Any] | None = None) -> None:
    conn.execute(text(sql), dict(params or {}))
