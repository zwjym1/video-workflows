"""Prepare an exact Qoder call for the existing queue; default setup stays disabled."""

from collections.abc import Callable
from dataclasses import dataclass
from decimal import Decimal

from sqlalchemy import Engine

from app.config import Settings
from app.model_client import ModelFailure, ModelResult, estimate_cost, validate_qoder_configuration
from app.qoder_executor import PreparedQoderCall, QoderExecutor, QoderMetadata, QoderPaths
from app.qoder_invocation import QoderInvocation
from app.qoder_metadata import MetadataPaths, MetadataTransport
from app.repository import Row


@dataclass(frozen=True)
class QoderCall:
    model_settings: Settings
    estimated_usd: Decimal
    executor: QoderExecutor
    task: Row
    prepared: PreparedQoderCall

    def generate(self, context: Row) -> ModelResult:
        return self.executor.execute(self.task, context, prepared=self.prepared)


def create_qoder_call(
    engine: Engine,
    settings: Settings,
    task: Row,
    context: Row,
    *,
    metadata: Callable[[], QoderMetadata] | None = None,
    runner: Callable[[QoderInvocation], str] | None = None,
) -> QoderCall:
    """Only trusted backend/test code may replace metadata or runner dependencies.

    Reviewed is an explicit local operator acknowledgement of external history,
    never inferred from directory flags and never a claim that a bill is verified.
    """
    validate_qoder_configuration(settings, require_model=False)

    def preflight(scope: str) -> None:
        validate_qoder_configuration(settings, require_model=False)
        if scope != settings.qoder_account_scope:
            raise ModelFailure("QODER_ACCOUNT_MISMATCH")

    transport = (
        metadata
        if metadata is not None
        else MetadataTransport(
            MetadataPaths(
                settings.qoder_node,
                settings.qoder_bridge,
                settings.qoder_cwd,
                settings.qoder_config_dir,
                settings.qoder_cli,
                settings.qoder_platform,
            )
        )
    )
    paths = QoderPaths(
        settings.qoder_node,
        settings.qoder_cli,
        settings.qoder_cwd,
        settings.qoder_config_dir,
        settings.qoder_platform,
    )
    if runner is None:
        executor = QoderExecutor(
            engine, settings, paths, metadata=transport, account_preflight=preflight, enabled=True
        )
    else:
        executor = QoderExecutor(
            engine,
            settings,
            paths,
            metadata=transport,
            account_preflight=preflight,
            enabled=True,
            runner=runner,
        )
    prepared = executor.prepare(task, context)
    selected_settings = settings.model_copy(update={"chat_model": prepared.model})
    amount = estimate_cost(context, selected_settings)
    return QoderCall(selected_settings, amount, executor, task, prepared)
