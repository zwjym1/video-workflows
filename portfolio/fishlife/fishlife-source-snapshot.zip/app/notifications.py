"""Bounded, opt-in in-app sharing from real completed activity events."""

from datetime import UTC, datetime
from uuid import UUID, uuid4
from zoneinfo import ZoneInfo

from sqlalchemy import Connection, Engine

from app.config import Settings
from app.living import cancel_local
from app.memory import assert_character
from app.repository import Row, execute, one, rows


def is_quiet(now: datetime, timezone: str, start: int, end: int) -> bool:
    hour = now.astimezone(ZoneInfo(timezone)).hour
    if start == end:
        return False
    return start <= hour < end if start < end else hour >= start or hour < end


def preferences(conn: Connection, owner: UUID, lock: bool = False) -> Row:
    execute(
        conn,
        "INSERT INTO notification_preferences(owner_id) VALUES (:o) ON CONFLICT DO NOTHING",
        {"o": owner},
    )
    value = one(
        conn,
        "SELECT * FROM notification_preferences WHERE owner_id=:o"
        + (" FOR UPDATE" if lock else ""),
        {"o": owner},
    )
    assert value
    return value


def safety_status(conn: Connection, owner: UUID) -> Row:
    user = one(conn, "SELECT autonomy_paused FROM users WHERE id=:o", {"o": owner})
    pref = preferences(conn, owner)
    tools = one(
        conn,
        "SELECT COALESCE(bool_or(tools_enabled),false) AS enabled FROM character_states "
        "WHERE owner_id=:o",
        {"o": owner},
    )
    assert user and tools
    return {
        "autonomy_paused": user["autonomy_paused"],
        "notifications_enabled": pref["enabled"],
        "tools_enabled": tools["enabled"],
        "scope": "all_characters",
    }


def stop_all(engine: Engine, owner: UUID) -> Row:
    with engine.begin() as conn:
        one(conn, "SELECT id FROM users WHERE id=:o FOR UPDATE", {"o": owner})
        characters = rows(
            conn, "SELECT id FROM characters WHERE owner_id=:o ORDER BY id", {"o": owner}
        )
        # Same character -> preference lock ordering as delivery; all characters in UUID order.
        for character in characters:
            assert_character(conn, owner, character["id"], lock=True)
        preferences(conn, owner, lock=True)
        execute(
            conn,
            "UPDATE users SET autonomy_paused=true,tools_paused=true WHERE id=:o",
            {"o": owner},
        )
        execute(
            conn,
            "UPDATE character_states SET tools_enabled=false,tools_epoch=tools_epoch+1 "
            "WHERE owner_id=:o",
            {"o": owner},
        )
        execute(
            conn,
            "UPDATE notification_preferences SET enabled=false,version=version+1,updated_at=now() "
            "WHERE owner_id=:o",
            {"o": owner},
        )
        for character in characters:
            cancel_local(conn, owner, character["id"])
        return safety_status(conn, owner)


def notification_tick(engine: Engine, settings: Settings, now: datetime | None = None) -> int:
    if not settings.notifications_enabled:
        return 0
    now = now or datetime.now(UTC)
    with engine.connect() as conn:
        candidates = rows(
            conn,
            """SELECT candidate.id,candidate.owner_id,candidate.character_id FROM
            (SELECT DISTINCT ON (e.owner_id) e.id,e.owner_id,e.character_id,e.occurred_at
            FROM experience_events e
            JOIN users u ON u.id=e.owner_id
            JOIN notification_preferences p ON p.owner_id=e.owner_id
            JOIN goals g ON g.owner_id=e.owner_id AND g.character_id=e.character_id
              AND g.id::text=e.payload->>'goal_id'
            WHERE e.event_type='local_activity_completed' AND g.status='completed'
            AND p.enabled AND NOT u.autonomy_paused AND NOT u.disabled
            AND NOT EXISTS(SELECT 1 FROM notifications n WHERE n.owner_id=e.owner_id
              AND n.source_event_id=e.id)
            ORDER BY e.owner_id,e.occurred_at,e.id) candidate
            ORDER BY candidate.occurred_at,candidate.id LIMIT 20""",
        )
    delivered = 0
    seen: set[UUID] = set()
    for candidate in candidates:
        owner, character = candidate["owner_id"], candidate["character_id"]
        if owner in seen:
            continue
        seen.add(owner)
        with engine.begin() as conn:
            assert_character(conn, owner, character, lock=True)
            pref = preferences(conn, owner, lock=True)
            user = one(conn, "SELECT autonomy_paused,disabled FROM users WHERE id=:o", {"o": owner})
            if not user or user["autonomy_paused"] or user["disabled"] or not pref["enabled"]:
                continue
            if is_quiet(now, pref["timezone"], pref["quiet_start_hour"], pref["quiet_end_hour"]):
                continue
            # Recheck source inside the same character lock as source deletion.
            source = one(
                conn,
                """SELECT e.id FROM experience_events e JOIN goals g
                ON g.id::text=e.payload->>'goal_id' AND g.owner_id=e.owner_id
                AND g.character_id=e.character_id WHERE e.id=:e AND e.owner_id=:o
                AND e.event_type='local_activity_completed' AND g.status='completed'
                AND NOT EXISTS(SELECT 1 FROM notifications n WHERE n.owner_id=:o
                  AND n.source_event_id=e.id)""",
                {"e": candidate["id"], "o": owner},
            )
            if not source:
                continue
            day = now.astimezone(ZoneInfo(pref["timezone"])).date()
            usage = one(
                conn,
                """SELECT count(*) FILTER(WHERE local_date=:day) AS today,
                max(created_at) AS latest FROM notifications WHERE owner_id=:o""",
                {"day": day, "o": owner},
            )
            assert usage
            if usage["today"] >= pref["daily_limit"]:
                continue
            if (
                usage["latest"]
                and (now - usage["latest"]).total_seconds() < pref["min_interval_minutes"] * 60
            ):
                continue
            execute(
                conn,
                """INSERT INTO notifications(id,owner_id,character_id,source_event_id,body,
                created_at,local_date) VALUES (:id,:o,:c,:e,:body,:now,:day)""",
                {
                    "id": uuid4(),
                    "o": owner,
                    "c": character,
                    "e": source["id"],
                    "now": now,
                    "day": day,
                    "body": "我刚完成了一次站内材料整理，摘录已经按原文核验。"
                    "你方便时可以在目标与活动中查看；没有进行网络研究或外部操作。",
                },
            )
            delivered += 1
    return delivered
