import json
from uuid import UUID

from fastapi import APIRouter, Request
from pydantic import BaseModel, Field, field_validator
from sqlalchemy import Engine

from app.config import Settings
from app.errors import BusinessError
from app.life_service import check_version, owned
from app.memory import assert_character
from app.repository import Row, one
from app.safe_web import domain_name
from app.security import authenticate
from app.web_service import delete_document, document_list, expire_running, import_document, policy


class WebPolicyBody(BaseModel):
    enabled: bool
    allowed_domains: list[str] = Field(max_length=10)

    @field_validator("allowed_domains")
    @classmethod
    def domains(cls, values: list[str]) -> list[str]:
        return sorted(set(domain_name(value) for value in values))


class WebDocumentBody(BaseModel):
    url: str = Field(min_length=1, max_length=2000)
    client_request_id: UUID


def web_router(engine: Engine, settings: Settings) -> APIRouter:
    routes = APIRouter()

    def user(request: Request, write: bool = False) -> Row:
        return authenticate(request, engine, settings, write)

    @routes.get("/characters/{character_id}/web-policy")
    def get_policy(character_id: UUID, request: Request) -> Row:
        current = user(request)
        with engine.begin() as conn:
            return policy(conn, current["id"], character_id)

    @routes.patch("/characters/{character_id}/web-policy")
    def update_policy(character_id: UUID, body: WebPolicyBody, request: Request) -> Row:
        current = user(request, True)
        with engine.begin() as conn:
            assert_character(conn, current["id"], character_id, lock=True)
            before = policy(conn, current["id"], character_id, lock=True)
            check_version(before, request.headers.get("if-match"))
            result = one(
                conn,
                """UPDATE web_policies SET enabled=:enabled,
                allowed_domains=CAST(:domains AS jsonb),version=version+1,updated_at=now()
                WHERE character_id=:c RETURNING *""",
                {
                    "enabled": body.enabled,
                    "domains": json.dumps(body.allowed_domains),
                    "c": character_id,
                },
            )
            assert result
            return result

    @routes.post("/characters/{character_id}/web-documents", status_code=201)
    def create_document(character_id: UUID, body: WebDocumentBody, request: Request) -> Row:
        current = user(request, True)
        if request.headers.get("idempotency-key") != str(body.client_request_id):
            raise BusinessError("IDEMPOTENCY_REQUIRED", "请求标识不匹配", 400)
        return import_document(
            engine, current["id"], character_id, body.url, body.client_request_id
        )

    @routes.get("/characters/{character_id}/web-documents")
    def documents(character_id: UUID, request: Request) -> Row:
        current = user(request)
        with engine.begin() as conn:
            return {"items": document_list(conn, current["id"], character_id), "next_cursor": None}

    @routes.get("/web-documents/{document_id}")
    def document(document_id: UUID, request: Request) -> Row:
        current = user(request)
        with engine.begin() as conn:
            expire_running(conn, current["id"])
            return owned(conn, "web_documents", current["id"], document_id)

    @routes.delete("/web-documents/{document_id}")
    def forget(document_id: UUID, request: Request) -> Row:
        return delete_document(engine, user(request, True)["id"], document_id)

    return routes
