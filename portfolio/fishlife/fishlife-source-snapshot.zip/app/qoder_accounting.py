"""Persist validated Qoder reports without converting them into verified charges."""

from decimal import Decimal
from uuid import UUID

from sqlalchemy import Connection

from app.model_client import ModelFailure, ModelResult
from app.repository import Row, execute, one


def record_report(conn: Connection, reservation: Row, usage: Row, result: ModelResult) -> None:
    report = result.qoder_usage
    if report is None or report.model != usage["model"]:
        raise ModelFailure("QODER_REPORT_REQUIRED", uncertain=True)
    try:
        request_id, session_id = UUID(str(result.request_id)), UUID(report.session_id)
        for amount in (report.reported_cost_usd, report.reported_credits):
            if amount is not None and (
                not isinstance(amount, Decimal)
                or not amount.is_finite()
                or not 0 <= amount <= 1_000_000
            ):
                raise ValueError("Invalid reported amount")
        if report.reported_cost_usd is None:
            raise ValueError("Missing reported amount")
        if any(
            type(n) is not int or not 0 <= n <= 10_000_000
            for n in (
                result.input_tokens,
                result.output_tokens,
                report.cache_read_tokens,
                report.cache_creation_tokens,
            )
        ):
            raise ValueError("Invalid usage")
    except (ValueError, TypeError, ArithmeticError):
        raise ModelFailure("QODER_REPORT_INVALID", uncertain=True) from None
    dispatch = one(
        conn,
        """SELECT * FROM provider_dispatches WHERE owner_id=:o AND run_id=:run
        AND reservation_id=:r AND model=:model FOR UPDATE""",
        {
            "o": reservation["owner_id"],
            "run": reservation["run_id"],
            "r": reservation["id"],
            "model": report.model,
        },
    )
    if not dispatch:
        raise ModelFailure("QODER_DISPATCH_REQUIRED", uncertain=True)
    p = {
        "reservation_id": reservation["id"],
        "dispatch_id": dispatch["id"],
        "owner_id": reservation["owner_id"],
        "provider_model": report.model,
        "request_id": request_id,
        "session_id": session_id,
        "reported_cost_usd": report.reported_cost_usd,
        "reported_credits": report.reported_credits,
        "input_tokens": result.input_tokens,
        "output_tokens": result.output_tokens,
        "cache_read_tokens": report.cache_read_tokens,
        "cache_creation_tokens": report.cache_creation_tokens,
    }
    execute(
        conn,
        """INSERT INTO qoder_usage_reports(reservation_id,dispatch_id,owner_id,
        provider_model,request_id,session_id,reported_cost_usd,reported_credits,input_tokens,
        output_tokens,cache_read_tokens,cache_creation_tokens)
        VALUES (:reservation_id,:dispatch_id,:owner_id,:provider_model,:request_id,:session_id,
        :reported_cost_usd,:reported_credits,:input_tokens,:output_tokens,:cache_read_tokens,
        :cache_creation_tokens) ON CONFLICT DO NOTHING""",
        p,
    )
    stored = one(conn, "SELECT * FROM qoder_usage_reports WHERE reservation_id=:reservation_id", p)
    if not stored or any(stored[key] != value for key, value in p.items()):
        raise ModelFailure("QODER_REPORT_CONFLICT", uncertain=True)
    # A response is known, but its billing remains unverified. Preserve the
    # owner's dispatch block; this is not account reconciliation or permission.
    execute(
        conn,
        """UPDATE provider_dispatches SET status='unknown',finished_at=clock_timestamp()
        WHERE id=:dispatch_id AND status='started'""",
        p,
    )
