"""Bounded, lossless preparation of user-selected local text; no file access."""

from hashlib import sha256
from typing import TypedDict
from unicodedata import category

MAX_TEXT_CHARS = 200_000
MAX_TEXT_BYTES = 1024 * 1024
MAX_SEGMENT_CHARS = 2500
MAX_SEGMENTS = 100


class TextTooLargeError(ValueError):
    """The selected text exceeds an explicit import limit."""


class ReadingSegment(TypedDict):
    ordinal: int
    start_offset: int
    end_offset: int
    content: str
    source_hash: str


class PreparedText(TypedDict):
    title: str
    text: str
    source_hash: str
    total_chars: int
    segments: list[ReadingSegment]


def _valid_characters(value: str, *, multiline: bool) -> None:
    allowed = "\n\t" if multiline else ""
    if any(
        category(char) == "Cs" or (category(char) == "Cc" and char not in allowed) for char in value
    ):
        raise ValueError("Text contains a forbidden control character or surrogate")


def _nonblank_pair(value: str) -> list[str] | None:
    """Rebalance adjacent chunks without discarding their whitespace."""
    if len(value) <= MAX_SEGMENT_CHARS:
        return [value] if value.strip() else None
    first = next((i for i, char in enumerate(value) if not char.isspace()), len(value))
    last = next((i for i in range(len(value) - 1, -1, -1) if not value[i].isspace()), -1)
    minimum = max(len(value) - MAX_SEGMENT_CHARS, first + 1)
    maximum = min(MAX_SEGMENT_CHARS, last)
    if minimum > maximum:
        return None
    return [value[:maximum], value[maximum:]]


def _chunks(text: str) -> list[str]:
    chunks: list[str] = []
    offset = 0
    while offset < len(text):
        end = min(offset + MAX_SEGMENT_CHARS, len(text))
        if end < len(text):
            # Prefer a paragraph/line boundary without creating tiny fragments.
            newline = text.rfind("\n", offset + MAX_SEGMENT_CHARS // 2, end)
            if newline != -1 and text[offset : newline + 1].strip():
                end = newline + 1
        chunks.append(text[offset:end])
        offset = end
    index = 0
    while index < len(chunks):
        if chunks[index].strip():
            index += 1
            continue
        for left in (index - 1, index):
            if left < 0 or left + 1 >= len(chunks):
                continue
            replacement = _nonblank_pair(chunks[left] + chunks[left + 1])
            if replacement is not None:
                chunks[left : left + 2] = replacement
                index = max(0, left)
                break
        else:
            raise ValueError("Whitespace cannot fit into bounded nonblank segments")
    if len(chunks) > MAX_SEGMENTS:
        raise TextTooLargeError("Text exceeds 100 segments")
    return chunks


def prepare_text(title: str, content: str) -> PreparedText:
    """Strip title edges, remove one initial BOM, normalize CRLF, and hash UTF-8.

    Body whitespace is preserved, including final newlines. Lone CR and all C0/C1
    controls except body tab/newline are rejected, as are isolated surrogates.
    Offsets count Python Unicode characters in the normalized body.
    """
    _valid_characters(title, multiline=False)
    title = title.strip()
    if not 1 <= len(title) <= 120:
        raise ValueError("Title must contain between 1 and 120 characters")
    text = content.removeprefix("\ufeff").replace("\r\n", "\n")
    _valid_characters(text, multiline=True)
    if len(text) > MAX_TEXT_CHARS or len(text.encode("utf-8")) > MAX_TEXT_BYTES:
        raise TextTooLargeError("Text exceeds 200000 characters or 1 MiB UTF-8")
    if not text.strip():
        raise ValueError("Text must contain non-whitespace content")
    segments: list[ReadingSegment] = []
    offset = 0
    for ordinal, chunk in enumerate(_chunks(text)):
        end = offset + len(chunk)
        segments.append(
            {
                "ordinal": ordinal,
                "start_offset": offset,
                "end_offset": end,
                "content": chunk,
                "source_hash": sha256(chunk.encode()).hexdigest(),
            }
        )
        offset = end
    return {
        "title": title,
        "text": text,
        "source_hash": sha256(text.encode()).hexdigest(),
        "total_chars": len(text),
        "segments": segments,
    }
