import argparse
import getpass
import os
import re
from uuid import uuid4

from langgraph.checkpoint.postgres import PostgresSaver
from psycopg import Connection
from psycopg.rows import dict_row
from sqlalchemy.engine import make_url

from app.config import Settings
from app.repository import business_engine, execute
from app.security import hash_password


def psycopg_dsn(value: str) -> str:
    return make_url(value).set(drivername="postgresql").render_as_string(hide_password=False)


def init_checkpoints(settings: Settings) -> None:
    # Schema is owned by migrator. Runtime only receives DML permissions afterwards.
    dsn = psycopg_dsn(settings.migration_database_url.get_secret_value())
    with Connection.connect(
        dsn,
        autocommit=True,
        row_factory=dict_row,
        options="-c search_path=agent_runtime,public",
    ) as connection:
        PostgresSaver(connection).setup()
        connection.execute("GRANT USAGE ON SCHEMA agent_runtime TO fishlife_runtime")
        connection.execute(
            "GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES "
            "IN SCHEMA agent_runtime TO fishlife_runtime"
        )
        connection.execute(
            "GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA agent_runtime TO fishlife_runtime"
        )


def main() -> None:
    parser = argparse.ArgumentParser(description="FishLife administration")
    parser.add_argument("command", choices=["init-checkpoints", "create-user"])
    parser.add_argument("--username", default="owner")
    parser.add_argument("--password-env", help="Read password from this environment variable")
    args = parser.parse_args()
    settings = Settings()
    if args.command == "init-checkpoints":
        init_checkpoints(settings)
        print("Checkpoint schema initialized")
        return
    if not re.fullmatch(r"[a-zA-Z0-9_-]{3,80}", args.username):
        parser.error("Username must contain 3-80 letters, numbers, underscore or hyphen")
    password = (
        os.environ.get(args.password_env, "")
        if args.password_env
        else getpass.getpass("Password: ")
    )
    if not args.password_env and password != getpass.getpass("Confirm password: "):
        parser.error("Passwords do not match")
    try:
        encoded = hash_password(password)
    except ValueError as exc:
        parser.error(str(exc))
    engine = business_engine(settings)
    try:
        with engine.begin() as conn:
            execute(
                conn,
                """INSERT INTO users(id,username,password_hash,daily_budget_usd,monthly_budget_usd)
                VALUES (:id,:name,:hash,:day,:month)""",
                {
                    "id": uuid4(),
                    "name": args.username,
                    "hash": encoded,
                    "day": settings.daily_budget_usd,
                    "month": settings.monthly_budget_usd,
                },
            )
        print("Local user created; password was not printed")
    finally:
        engine.dispose()


if __name__ == "__main__":
    main()
