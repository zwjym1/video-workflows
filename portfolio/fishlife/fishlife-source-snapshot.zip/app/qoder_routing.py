"""Free-only model selection; caller must verify account quota before each request.

No CLI execution or billing authorization is implemented here. Unknown DS quota
must never be treated as remaining free calls. Qwen verification is a per-request
input, not an enduring claim that a temporary promotion is free forever.
"""

from datetime import UTC, datetime
from typing import Literal

DS_PROMOTION_START = datetime(2026, 10, 19, 16, tzinfo=UTC)
DS_PROMOTION_END = datetime(2026, 10, 31, 16, tzinfo=UTC)


def cli_model_name(model: str | None) -> str:
    """Names observed in the authenticated official CLI list; never select auto."""
    names = {"dfmodel": "DeepSeek-Flash", "qfmodel": "Qwen3.8-Flash"}
    if model not in names:
        raise ValueError("No authorized model selection")
    return names[model]


def choose_model(
    now: datetime, *, ds_free_available: bool | None, qwen_free_verified: bool
) -> Literal["dfmodel", "qfmodel"] | None:
    if now.tzinfo is None or now.utcoffset() is None:
        raise ValueError("Timezone-aware time required")
    if DS_PROMOTION_START <= now < DS_PROMOTION_END and ds_free_available is True:
        return "dfmodel"
    if qwen_free_verified is True:
        return "qfmodel"
    return None
