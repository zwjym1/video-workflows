import json
from typing import Any
from uuid import UUID, uuid4

from sqlalchemy import Connection, Engine

from app.errors import BusinessError
from app.memory import assert_character
from app.repository import Row, execute, one, rows


def owned(conn: Connection, table: str, owner: UUID, item: UUID, lock: bool = False) -> Row:
    if table not in {
        "characters",
        "conversations",
        "messages",
        "memory_items",
        "tasks",
        "deletion_requests",
        "goals",
        "scheduled_jobs",
        "journal_entries",
        "artifacts",
        "tool_previews",
        "notifications",
        "web_documents",
    }:
        raise ValueError("Unknown resource")
    value = one(
        conn,
        f"SELECT * FROM {table} WHERE id=:id AND owner_id=:o" + (" FOR UPDATE" if lock else ""),
        {"id": item, "o": owner},
    )
    if not value:
        raise BusinessError("NOT_FOUND", "内容不存在", 404)
    return value


def check_version(current: Row, expected: str | None) -> None:
    if expected is None:
        raise BusinessError("VERSION_REQUIRED", "请带上当前版本后再修改", 428)
    if expected.strip('"') != str(current["version"]):
        raise BusinessError("VERSION_CONFLICT", "内容已变化，请刷新后重试", 409)


def create_character(
    engine: Engine, owner: UUID, name: str, persona: dict[str, Any], interests: list[str]
) -> Row:
    with engine.begin() as conn:
        # Owner lock also serializes creation with the owner-wide stop operation.
        user = one(conn, "SELECT id,tools_paused FROM users WHERE id=:o FOR UPDATE", {"o": owner})
        assert user
        count = one(
            conn, "SELECT count(*) AS n FROM characters WHERE owner_id=:o AND enabled", {"o": owner}
        )
        if count and count["n"] >= 5:
            raise BusinessError("CHARACTER_LIMIT", "每个用户最多启用5个角色", 409)
        character = one(
            conn,
            """INSERT INTO characters(id,owner_id,name,core_persona,interests)
            VALUES (:id,:o,:n,CAST(:p AS jsonb),CAST(:i AS jsonb)) RETURNING *""",
            {
                "id": uuid4(),
                "o": owner,
                "n": name,
                "p": json.dumps(persona, ensure_ascii=False),
                "i": json.dumps(interests, ensure_ascii=False),
            },
        )
        assert character
        execute(
            conn,
            "INSERT INTO character_states(character_id,owner_id,tools_enabled) "
            "VALUES (:c,:o,:tools)",
            {"c": character["id"], "o": owner, "tools": not user["tools_paused"]},
        )
        return character


def update_character(
    engine: Engine, owner: UUID, character: UUID, changes: Row, expected: str | None
) -> Row:
    with engine.begin() as conn:
        assert_character(conn, owner, character, lock=True)
        current = owned(conn, "characters", owner, character, lock=True)
        check_version(current, expected)
        name = changes.get("name", current["name"])
        persona = changes.get("core_persona", current["core_persona"])
        interests = changes.get("interests", current["interests"])
        result = one(
            conn,
            """UPDATE characters SET name=:n,core_persona=CAST(:p AS jsonb),
            interests=CAST(:i AS jsonb),version=version+1,persona_version=persona_version+1,
            updated_at=now() WHERE id=:c RETURNING *""",
            {
                "n": name,
                "p": json.dumps(persona, ensure_ascii=False),
                "i": json.dumps(interests, ensure_ascii=False),
                "c": character,
            },
        )
        assert result
        return result


def create_conversation(engine: Engine, owner: UUID, character: UUID, title: str) -> Row:
    with engine.begin() as conn:
        assert_character(conn, owner, character, lock=True)
        result = one(
            conn,
            """INSERT INTO conversations(id,owner_id,character_id,title)
            VALUES (:id,:o,:c,:title) RETURNING *""",
            {"id": uuid4(), "o": owner, "c": character, "title": title},
        )
        assert result
        return result


def enqueue_message(
    engine: Engine,
    owner: UUID,
    conversation: UUID,
    content: str,
    request_id: UUID,
    content_kind: str,
) -> Row:
    with engine.begin() as conn:
        conv = owned(conn, "conversations", owner, conversation)
        state = assert_character(conn, owner, conv["character_id"], lock=True)
        if state["mode"] == "deleting":
            raise BusinessError("DELETING", "正在删除相关内容，请稍后重试", 409)
        one(conn, "SELECT id FROM conversations WHERE id=:id FOR UPDATE", {"id": conversation})
        if one(
            conn,
            """SELECT id FROM tasks WHERE owner_id=:o AND character_id=:c
            AND input->>'conversation_id'=:conv AND input ? 'reading_qa' LIMIT 1""",
            {"o": owner, "c": conv["character_id"], "conv": str(conversation)},
        ):
            raise BusinessError(
                "READING_CONVERSATION", "请在书架中逐次授权并提问，阅读会话不能追加普通聊天", 409
            )
        existing = one(
            conn,
            "SELECT * FROM messages WHERE owner_id=:o AND client_request_id=:r",
            {"o": owner, "r": request_id},
        )
        if existing:
            if (
                existing["content"] != content
                or existing["conversation_id"] != conversation
                or existing["content_kind"] != content_kind
            ):
                raise BusinessError("IDEMPOTENCY_CONFLICT", "重复请求标识对应了不同内容", 409)
            task = one(
                conn,
                "SELECT id FROM tasks WHERE owner_id=:o AND idempotency_key=:key",
                {"o": owner, "key": str(request_id)},
            )
            assert task
            return {
                "user_message_id": existing["id"],
                "reply_job_id": task["id"],
                "status_url": "/api/v1/jobs/" + str(task["id"]),
            }
        seq = one(
            conn,
            "SELECT COALESCE(MAX(seq),0)+1 AS n FROM messages WHERE conversation_id=:id",
            {"id": conversation},
        )
        assert seq
        message_id, task_id = uuid4(), uuid4()
        execute(
            conn,
            """INSERT INTO messages(id,owner_id,character_id,conversation_id,role,content,
            content_kind,status,seq,client_request_id) VALUES (:id,:o,:c,:conv,'user',:text,
            :kind,'completed',:seq,:r)""",
            {
                "id": message_id,
                "o": owner,
                "c": conv["character_id"],
                "conv": conversation,
                "text": content,
                "kind": content_kind,
                "seq": seq["n"],
                "r": request_id,
            },
        )
        execute(
            conn,
            """INSERT INTO tasks(id,owner_id,character_id,kind,input,status,idempotency_key)
            VALUES (:id,:o,:c,'chat_reply',CAST(:input AS jsonb),'queued',:key)""",
            {
                "id": task_id,
                "o": owner,
                "c": conv["character_id"],
                "key": str(request_id),
                "input": json.dumps(
                    {"message_id": str(message_id), "conversation_id": str(conversation)}
                ),
            },
        )
        execute(
            conn,
            """INSERT INTO experience_events(id,owner_id,character_id,event_type,
            reality_class,source_message_id,dedupe_key) VALUES (:id,:o,:c,'message_received',
            :reality,:msg,:key)""",
            {
                "id": uuid4(),
                "o": owner,
                "c": conv["character_id"],
                "reality": "roleplay" if content_kind == "roleplay" else "user_claim",
                "msg": message_id,
                "key": "message:" + str(message_id),
            },
        )
        return {
            "user_message_id": message_id,
            "reply_job_id": task_id,
            "status_url": "/api/v1/jobs/" + str(task_id),
        }


def list_messages(
    engine: Engine, owner: UUID, conversation: UUID, before_seq: int | None = None
) -> list[Row]:
    with engine.connect() as conn:
        owned(conn, "conversations", owner, conversation)
        if one(
            conn,
            """SELECT id FROM tasks WHERE owner_id=:o
            AND input->>'conversation_id'=:conv AND input ? 'reading_qa' LIMIT 1""",
            {"o": owner, "conv": str(conversation)},
        ):
            raise BusinessError("READING_CONVERSATION", "请从书架查看这次阅读问答", 409)
        return rows(
            conn,
            """SELECT page.* FROM (SELECT m.*,t.id AS reply_job_id FROM messages m LEFT JOIN tasks t
            ON t.owner_id=m.owner_id AND t.idempotency_key=m.client_request_id::text
            WHERE m.owner_id=:o AND m.conversation_id=:c
            AND m.seq<COALESCE(:before,9223372036854775807)
            ORDER BY m.seq DESC LIMIT 200) page ORDER BY page.seq""",
            {"o": owner, "c": conversation, "before": before_seq},
        )


def retry_message(engine: Engine, owner: UUID, message_id: UUID) -> Row:
    with engine.begin() as conn:
        message = owned(conn, "messages", owner, message_id)
        assert_character(conn, owner, message["character_id"], lock=True)
        if message["role"] != "user" or message["status"] != "completed":
            raise BusinessError("NOT_RETRYABLE", "该消息不能重试", 409)
        task = one(
            conn,
            "SELECT * FROM tasks WHERE owner_id=:o AND idempotency_key=:key FOR UPDATE",
            {"o": owner, "key": str(message["client_request_id"])},
        )
        if not task:
            raise BusinessError("NOT_FOUND", "回复任务不存在", 404)
        if "reading_qa" in task["input"]:
            raise BusinessError("NOT_RETRYABLE", "请在书架重新确认原文后发起新问题", 409)
        if task["status"] != "failed" or task["attempt_count"] >= task["max_attempts"]:
            raise BusinessError("NOT_RETRYABLE", "任务未失败、结果未知或已达重试上限", 409)
        execute(
            conn,
            """UPDATE tasks SET status='queued',not_before=now(),error_code=NULL
            WHERE id=:id""",
            {"id": task["id"]},
        )
        return {"reply_job_id": task["id"], "status_url": "/api/v1/jobs/" + str(task["id"])}
