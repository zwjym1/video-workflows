"""Optional cloud speech transport; no route, automatic call, storage or fake audio URL."""

import hashlib
import io
import time
import wave
from dataclasses import dataclass
from typing import Literal

import httpx
from pydantic import BaseModel, ConfigDict, Field, SecretStr

MAX_AUDIO_BYTES = 2_000_000


class FishAudioConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")
    allow_cloud: bool = False
    api_key: SecretStr = SecretStr("")
    reference_id: str = Field(default="", max_length=200, pattern=r"^[a-zA-Z0-9_-]*$")
    model: Literal["s1", "s2-pro", "s2.1-pro", "s2.1-pro-free", "drama-3"]


class SpeechProviderFailure(Exception):
    def __init__(self, code: str, *, uncertain: bool = False) -> None:
        super().__init__(code)
        self.code, self.uncertain = code, uncertain


@dataclass(frozen=True)
class VerifiedSpeechAudio:
    data: bytes
    duration_seconds: float
    sample_rate: int
    sha256: str
    provider: str = "fish_audio"
    content_type: str = "audio/wav"


def verify_wav(data: bytes) -> VerifiedSpeechAudio:
    try:
        with wave.open(io.BytesIO(data), "rb") as audio:
            rate, frames = audio.getframerate(), audio.getnframes()
            if (
                audio.getnchannels() != 1
                or audio.getsampwidth() != 2
                or rate not in (8000, 16000, 24000, 32000, 44100)
                or frames <= 0
                or frames / rate > 60
            ):
                raise ValueError("Unsupported wave properties")
            actual = audio.readframes(frames)
            if len(actual) != frames * 2:
                raise ValueError("Truncated wave data")
    except (wave.Error, EOFError, ValueError) as exc:
        raise SpeechProviderFailure("INVALID_AUDIO", uncertain=True) from exc
    return VerifiedSpeechAudio(data, frames / rate, rate, hashlib.sha256(data).hexdigest())


class FishAudioClient:
    def __init__(self, config: FishAudioConfig, client: httpx.Client | None = None) -> None:
        self.config, self.client = config, client

    def synthesize_audio(
        self, text: str, *, request_authorized: bool = False
    ) -> VerifiedSpeechAudio:
        config = self.config
        if (
            not config.allow_cloud
            or not request_authorized
            or not config.reference_id
            or not config.api_key.get_secret_value()
        ):
            raise SpeechProviderFailure("CLOUD_SPEECH_NOT_AUTHORIZED")
        if not isinstance(text, str) or not text.strip() or len(text) > 500:
            raise SpeechProviderFailure("INVALID_SPEECH_TEXT")
        own_client = self.client is None
        client = self.client or httpx.Client(timeout=30, follow_redirects=False)
        started = time.monotonic()
        try:
            with client.stream(
                "POST",
                "https://api.fish.audio/v1/tts",
                headers={
                    "Authorization": "Bearer " + config.api_key.get_secret_value(),
                    "model": config.model,
                },
                json={"text": text, "reference_id": config.reference_id, "format": "wav"},
                follow_redirects=False,
                timeout=30,
            ) as response:
                if response.status_code != 200:
                    raise SpeechProviderFailure("SPEECH_PROVIDER_REJECTED", uncertain=True)
                if response.headers.get("content-encoding", "identity").lower() != "identity":
                    raise SpeechProviderFailure("UNSUPPORTED_AUDIO_ENCODING", uncertain=True)
                data = bytearray()
                for chunk in response.iter_raw(chunk_size=16384):
                    if len(data) + len(chunk) > MAX_AUDIO_BYTES:
                        raise SpeechProviderFailure("AUDIO_TOO_LARGE", uncertain=True)
                    if time.monotonic() - started > 45:
                        raise SpeechProviderFailure("AUDIO_DEADLINE_EXCEEDED", uncertain=True)
                    data.extend(chunk)
                return verify_wav(bytes(data))
        except httpx.HTTPError as exc:
            raise SpeechProviderFailure("SPEECH_NETWORK_UNCERTAIN", uncertain=True) from exc
        finally:
            if own_client:
                client.close()
