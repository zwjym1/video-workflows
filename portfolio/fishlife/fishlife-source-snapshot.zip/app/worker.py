import json
import signal
import threading
from datetime import UTC, datetime
from types import FrameType

from sqlalchemy import Engine, text

from app.activity_plan_worker import process_plan_once
from app.budgets import reconcile_cancelled_reservations
from app.config import Settings
from app.living import process_activity_once, scheduler_tick
from app.memory_lifecycle import expire_memories_tick
from app.notifications import notification_tick
from app.queue import process_once
from app.reading_worker import process_reading_once, reading_tick
from app.release import APP_VERSION, STAGE
from app.repository import business_engine
from app.tool_service import reconcile_tool_files

HEARTBEAT_INTERVAL_SECONDS = 15
HEARTBEAT_JOIN_TIMEOUT_SECONDS = 15


def heartbeat_loop(engine: Engine, settings: Settings, stopped: threading.Event) -> None:
    """Keep liveness independent of model calls and ordinary worker scheduling."""
    while not stopped.is_set():
        status = "idle"
        error_type = None
        try:
            with engine.begin() as connection:
                # A pool checkout may have waited while shutdown was requested.
                if stopped.is_set():
                    return
                connection.execute(
                    text(
                        "INSERT INTO service_heartbeats(service_name, heartbeat_at) "
                        "VALUES ('worker', now()) ON CONFLICT(service_name) "
                        "DO UPDATE SET heartbeat_at=EXCLUDED.heartbeat_at"
                    )
                )
        except Exception as exc:
            status = "database_unavailable"
            error_type = type(exc).__name__
        print(
            json.dumps(
                {
                    "service": "worker",
                    "stage": STAGE,
                    "version": APP_VERSION,
                    "status": status,
                    "autonomy_enabled": settings.autonomy_enabled,
                    "time": datetime.now(UTC).isoformat(),
                    "error_type": error_type,
                }
            ),
            flush=True,
        )
        stopped.wait(HEARTBEAT_INTERVAL_SECONDS)


def main() -> None:
    settings = Settings()
    engine = business_engine(settings)
    stopped = threading.Event()

    def stop(_signum: int, _frame: FrameType | None) -> None:
        stopped.set()

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    heartbeat = threading.Thread(
        target=heartbeat_loop,
        args=(engine, settings, stopped),
        name="worker-heartbeat",
        daemon=True,
    )
    heartbeat.start()
    try:
        while not stopped.is_set():
            try:
                reconcile_cancelled_reservations(engine)
                expire_memories_tick(engine)
                reconcile_tool_files(engine, settings)
                scheduler_tick(engine, settings)
                reading_tick(engine, settings)
                notification_tick(engine, settings)
                if process_once(engine, settings):
                    continue
                if process_activity_once(engine, settings):
                    continue
                if process_reading_once(engine, settings):
                    continue
                if process_plan_once(engine, settings):
                    continue
            except Exception:
                print(
                    json.dumps({"service": "worker", "status": "processing_unavailable"}),
                    flush=True,
                )
            stopped.wait(max(1, settings.worker_interval_seconds))
    finally:
        stopped.set()
        heartbeat.join(HEARTBEAT_JOIN_TIMEOUT_SECONDS)
        if heartbeat.is_alive():
            # dispose does not cancel a checked-out connection or terminate its thread.
            print(
                json.dumps({"service": "worker", "status": "heartbeat_stop_timeout"}),
                flush=True,
            )
        engine.dispose()


if __name__ == "__main__":
    main()
