from decimal import Decimal
from pathlib import Path
from typing import Literal

from pydantic import Field, SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore", env_ignore_empty=True)

    app_env: Literal["development", "test", "production"] = "development"
    database_url: SecretStr = SecretStr(
        "postgresql+psycopg://fishlife_app:replace_me@localhost:5432/fishlife"
    )
    migration_database_url: SecretStr = SecretStr(
        "postgresql+psycopg://fishlife_migrator:replace_me@localhost:5432/fishlife"
    )
    checkpoint_database_url: SecretStr = SecretStr(
        "postgresql://fishlife_runtime:replace_me@localhost:5432/fishlife"
    )
    frontend_dist: Path = Path(__file__).resolve().parent.parent / "frontend" / "dist"
    model_provider: Literal["mock", "openai", "qoder", "codex"] = "mock"
    public_origin: str = "http://127.0.0.1:8000"
    model_api_key: SecretStr = SecretStr("")
    chat_model: str = ""
    allow_real_model_calls: bool = False
    codex_cli: str = ""
    codex_cwd: str = ""
    codex_model: str = ""
    codex_daily_limit: int = Field(default=20, ge=1, le=100)
    codex_uncertainty_hold_usd: Decimal = Field(
        default=Decimal("0.01"), gt=0, le=1, decimal_places=8, allow_inf_nan=False
    )
    qoder_node: str = ""
    qoder_platform: Literal["posix", "windows"] = "posix"
    qoder_cli: str = ""
    qoder_bridge: str = ""
    qoder_cwd: str = ""
    qoder_config_dir: str = ""
    # Server-derived authentication metadata fingerprint; never an API key.
    qoder_account_scope: str = ""
    # Explicit acknowledgement of external history; does not verify unknown bills.
    qoder_account_reviewed: bool = False
    # Zero usage receipts can permit continuation; unknown budget holds remain.
    qoder_continue_reported_free: bool = False
    # Unknown-cost reservation only: neither a price nor permission to incur charges.
    qoder_uncertainty_hold_usd: Decimal = Field(
        default=Decimal("0.01"), gt=0, le=1, decimal_places=8, allow_inf_nan=False
    )
    model_input_usd_per_million: Decimal | None = None
    model_output_usd_per_million: Decimal | None = None
    daily_budget_usd: Decimal = Field(default=Decimal("0.50"), ge=0)
    monthly_budget_usd: Decimal = Field(default=Decimal("10.00"), ge=0)
    session_days: int = Field(default=7, gt=0, le=30)
    autonomy_enabled: bool = True
    model_planning_enabled: bool = False
    reading_enabled: bool = False
    notifications_enabled: bool = True
    worker_interval_seconds: int = Field(default=10, gt=0, le=3600)
    artifact_root: Path = Path("data/artifacts")

