from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy.exc import SQLAlchemyError
from starlette.concurrency import run_in_threadpool

from app.api import router
from app.config import Settings
from app.db import build_engine, probe_database
from app.errors import BusinessError
from app.release import APP_VERSION, STAGE
from app.repository import business_engine


def create_app(settings: Settings | None = None) -> FastAPI:
    config = settings or Settings()
    engine = build_engine(config)
    business = business_engine(config)

    @asynccontextmanager
    async def lifespan(_: FastAPI) -> AsyncIterator[None]:
        yield
        engine.dispose()
        business.dispose()

    application = FastAPI(title="Project FishLife", version=APP_VERSION, lifespan=lifespan)

    @application.exception_handler(BusinessError)
    async def business_error(_: Request, error: BusinessError) -> JSONResponse:
        return JSONResponse(
            {"error": {"code": error.code, "message": error.message}}, status_code=error.status
        )

    @application.exception_handler(RequestValidationError)
    async def validation_error(_: Request, error: RequestValidationError) -> JSONResponse:
        return JSONResponse(
            {
                "error": {
                    "code": "VALIDATION_ERROR",
                    "message": "请求字段不符合要求",
                    "fields": [list(x["loc"]) for x in error.errors()],
                }
            },
            status_code=422,
        )

    @application.exception_handler(SQLAlchemyError)
    async def database_error(_: Request, __: SQLAlchemyError) -> JSONResponse:
        return JSONResponse(
            {"error": {"code": "DATABASE_UNAVAILABLE", "message": "数据库暂时不可用"}},
            status_code=503,
        )

    application.include_router(router(business, config))

    @application.get("/health/live")
    def live() -> dict[str, str]:
        return {"status": "alive", "stage": STAGE, "version": APP_VERSION}

    @application.get("/health/ready")
    async def ready() -> JSONResponse:
        try:
            result = await run_in_threadpool(probe_database, engine)
        except Exception:
            # Health output never includes DSNs, passwords or provider errors.
            return JSONResponse({"status": "not_ready", "database": "unavailable"}, status_code=503)
        return JSONResponse({"status": "ready", **result})

    assets = config.frontend_dist / "assets"
    if assets.is_dir():
        application.mount("/assets", StaticFiles(directory=assets), name="assets")

    @application.get("/{path:path}", include_in_schema=False)
    def frontend(path: str) -> FileResponse:
        if path.split("/", 1)[0] in {"api", "health", "assets"}:
            raise HTTPException(status_code=404)
        index = config.frontend_dist / "index.html"
        if not index.is_file():
            raise HTTPException(status_code=503, detail="Frontend not built; run npm run build")
        return FileResponse(index)

    return application


app = create_app()
