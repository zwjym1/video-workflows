"""Invalidate pending model choices and erase derived text without erasing billing."""

from uuid import UUID

from sqlalchemy import Connection

from app.repository import execute, one


def cancel_plans(conn: Connection, owner: UUID, character: UUID, goal: UUID | None = None) -> None:
    # The released Windows runtime still supports schema 0014 with planning off.
    installed = one(conn, "SELECT to_regclass('public.activity_plan_sources') AS name")
    if not installed or installed["name"] is None:
        return
    params = {"o": owner, "c": character, "g": goal}
    selection = """SELECT t.id FROM tasks t
        WHERE t.owner_id=:o AND t.character_id=:c AND t.kind='activity_plan'
        AND (CAST(:g AS uuid) IS NULL OR EXISTS
            (SELECT 1 FROM activity_plan_sources s WHERE s.task_id=t.id
            AND s.owner_id=:o AND s.character_id=:c AND s.goal_id=:g))"""
    execute(
        conn,
        """UPDATE task_runs SET status='cancelled',finished_at=now(),
        error_code='ACTIVITY_PAUSED' WHERE owner_id=:o AND character_id=:c
        AND status='running' AND task_id IN ("""
        + selection
        + ")",
        params,
    )
    execute(
        conn,
        """UPDATE tasks SET status='cancelled',cancel_requested=true,
        fencing_token=fencing_token+1,lease_until=NULL,error_code='ACTIVITY_PAUSED'
        WHERE id IN ("""
        + selection
        + ") AND status IN ('queued','retry_wait','running')",
        params,
    )
    if goal is not None:
        # Reasons may quote any candidate title, even when another goal was selected.
        # Preserve source hashes, dispatches, usage and unknown reservations as evidence.
        execute(
            conn,
            "UPDATE tasks SET result=NULL,input='{}' WHERE id IN (" + selection + ")",
            params,
        )
