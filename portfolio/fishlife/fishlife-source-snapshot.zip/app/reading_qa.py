"""User-requested single-segment Q&A using existing chat billing and fencing."""

import hashlib
import json
from dataclasses import asdict
from uuid import UUID, uuid4

from sqlalchemy import Connection, Engine

from app.config import Settings
from app.errors import BusinessError
from app.reading_answer import build_reading_prompt, parse_reading_answer
from app.repository import Row, execute, one, rows

CONSENT = "允许将所选原文和问题发送给Qoder"


def load_source(conn: Connection, task: Row) -> Row:
    """Caller owns the character lock for writes/dispatch; no content snapshots persist."""
    binding = task.get("input", {}).get("reading_qa")
    if not isinstance(binding, dict) or binding.get("consent") is not True:
        raise BusinessError("READING_QA_INVALID", "阅读问答来源或授权已失效", 409)
    try:
        book = UUID(binding["book_id"])
        ordinal = binding["ordinal"]
        if type(ordinal) is not int or not 0 <= ordinal < 100:
            raise ValueError
        value = one(
            conn,
            """SELECT s.*,b.status AS book_status FROM reading_segments s
            JOIN books b ON b.id=s.book_id AND b.owner_id=s.owner_id
            AND b.character_id=s.character_id
            WHERE s.owner_id=:o AND s.character_id=:c AND s.book_id=:b AND s.ordinal=:n""",
            {"o": task["owner_id"], "c": task["character_id"], "b": book, "n": ordinal},
        )
        if (
            not value
            or value["book_status"] == "deleted"
            or value["deleted"]
            or value["source_hash"] != binding["source_hash"]
            or not value["content"].strip()
            or len(value["content"]) > 2500
            or hashlib.sha256(value["content"].encode()).hexdigest() != value["source_hash"]
        ):
            raise ValueError
        return value
    except (KeyError, TypeError, ValueError):
        raise BusinessError("READING_QA_INVALID", "阅读问答来源或授权已失效", 409) from None


def context(conn: Connection, task: Row, message: Row) -> Row:
    source = load_source(conn, task)
    return {
        "message": message,
        "memories": [],
        "persona": {},
        "conflicts": False,
        "recent_messages": [],
        "recent_message_ids": [],
        "reading_qa": {
            "book_id": str(source["book_id"]),
            "ordinal": source["ordinal"],
            "source_hash": source["source_hash"],
            "content": source["content"],
        },
    }


def prompt(context: Row) -> str:
    source = context["reading_qa"]
    return build_reading_prompt(
        UUID(source["book_id"]),
        source["ordinal"],
        source["content"],
        source["source_hash"],
        context["message"]["content"],
    )


def validate_answer(conn: Connection, task: Row, raw: str) -> Row:
    source = load_source(conn, task)
    try:
        return asdict(
            parse_reading_answer(
                raw,
                source["book_id"],
                source["ordinal"],
                source["content"],
                source["source_hash"],
            )
        )
    except ValueError:
        raise BusinessError(
            "READING_ANSWER_INVALID", "回答未通过原文引用核验，请勿将其当作已验证答案", 409
        ) from None


def enqueue(
    engine: Engine,
    settings: Settings,
    owner: UUID,
    book: UUID,
    ordinal: int,
    source_hash: str,
    question: str,
    acknowledgement: str,
    request_key: UUID,
) -> Row:
    from app.reading_service import capability, lock_book

    capability(settings)
    if settings.model_provider != "qoder" or not settings.allow_real_model_calls:
        raise BusinessError("READING_QA_UNAVAILABLE", "阅读问答需要启用Qoder真实模型", 409)
    if acknowledgement != CONSENT:
        raise BusinessError("READING_QA_CONSENT", "请确认本次所选原文和问题的云端处理", 422)
    if not question.strip() or len(question) > 1500 or "\0" in question:
        raise BusinessError("READING_QUESTION_INVALID", "问题须为1至1500字有效文本", 422)
    try:
        question.encode("utf8")
    except UnicodeError:
        raise BusinessError("READING_QUESTION_INVALID", "问题包含无效字符", 422) from None
    binding = {
        "book_id": str(book),
        "ordinal": ordinal,
        "source_hash": source_hash,
        "consent": True,
    }
    with engine.begin() as conn:
        user, state, value = lock_book(conn, owner, book)
        if user["disabled"] or not state["enabled"] or state["mode"] == "deleting":
            raise BusinessError("CHARACTER_UNAVAILABLE", "角色当前不可用", 409)
        parameters = {"o": owner, "c": value["character_id"], "key": str(request_key)}
        existing = one(
            conn, "SELECT * FROM tasks WHERE owner_id=:o AND idempotency_key=:key", parameters
        )
        if existing:
            message = one(
                conn,
                "SELECT * FROM messages WHERE id=:m AND owner_id=:o",
                {
                    "m": UUID(existing["input"].get("message_id", str(UUID(int=0)))),
                    "o": owner,
                },
            )
            if (
                existing["input"].get("reading_qa") != binding
                or not message
                or message["content"] != question
            ):
                raise BusinessError("IDEMPOTENCY_CONFLICT", "同一请求标识不能发送不同问题", 409)
            return queued_view(existing, message)
        task_id, message_id, conversation_id = uuid4(), uuid4(), uuid4()
        task_input = {
            "message_id": str(message_id),
            "conversation_id": str(conversation_id),
            "reading_qa": binding,
        }
        load_source(
            conn, {"owner_id": owner, "character_id": value["character_id"], "input": task_input}
        )
        execute(
            conn,
            """INSERT INTO conversations(id,owner_id,character_id,title)
            VALUES (:id,:o,:c,'单段阅读问答')""",
            {**parameters, "id": conversation_id},
        )
        execute(
            conn,
            """INSERT INTO messages(id,owner_id,character_id,conversation_id,role,
            content,content_kind,status,seq,client_request_id)
            VALUES (:id,:o,:c,:conv,'user',:text,'inference','completed',1,:r)""",
            {
                **parameters,
                "id": message_id,
                "conv": conversation_id,
                "text": question,
                "r": request_key,
            },
        )
        task = one(
            conn,
            """INSERT INTO tasks(id,owner_id,character_id,kind,input,status,
            idempotency_key,max_attempts) VALUES (:id,:o,:c,'chat_reply',CAST(:input AS jsonb),
            'queued',:key,1) RETURNING *""",
            {**parameters, "id": task_id, "input": json.dumps(task_input)},
        )
        assert task
        return queued_view(task, {"id": message_id, "conversation_id": conversation_id})


def queued_view(task: Row, message: Row) -> Row:
    return {
        "user_message_id": message["id"],
        "reply_job_id": task["id"],
        "conversation_id": message["conversation_id"],
        "status_url": "/api/v1/jobs/" + str(task["id"]),
    }


def list_questions(
    engine: Engine, settings: Settings, owner: UUID, book: UUID, ordinal: int
) -> Row:
    """Recover up to twenty requests without resending any question to the provider."""
    from app.reading_service import capability, owned_book, read_snapshot

    capability(settings)
    if type(ordinal) is not int or not 0 <= ordinal < 100:
        raise BusinessError("READING_SEGMENT_INVALID", "段落编号无效", 422)
    with read_snapshot(engine) as conn:
        value = owned_book(conn, owner, book)
        p = {"o": owner, "c": value["character_id"], "b": str(book), "n": str(ordinal)}
        source = one(
            conn,
            """SELECT source_hash FROM reading_segments WHERE owner_id=:o
            AND character_id=:c AND book_id=CAST(:b AS uuid) AND ordinal=CAST(:n AS int)""",
            p,
        )
        if not source:
            raise BusinessError("NOT_FOUND", "段落不存在", 404)
        load_source(
            conn,
            {
                "owner_id": owner,
                "character_id": value["character_id"],
                "input": {
                    "reading_qa": {
                        "book_id": str(book),
                        "ordinal": ordinal,
                        "source_hash": source["source_hash"],
                        "consent": True,
                    },
                },
            },
        )
        tasks = rows(
            conn,
            """SELECT t.id,t.status,t.error_code,t.input,t.created_at,m.content AS question
            FROM tasks t JOIN messages m ON m.id::text=t.input->>'message_id'
            AND m.owner_id=t.owner_id AND m.character_id=t.character_id
            AND m.role='user' AND m.status='completed'
            WHERE t.owner_id=:o AND t.character_id=:c AND t.kind='chat_reply'
            AND t.input->'reading_qa'->>'book_id'=:b
            AND t.input->'reading_qa'->>'ordinal'=:n
            ORDER BY t.created_at DESC,t.id DESC LIMIT 20""",
            p,
        )
        items = []
        for task in tasks:
            load_source(conn, {**task, "owner_id": owner, "character_id": value["character_id"]})
            items.append(
                {
                    "task_id": task["id"],
                    "status": task["status"],
                    "error_code": task["error_code"],
                    "question": task["question"][:1500],
                    "source_hash": source["source_hash"],
                    "created_at": task["created_at"],
                }
            )
        return {"items": items}


def get_answer(engine: Engine, settings: Settings, owner: UUID, book: UUID, task_id: UUID) -> Row:
    from app.reading_service import capability, owned_book, read_snapshot

    capability(settings)
    with read_snapshot(engine) as conn:
        value = owned_book(conn, owner, book)
        task = one(
            conn,
            "SELECT * FROM tasks WHERE id=:t AND owner_id=:o AND character_id=:c",
            {"t": task_id, "o": owner, "c": value["character_id"]},
        )
        if not task or task["input"].get("reading_qa", {}).get("book_id") != str(book):
            raise BusinessError("NOT_FOUND", "阅读问答不存在", 404)
        answer = None
        if task["status"] == "succeeded":
            message = one(
                conn,
                "SELECT content FROM messages WHERE id=:m AND owner_id=:o AND status='completed'",
                {"m": task["result_message_id"], "o": owner},
            )
            if message:
                answer = validate_answer(conn, task, message["content"])
        return {
            "task_id": task_id,
            "status": task["status"],
            "error_code": task["error_code"],
            "answer": answer,
        }


def erase(conn: Connection, owner: UUID, character: UUID, book: UUID) -> None:
    """Called under owner -> character -> book locks, retaining usage and receipts."""
    tasks = rows(
        conn,
        """SELECT id,input FROM tasks WHERE owner_id=:o AND character_id=:c
        AND input->'reading_qa'->>'book_id'=:b FOR UPDATE""",
        {"o": owner, "c": character, "b": str(book)},
    )
    for task in tasks:
        p = {
            "o": owner,
            "c": character,
            "t": task["id"],
            "conv": UUID(task["input"]["conversation_id"]),
        }
        execute(
            conn,
            """UPDATE task_runs SET status='cancelled',finished_at=now(),error_code='BOOK_DELETED'
            WHERE task_id=:t AND status='running'""",
            p,
        )
        execute(
            conn,
            """UPDATE tasks SET status=CASE WHEN status IN ('queued','retry_wait','running')
            THEN 'cancelled' ELSE status END,cancel_requested=true,fencing_token=fencing_token+1,
            input='{}',result=NULL,lease_until=NULL,lease_owner=NULL WHERE id=:t""",
            p,
        )
        execute(
            conn,
            """UPDATE messages SET content='',status='deleted' WHERE owner_id=:o
            AND character_id=:c AND conversation_id=:conv""",
            p,
        )
        execute(
            conn,
            "UPDATE conversations SET title='已删除阅读问答' WHERE id=:conv AND owner_id=:o",
            p,
        )
        execute(
            conn,
            """UPDATE experience_events SET payload='{}' WHERE owner_id=:o AND character_id=:c
            AND task_run_id IN (SELECT id FROM task_runs WHERE task_id=:t)""",
            p,
        )
