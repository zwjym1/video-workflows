"""M2: bounded, deterministic local material work. No model or external tools."""

import hashlib
import json
from datetime import UTC, datetime, timedelta
from uuid import UUID, uuid4
from zoneinfo import ZoneInfo

from sqlalchemy import Connection, Engine

from app.activity_plan_lifecycle import cancel_plans
from app.activity_plan_queue import maybe_enqueue_plan
from app.config import Settings
from app.errors import BusinessError
from app.interest_ranking import rank_candidates
from app.life_service import owned
from app.memory import assert_character
from app.queue import claim_task, recover_expired
from app.reading_lifecycle import cancel_reading
from app.repository import Row, execute, one, rows


def organize_material(material: str) -> Row:
    lines = list(dict.fromkeys(x.strip() for x in material.splitlines() if x.strip()))[:8]
    result = {
        "kind": "local_material_outline",
        "excerpt_lines": lines,
        "checklist": ["复核摘录是否符合原意", "由用户确认下一步；本活动不执行外部行动"],
        "source_hash": hashlib.sha256(material.encode()).hexdigest(),
        "verification": {"all_excerpts_in_source": all(x in material for x in lines)},
        "method": "确定性逐行摘录和模板清单；未进行网络研究或模型推理",
    }
    return result


def coalesce_next(due: datetime, interval: int, now: datetime) -> datetime:
    return due + timedelta(
        seconds=(max(0, int((now - due).total_seconds())) // interval + 1) * interval
    )


def autonomy(conn: Connection, owner: UUID, character: UUID, settings: Settings) -> Row:
    assert_character(conn, owner, character)
    current = one(conn, "SELECT autonomy_paused,disabled FROM users WHERE id=:o", {"o": owner})
    assert current
    return {
        "enabled": settings.autonomy_enabled
        and not current["autonomy_paused"]
        and not current["disabled"],
        "capability_enabled": settings.autonomy_enabled,
        "paused": current["autonomy_paused"],
        # Capability only. User opt-in and quiet-hour policy are in notification-preferences.
        "notifications_enabled": settings.notifications_enabled,
        "execution_mode": "local_deterministic",
    }


def set_autonomy(
    engine: Engine, owner: UUID, character: UUID, enabled: bool, settings: Settings
) -> Row:
    with engine.begin() as conn:
        one(conn, "SELECT id FROM users WHERE id=:o FOR UPDATE", {"o": owner})
        assert_character(conn, owner, character)
        affected = (
            rows(conn, "SELECT id FROM characters WHERE owner_id=:o ORDER BY id", {"o": owner})
            if not enabled
            else [{"id": character}]
        )
        for item in affected:
            assert_character(conn, owner, item["id"], lock=True)
        if enabled and not settings.autonomy_enabled:
            raise BusinessError("AUTONOMY_UNAVAILABLE", "服务端未开启本地活动能力", 409)
        execute(
            conn, "UPDATE users SET autonomy_paused=:p WHERE id=:o", {"p": not enabled, "o": owner}
        )
        if not enabled:
            for item in affected:
                cancel_local(conn, owner, item["id"])
        return autonomy(conn, owner, character, settings)


def cancel_local(conn: Connection, owner: UUID, character: UUID, goal: UUID | None = None) -> None:
    if goal is None:
        cancel_reading(conn, owner, character)
    cancel_plans(conn, owner, character, goal)
    params = {"o": owner, "c": character, "g": goal}
    execute(
        conn,
        """UPDATE task_runs SET status='cancelled',finished_at=now(),error_code='ACTIVITY_PAUSED'
        WHERE owner_id=:o AND character_id=:c AND status='running' AND task_id IN
        (SELECT id FROM tasks WHERE kind='local_activity'
        AND (CAST(:g AS uuid) IS NULL OR goal_id=:g))""",
        params,
    )
    execute(
        conn,
        """UPDATE tasks SET status='cancelled',cancel_requested=true,fencing_token=fencing_token+1,
        error_code='ACTIVITY_PAUSED',lease_until=NULL WHERE owner_id=:o AND character_id=:c
        AND kind='local_activity' AND (CAST(:g AS uuid) IS NULL OR goal_id=:g)
        AND status IN ('queued','retry_wait','running')""",
        params,
    )


def enqueue_activity(
    conn: Connection,
    owner: UUID,
    character: UUID,
    key: str,
    settings: Settings,
    schedule: UUID | None = None,
) -> Row:
    state = assert_character(conn, owner, character, lock=True)
    if not autonomy(conn, owner, character, settings)["enabled"]:
        raise BusinessError("AUTONOMY_PAUSED", "请先明确开启本地自主活动", 409)
    prior = one(
        conn,
        "SELECT id,status FROM tasks WHERE owner_id=:o AND idempotency_key=:k",
        {"o": owner, "k": key},
    )
    if prior:
        return {"task_id": prior["id"], "status": prior["status"]}
    # Only three ranked candidates are examined, and only one is enqueued per wake.
    candidates = rows(
        conn,
        """SELECT * FROM goals g WHERE owner_id=:o AND character_id=:c
        AND status='active' AND NOT EXISTS (SELECT 1 FROM tasks t WHERE t.goal_id=g.id
        AND t.status IN ('queued','retry_wait','running','succeeded','failed','unknown'))
        ORDER BY priority DESC,created_at,id LIMIT 3""",
        {"o": owner, "c": character},
    )
    planned = maybe_enqueue_plan(conn, owner, character, key, settings, candidates, schedule)
    if planned is not None:
        return planned
    # Only local execution uses title interests; opted-in model plans keep
    # their original candidate snapshot and independent choice semantics.
    candidates = rank_candidates(candidates, state["interests"])
    if not candidates:
        return {"task_id": None, "status": "quiet", "reason": "没有可执行的新目标，保持安静"}
    task_id = uuid4()
    execute(
        conn,
        """INSERT INTO tasks(id,owner_id,character_id,kind,input,status,idempotency_key,
        goal_id,schedule_id) VALUES (:id,:o,:c,'local_activity','{}','queued',:k,:g,:s)""",
        {
            "id": task_id,
            "o": owner,
            "c": character,
            "k": key,
            "g": candidates[0]["id"],
            "s": schedule,
        },
    )
    return {"task_id": task_id, "status": "queued"}


def wake(engine: Engine, owner: UUID, character: UUID, key: str, settings: Settings) -> Row:
    with engine.begin() as conn:
        assert_character(conn, owner, character, lock=True)
        old = one(
            conn,
            "SELECT response FROM wake_receipts WHERE owner_id=:o AND request_key=:k",
            {"o": owner, "k": key},
        )
        if old:
            response: Row = old["response"]
            return response
        result = enqueue_activity(conn, owner, character, "wake:" + key, settings)
        execute(
            conn,
            """INSERT INTO wake_receipts(owner_id,character_id,request_key,response)
                VALUES (:o,:c,:k,CAST(:r AS jsonb))""",
            {
                "o": owner,
                "c": character,
                "k": key,
                "r": json.dumps(result, default=str, ensure_ascii=False),
            },
        )
        return result


def scheduler_tick(engine: Engine, settings: Settings, now: datetime | None = None) -> int:
    if not settings.autonomy_enabled:
        return 0
    now = now or datetime.now(UTC)
    with engine.connect() as conn:
        due = rows(
            conn,
            """SELECT s.id,s.owner_id,s.character_id FROM scheduled_jobs s JOIN users u
            ON u.id=s.owner_id WHERE s.enabled AND s.next_run_at<=:now AND NOT u.autonomy_paused
            AND NOT u.disabled ORDER BY s.next_run_at LIMIT 20""",
            {"now": now},
        )
    count = 0
    for candidate in due:
        with engine.begin() as conn:
            assert_character(conn, candidate["owner_id"], candidate["character_id"], lock=True)
            schedule = one(
                conn,
                "SELECT * FROM scheduled_jobs WHERE id=:id FOR UPDATE",
                {"id": candidate["id"]},
            )
            if not schedule or not schedule["enabled"] or schedule["next_run_at"] > now:
                continue
            if not autonomy(conn, schedule["owner_id"], schedule["character_id"], settings)[
                "enabled"
            ]:
                continue
            result = enqueue_activity(
                conn,
                schedule["owner_id"],
                schedule["character_id"],
                f"schedule:{schedule['id']}:{schedule['next_run_at'].isoformat()}",
                settings,
                schedule["id"],
            )
            execute(
                conn,
                """UPDATE scheduled_jobs SET next_run_at=:n,last_enqueued_at=:now WHERE id=:id""",
                {
                    "n": coalesce_next(schedule["next_run_at"], schedule["interval_seconds"], now),
                    "now": now,
                    "id": schedule["id"],
                },
            )
            count += int(result["task_id"] is not None)
    return count


def finish_activity(engine: Engine, task: Row, settings: Settings) -> bool:
    # Everything here is bounded local data work and committed atomically with evidence.
    with engine.begin() as conn:
        state = assert_character(conn, task["owner_id"], task["character_id"], lock=True)
        current = owned(conn, "tasks", task["owner_id"], task["id"], lock=True)
        if current["status"] != "running" or current["fencing_token"] != task["fencing_token"]:
            return False
        goal = owned(conn, "goals", task["owner_id"], task["goal_id"], lock=True)
        if (
            not autonomy(conn, task["owner_id"], task["character_id"], settings)["enabled"]
            or goal["status"] != "active"
            or state["memory_epoch"] != task["memory_epoch"]
        ):
            cancel_local(conn, task["owner_id"], task["character_id"], goal["id"])
            return False
        result = organize_material(goal["material"])
        if not result["excerpt_lines"] or not result["verification"]["all_excerpts_in_source"]:
            raise BusinessError("VERIFICATION_FAILED", "材料摘录核验失败", 409)
        event_id, journal_id = uuid4(), uuid4()
        execute(
            conn,
            """UPDATE tasks SET status='succeeded',result=CAST(:r AS jsonb),lease_until=NULL,
            error_code=NULL,updated_at=now() WHERE id=:id""",
            {"r": json.dumps(result, ensure_ascii=False), "id": task["id"]},
        )
        execute(
            conn,
            """UPDATE task_runs SET status='succeeded',node='verified_local',finished_at=now()
            WHERE id=:id""",
            {"id": task["run_id"]},
        )
        execute(
            conn,
            "UPDATE goals SET status='completed',version=version+1,updated_at=now() WHERE id=:id",
            {"id": goal["id"]},
        )
        execute(
            conn,
            """INSERT INTO experience_events(id,owner_id,character_id,event_type,reality_class,
            task_run_id,dedupe_key,payload)
            VALUES (:id,:o,:c,'local_activity_completed','observed',:run,
            :key,CAST(:p AS jsonb))""",
            {
                "id": event_id,
                "o": task["owner_id"],
                "c": task["character_id"],
                "run": task["run_id"],
                "key": "activity:" + str(task["id"]),
                "p": json.dumps(
                    {
                        "goal_id": str(goal["id"]),
                        "task_id": str(task["id"]),
                        "source_hash": result["source_hash"],
                        "excerpt_count": len(result["excerpt_lines"]),
                    }
                ),
            },
        )
        user = one(conn, "SELECT timezone FROM users WHERE id=:o", {"o": task["owner_id"]})
        assert user
        local_date = datetime.now(UTC).astimezone(ZoneInfo(user["timezone"])).date()
        body = (
            "我完成了一次站内材料整理，将用户提供的材料摘录为"
            f"{len(result['excerpt_lines'])}个不重复段落，并核对每段均存在于原文。"
            "清单采用固定模板，没有进行网络研究或外部操作。"
        )
        execute(
            conn,
            """INSERT INTO journal_entries
            (id,owner_id,character_id,task_id,local_date,timezone,body)
            VALUES (:id,:o,:c,:t,:day,:tz,:body)""",
            {
                "id": journal_id,
                "o": task["owner_id"],
                "c": task["character_id"],
                "t": task["id"],
                "day": local_date,
                "tz": user["timezone"],
                "body": body,
            },
        )
        execute(
            conn,
            """INSERT INTO journal_sources(owner_id,character_id,journal_id,event_id)
            VALUES (:o,:c,:j,:e)""",
            {"o": task["owner_id"], "c": task["character_id"], "j": journal_id, "e": event_id},
        )
        execute(
            conn,
            """UPDATE character_states SET last_active_at=now(),state_version=state_version+1
            WHERE character_id=:c""",
            {"c": task["character_id"]},
        )
        return True


def process_activity_once(engine: Engine, settings: Settings) -> bool:
    if not settings.autonomy_enabled:
        return False
    recover_expired(engine, settings)
    task = claim_task(engine, "local_activity")
    if not task:
        return False
    finish_activity(engine, task, settings)
    return True


def journal_view(conn: Connection, journal: Row) -> Row:
    journal["sources"] = rows(
        conn,
        """SELECT e.id AS event_id,e.event_type,e.occurred_at FROM
        journal_sources s JOIN experience_events e ON e.id=s.event_id WHERE s.journal_id=:id""",
        {"id": journal["id"]},
    )
    return journal


def delete_goal(engine: Engine, owner: UUID, goal_id: UUID) -> Row:
    with engine.begin() as conn:
        goal = owned(conn, "goals", owner, goal_id)
        assert_character(conn, owner, goal["character_id"], lock=True)
        cancel_local(conn, owner, goal["character_id"], goal_id)
        execute(
            conn,
            """UPDATE goals SET title='已删除',material='',status='deleted',version=version+1
            WHERE id=:g""",
            {"g": goal_id},
        )
        execute(
            conn,
            "UPDATE tasks SET result=NULL,input='{}' WHERE owner_id=:o AND goal_id=:g",
            {"o": owner, "g": goal_id},
        )
        execute(
            conn,
            """UPDATE journal_entries SET body='',status='invalidated' WHERE owner_id=:o
            AND task_id IN (SELECT id FROM tasks WHERE goal_id=:g)""",
            {"o": owner, "g": goal_id},
        )
        execute(
            conn,
            """UPDATE notifications SET body='',status='invalidated' WHERE owner_id=:o
            AND source_event_id IN (SELECT id FROM experience_events WHERE owner_id=:o
            AND event_type='local_activity_completed' AND payload->>'goal_id'=:g)""",
            {"o": owner, "g": str(goal_id)},
        )
        execute(
            conn,
            """UPDATE experience_events SET payload='{}' WHERE owner_id=:o
            AND event_type='local_activity_completed' AND payload->>'goal_id'=:g""",
            {"o": owner, "g": str(goal_id)},
        )
        return {"status": "deleted"}
