"""User-triggered local roleplay, bounded to two turns and isolated from fact memory."""

import hashlib
import json
from uuid import UUID, uuid4

from sqlalchemy import Engine

from app.errors import BusinessError
from app.memory import assert_character
from app.repository import Row, execute, one, rows


def exchange_view(value: Row) -> Row:
    return {**value, "reality_class": "roleplay", "generation_mode": "local_template"}


def create_exchange(
    engine: Engine, owner: UUID, first: UUID, second: UUID, topic: str, key: UUID
) -> Row:
    if first == second:
        raise BusinessError("DISTINCT_CHARACTERS_REQUIRED", "请选择两个不同的角色", 400)
    fingerprint = hashlib.sha256(
        json.dumps(
            {"from": str(first), "to": str(second), "topic": topic},
            sort_keys=True,
            ensure_ascii=False,
        ).encode()
    ).hexdigest()
    with engine.begin() as conn:
        user = one(conn, "SELECT autonomy_paused FROM users WHERE id=:o FOR UPDATE", {"o": owner})
        states = {
            c: assert_character(conn, owner, c, lock=True) for c in sorted((first, second), key=str)
        }
        old = one(
            conn,
            "SELECT * FROM character_exchanges WHERE owner_id=:o AND request_key=:k",
            {"o": owner, "k": key},
        )
        if old:
            if old["request_hash"] != fingerprint:
                raise BusinessError("IDEMPOTENCY_CONFLICT", "请求标识已绑定其他交流参数", 409)
            return exchange_view(old)
        if not user or user["autonomy_paused"]:
            raise BusinessError("AUTONOMY_PAUSED", "请先明确允许站内活动，再发起角色交流", 409)
        if not all(state["enabled"] for state in states.values()):
            raise BusinessError("CHARACTER_DISABLED", "参与交流的角色已停用", 409)
        first_name, second_name = states[first]["name"], states[second]["name"]
        messages = [
            {
                "speaker_character_id": str(first),
                "seq": 1,
                "body": f"【站内模板角色扮演】{second_name}，我们来讨论：{topic}。",
            },
            {
                "speaker_character_id": str(second),
                "seq": 2,
                "body": f"【站内模板角色扮演】{first_name}，我收到这个主题了。"
                "建议先明确目标，再核对材料。此次没有读取其他角色的私人记忆，"
                "也没有进行模型推理或外部行动。",
            },
        ]
        identity = uuid4()
        result = one(
            conn,
            """INSERT INTO character_exchanges
            (id,owner_id,from_character_id,to_character_id,request_key,request_hash,topic,messages)
            VALUES (:id,:o,:f,:t,:k,:hash,:topic,CAST(:messages AS jsonb)) RETURNING *""",
            {
                "id": identity,
                "o": owner,
                "f": first,
                "t": second,
                "k": key,
                "hash": fingerprint,
                "topic": topic,
                "messages": json.dumps(messages, ensure_ascii=False),
            },
        )
        low, high = sorted((first, second), key=str)
        execute(
            conn,
            """INSERT INTO relationships
            (owner_id,low_character_id,high_character_id,exchange_count,last_exchange_at)
            VALUES (:o,:low,:high,1,now()) ON CONFLICT(owner_id,low_character_id,high_character_id)
            DO UPDATE SET exchange_count=relationships.exchange_count+1,last_exchange_at=now()""",
            {"o": owner, "low": low, "high": high},
        )
        for character in (first, second):
            execute(
                conn,
                """INSERT INTO experience_events
                (id,owner_id,character_id,event_type,reality_class,dedupe_key,payload)
                VALUES (:id,:o,:c,'character_exchange_completed','observed',:key,
                CAST(:payload AS jsonb))""",
                {
                    "id": uuid4(),
                    "o": owner,
                    "c": character,
                    "key": f"exchange:{identity}:{character}",
                    "payload": json.dumps({"exchange_id": str(identity), "mode": "local_roleplay"}),
                },
            )
        assert result
        return exchange_view(result)


def get_exchange(engine: Engine, owner: UUID, identity: UUID) -> Row:
    with engine.connect() as conn:
        result = one(
            conn,
            "SELECT * FROM character_exchanges WHERE id=:id AND owner_id=:o",
            {"id": identity, "o": owner},
        )
    if not result:
        raise BusinessError("NOT_FOUND", "交流不存在", 404)
    return exchange_view(result)


def delete_exchange(engine: Engine, owner: UUID, identity: UUID) -> Row:
    with engine.begin() as conn:
        one(conn, "SELECT id FROM users WHERE id=:o FOR UPDATE", {"o": owner})
        value = one(
            conn,
            "SELECT * FROM character_exchanges WHERE id=:id AND owner_id=:o",
            {"id": identity, "o": owner},
        )
        if not value:
            raise BusinessError("NOT_FOUND", "交流不存在", 404)
        first, second = value["from_character_id"], value["to_character_id"]
        low, high = sorted((first, second), key=str)
        for character in (low, high):
            assert_character(conn, owner, character, lock=True)
        if value["status"] != "deleted":
            execute(
                conn,
                """UPDATE character_exchanges SET topic='',messages='[]',status='deleted'
                WHERE id=:id""",
                {"id": identity},
            )
            execute(
                conn,
                """UPDATE relationships SET exchange_count=GREATEST(0,exchange_count-1),
                last_exchange_at=(SELECT max(created_at) FROM character_exchanges
                  WHERE owner_id=:o AND status='completed' AND
                  ((from_character_id=:low AND to_character_id=:high) OR
                   (from_character_id=:high AND to_character_id=:low)))
                WHERE owner_id=:o AND low_character_id=:low AND high_character_id=:high""",
                {"o": owner, "low": low, "high": high},
            )
        return {"status": "deleted"}


def list_exchanges(engine: Engine, owner: UUID, character: UUID) -> list[Row]:
    with engine.connect() as conn:
        assert_character(conn, owner, character)
        values = rows(
            conn,
            """SELECT * FROM character_exchanges WHERE owner_id=:o
            AND (from_character_id=:c OR to_character_id=:c) AND status='completed'
            ORDER BY created_at DESC,id DESC LIMIT 100""",
            {"o": owner, "c": character},
        )
        return [exchange_view(value) for value in values]


def relationships(engine: Engine, owner: UUID, character: UUID) -> list[Row]:
    with engine.connect() as conn:
        assert_character(conn, owner, character)
        return rows(
            conn,
            """SELECT CASE WHEN low_character_id=:c THEN high_character_id
            ELSE low_character_id END AS other_character_id,exchange_count,last_exchange_at
            FROM relationships WHERE owner_id=:o AND
            (low_character_id=:c OR high_character_id=:c) AND exchange_count>0
            ORDER BY last_exchange_at DESC LIMIT 100""",
            {"o": owner, "c": character},
        )
