"""Versioned recipes linked only to currently verified, owned success evidence."""

from uuid import UUID

from sqlalchemy import Connection

from app import autobiography
from app.artifact_store import read_verified
from app.config import Settings
from app.errors import BusinessError
from app.memory import assert_character
from app.repository import Row, one, rows


def recipe(
    identity: str,
    title: str,
    allowed: bool,
    steps: list[str],
    rules: list[str],
    evidence: list[Row],
    reuse_hint: str,
) -> Row:
    return {
        "recipe_id": identity,
        "title": title,
        "recipe_version": 1,
        "execution_allowed": allowed,
        "steps": steps,
        "verification_rules": rules,
        "evidence": evidence,
        "recent_success_count": len(evidence),
        "reuse_hint": reuse_hint,
    }


def catalog(conn: Connection, settings: Settings, owner: UUID, character: UUID) -> Row:
    state = assert_character(conn, owner, character, lock=True)
    _, segments = autobiography.sources(conn, owner, character, include_facts=False)
    evidence = [
        {
            "event_id": segment["source"]["id"],
            "occurred_at": segment["occurred_at"],
            "evidence_hash": segment["source"]["evidence_hash"],
        }
        for segment in segments
        if segment["reality_class"] == "observed" and segment["source"]["kind"] == "event"
    ]
    result: Row = {
        "items": [],
        "learning_mode": "evidence_linked_catalog",
        "activity_window_limit": 25,
        "artifact_window_limit": 10,
    }
    if not evidence:
        return result

    user = one(conn, "SELECT autonomy_paused,disabled FROM users WHERE id=:o", {"o": owner})
    organize_allowed = bool(
        settings.autonomy_enabled
        and state["enabled"]
        and user
        and not user["autonomy_paused"]
        and not user["disabled"]
    )
    result["items"].append(
        recipe(
            "organize_local_material_v1",
            "站内材料整理",
            organize_allowed,
            [
                "提交站内目标与材料",
                "执行本地整理并提取原文摘录",
                "核验来源摘要与摘录后记录完成事件",
            ],
            [
                "任务、运行与目标均成功完成",
                "活动事件为真实观察",
                "来源 SHA256 一致且摘录存在于原材料",
            ],
            evidence,
            "在目标页提交新材料，复用现有站内整理流程；最近窗口内成功次数不代表终身累计。",
        )
    )

    valid_events = rows(
        conn,
        """SELECT id,payload->>'goal_id' AS goal_id FROM experience_events
        WHERE owner_id=:o AND character_id=:c AND id=ANY(:ids)
        ORDER BY occurred_at DESC,id""",
        {"o": owner, "c": character, "ids": [UUID(x["event_id"]) for x in evidence]},
    )
    event_by_goal: dict[UUID, Row] = {}
    for event in valid_events:
        event_by_goal.setdefault(UUID(event["goal_id"]), event)
    artifacts = rows(
        conn,
        """SELECT a.id,a.goal_id,a.execution_id,a.sha256,a.byte_size,a.created_at
        FROM artifacts a JOIN tool_execution_logs l ON l.id=a.execution_id
          AND l.owner_id=a.owner_id AND l.character_id=a.character_id AND l.goal_id=a.goal_id
        WHERE a.owner_id=:o AND a.character_id=:c AND a.status='available'
          AND l.status='succeeded' AND l.tool_name='local_note' AND a.goal_id=ANY(:goals)
        ORDER BY a.created_at DESC,a.id LIMIT 10""",
        {"o": owner, "c": character, "goals": list(event_by_goal)},
    )
    exported: list[Row] = []
    for artifact in artifacts:
        try:
            read_verified(
                settings.artifact_root, artifact["id"], artifact["sha256"], artifact["byte_size"]
            )
        except (BusinessError, OSError):
            continue
        exported.append(
            {
                "artifact_id": str(artifact["id"]),
                "goal_id": str(artifact["goal_id"]),
                "execution_id": str(artifact["execution_id"]),
                "event_id": str(event_by_goal[artifact["goal_id"]]["id"]),
                "sha256": artifact["sha256"],
                "byte_size": artifact["byte_size"],
                "created_at": artifact["created_at"].isoformat(),
            }
        )
    if exported:
        result["items"].append(
            recipe(
                "export_verified_note_v1",
                "导出已核验笔记",
                bool(state["tools_enabled"]),
                [
                    "选择已核验完成的本角色目标",
                    "通过本地笔记工具生成文件",
                    "读取实际文件并核验字节数和 SHA256",
                ],
                [
                    "来源仍有有效整理事件",
                    "工具执行成功且产物可用",
                    "实际文件字节数和 SHA256 均与记录一致",
                ],
                exported,
                "在工具页选择已完成目标导出笔记；权限关闭时保留历史证据，不能执行导出。",
            )
        )
    return result
