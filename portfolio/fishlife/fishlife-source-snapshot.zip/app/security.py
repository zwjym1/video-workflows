import hashlib
import hmac
import secrets
from datetime import UTC, datetime, timedelta
from uuid import uuid4

from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerificationError
from fastapi import Request
from sqlalchemy import Engine

from app.config import Settings
from app.errors import BusinessError
from app.repository import Row, execute, one

_hasher = PasswordHasher()
_dummy_hash = _hasher.hash("fishlife-nonexistent-account-placeholder")
COOKIE = "fishlife_session"


def digest(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()


def hash_password(value: str) -> str:
    if len(value) < 12 or len(value) > 256:
        raise ValueError("Password must contain 12 to 256 characters")
    return _hasher.hash(value)


def verify_password(encoded: str, value: str) -> bool:
    try:
        return _hasher.verify(encoded, value)
    except (VerificationError, InvalidHashError):
        return False


def csrf_for(token: str) -> str:
    return digest("csrf:" + token)


def require_origin(request: Request, settings: Settings) -> None:
    if request.headers.get("origin", "").rstrip("/") != settings.public_origin.rstrip("/"):
        raise BusinessError("ORIGIN_DENIED", "请求来源不被允许", 403)


def authenticate(request: Request, engine: Engine, settings: Settings, write: bool = False) -> Row:
    token = request.cookies.get(COOKIE, "")
    with engine.connect() as conn:
        user = one(
            conn,
            """SELECT u.id,u.username,s.id AS session_id,s.csrf_hash
            FROM sessions s JOIN users u ON u.id=s.owner_id
            WHERE s.token_hash=:token AND s.expires_at>now() AND s.revoked_at IS NULL
            AND NOT u.disabled""",
            {"token": digest(token)},
        )
    if not user:
        raise BusinessError("UNAUTHENTICATED", "请先登录", 401)
    csrf = csrf_for(token)
    if write:
        require_origin(request, settings)
        supplied = request.headers.get("x-csrf-token", "")
        if not hmac.compare_digest(digest(supplied), user["csrf_hash"]):
            raise BusinessError("CSRF_DENIED", "安全令牌无效，请刷新后重试", 403)
    user["csrf_token"] = csrf
    return user


def login(engine: Engine, settings: Settings, username: str, password: str) -> tuple[Row, str]:
    key = digest(username.casefold())
    with engine.begin() as conn:
        attempt = one(
            conn,
            """INSERT INTO auth_rate_limits(key,attempts,reset_at)
            VALUES (:key,1,now()+interval '15 minutes')
            ON CONFLICT(key) DO UPDATE SET
            attempts=CASE WHEN auth_rate_limits.reset_at<now() THEN 1
                ELSE auth_rate_limits.attempts+1 END,
            reset_at=CASE WHEN auth_rate_limits.reset_at<now() THEN now()+interval '15 minutes'
                ELSE auth_rate_limits.reset_at END RETURNING attempts""",
            {"key": key},
        )
        user = one(
            conn,
            "SELECT id,username,password_hash,disabled FROM users WHERE username=:u",
            {"u": username},
        )
    if attempt and attempt["attempts"] > 10:
        raise BusinessError("LOGIN_RATE_LIMITED", "尝试过多，请15分钟后重试", 429)
    if not verify_password(user["password_hash"] if user else _dummy_hash, password):
        raise BusinessError("INVALID_CREDENTIALS", "用户名或密码错误", 401)
    if not user or user["disabled"]:
        raise BusinessError("INVALID_CREDENTIALS", "用户名或密码错误", 401)
    token = secrets.token_urlsafe(48)
    csrf = csrf_for(token)
    with engine.begin() as conn:
        execute(
            conn,
            """INSERT INTO sessions(id,owner_id,token_hash,csrf_hash,expires_at)
            VALUES (:id,:owner,:token,:csrf,:expires)""",
            {
                "id": uuid4(),
                "owner": user["id"],
                "token": digest(token),
                "csrf": digest(csrf),
                "expires": datetime.now(UTC) + timedelta(days=settings.session_days),
            },
        )
        execute(conn, "DELETE FROM auth_rate_limits WHERE key=:key", {"key": key})
    return {"user": {"id": user["id"], "username": user["username"]}, "csrf_token": csrf}, token
