"""Validate a fresh snapshot from trusted official SDK code, never model-generated text."""

from datetime import datetime
from typing import Literal

from app.qoder_routing import choose_model, cli_model_name


def select_free_model(
    snapshot: dict[str, object], now: datetime, *, ds_free_remaining: int | None = None
) -> Literal["dfmodel", "qfmodel"] | None:
    """Fail closed on ambiguity. This does not authenticate a supplied dictionary.

    Only trusted backend SDK transport may supply this data; it must never be
    accepted from an API client, a model, stored account balances or user prose.
    The daily DS counter requires a separate authoritative source if available.
    """
    if now.tzinfo is None or now.utcoffset() is None:
        raise ValueError("Timezone-aware time required")
    at = snapshot.get("queried_at")
    if not isinstance(at, str) or len(at) > 80:
        return None
    try:
        queried = datetime.fromisoformat(at)
        if queried.tzinfo is None or queried.utcoffset() is None:
            return None
        if not 0 <= (now - queried).total_seconds() <= 30:
            return None
    except (ValueError, OverflowError):
        return None
    plan = snapshot.get("plan")
    if snapshot.get("status") != "received" or not isinstance(plan, str):
        return None
    # This account type was observed through the authenticated official SDK.
    # Unknown plans require verification rather than prefix-based guessing.
    if plan != "personal_standard":
        return None
    models = snapshot.get("selected_models")
    if not isinstance(models, list) or len(models) > 10:
        return None
    allowed: dict[str, bool] = {}
    for item in models:
        if not isinstance(item, dict):
            return None
        identity = item.get("id")
        if identity not in ("dfmodel", "qfmodel"):
            continue
        if identity in allowed:
            return None
        price = item.get("price_factor")
        allowed[identity] = (
            item.get("name") == cli_model_name(identity)
            and item.get("source") == "system"
            and item.get("enabled") is True
            and item.get("free") is True
            and type(price) in (int, float)
            and price == 0
        )
    ds_verified = (
        allowed.get("dfmodel", False) and type(ds_free_remaining) is int and ds_free_remaining > 0
    )
    return choose_model(
        now, ds_free_available=ds_verified, qwen_free_verified=allowed.get("qfmodel", False)
    )
