"""Fail-closed HTTPS text reader with exact allowlist, pinned IP and bounded work."""

import hashlib
import http.client
import ipaddress
import queue
import re
import socket
import ssl
import threading
import time
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from html.parser import HTMLParser
from urllib.parse import urljoin, urlsplit, urlunsplit

from app.errors import BusinessError
from app.repository import Row

MAX_BYTES = 262144
_dns_slots = threading.BoundedSemaphore(2)
Resolver = Callable[[str, float], list[str]]


@dataclass
class FetchResponse:
    status: int
    headers: Mapping[str, str]
    body: bytes


Transport = Callable[[str, str, str, float], FetchResponse]


def domain_name(value: str) -> str:
    value = value.lower()
    if len(value) > 253 or value != value.strip() or "." not in value:
        raise BusinessError("WEB_DOMAIN_INVALID", "请提供完整ASCII域名，不含URL或通配符", 422)
    if not all(re.fullmatch(r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?", x) for x in value.split(".")):
        raise BusinessError("WEB_DOMAIN_INVALID", "域名格式无效", 422)
    try:
        ipaddress.ip_address(value)
    except ValueError:
        return value
    raise BusinessError("WEB_DOMAIN_INVALID", "不允许IP字面量", 422)


def validate_url(url: str, domains: set[str]) -> tuple[str, str, str]:
    if len(url) > 2000 or not url.isascii() or any(ord(c) <= 32 or ord(c) == 127 for c in url):
        raise BusinessError("WEB_URL_DENIED", "URL过长或含不支持字符，请使用百分号编码", 400)
    if "\\" in url:
        raise BusinessError("WEB_URL_DENIED", "URL不允许反斜线", 400)
    try:
        parsed = urlsplit(url)
        host = domain_name(parsed.hostname or "")
        if (
            parsed.scheme != "https"
            or parsed.username is not None
            or parsed.password is not None
            or parsed.port not in (None, 443)
            or parsed.fragment
            or host not in domains
        ):
            raise ValueError("URL policy denied")
    except (ValueError, BusinessError) as exc:
        raise BusinessError("WEB_URL_DENIED", "仅允许已授权域名的HTTPS标准端口URL", 400) from exc
    normalized = urlunsplit(("https", host, parsed.path or "/", parsed.query, ""))
    path = (parsed.path or "/") + ("?" + parsed.query if parsed.query else "")
    return host, path, normalized


def public_addresses(values: list[str]) -> list[str]:
    if not values:
        raise BusinessError("WEB_DNS_DENIED", "域名没有可用公网地址", 400)
    safe = []
    translations = [
        ipaddress.ip_network(x)
        for x in ("64:ff9b::/96", "64:ff9b:1::/48", "2002::/16", "2001::/32")
    ]
    for value in values:
        try:
            address = ipaddress.ip_address(value)
        except ValueError as exc:
            raise BusinessError("WEB_DNS_DENIED", "DNS地址无效", 400) from exc
        if (
            not address.is_global
            or address.is_multicast
            or address.is_reserved
            or address.is_unspecified
            or address.is_loopback
            or address.is_link_local
            or (
                isinstance(address, ipaddress.IPv6Address)
                and (
                    address.ipv4_mapped is not None
                    or any(address in network for network in translations)
                )
            )
        ):
            raise BusinessError("WEB_DNS_DENIED", "域名含非许可公网地址或转换地址", 400)
        safe.append(str(address))
    return sorted(set(safe))


def remaining(deadline: float) -> float:
    value = deadline - time.monotonic()
    if value <= 0:
        raise BusinessError("WEB_TIMEOUT", "网页读取超过总时间限制", 504)
    return value


def resolve_public(host: str, deadline: float) -> list[str]:
    # libc DNS has no portable deadline. At most two daemon calls may remain stuck;
    # callers return on deadline and further requests fail closed rather than grow threads.
    if not _dns_slots.acquire(blocking=False):
        raise BusinessError("WEB_RESOLVER_BUSY", "安全域名解析暂不可用", 503)
    result: queue.Queue[list[str] | Exception] = queue.Queue(maxsize=1)

    def lookup() -> None:
        try:
            values = socket.getaddrinfo(
                host, 443, type=socket.SOCK_STREAM, proto=socket.IPPROTO_TCP
            )
            result.put([str(value[4][0]) for value in values])
        except Exception as exc:
            result.put(exc)
        finally:
            _dns_slots.release()

    threading.Thread(target=lookup, daemon=True, name="fishlife-safe-dns").start()
    try:
        value = result.get(timeout=remaining(deadline))
    except queue.Empty as exc:
        raise BusinessError("WEB_TIMEOUT", "域名解析超时", 504) from exc
    if isinstance(value, Exception):
        raise BusinessError("WEB_DNS_FAILED", "域名解析失败", 502)
    remaining(deadline)
    return public_addresses(value)


class PinnedHTTPSConnection(http.client.HTTPSConnection):
    def __init__(self, host: str, ip: str, deadline: float) -> None:
        self.target_ip, self.deadline = ip, deadline
        self.active_socket: socket.socket | None = None
        context = ssl.create_default_context()
        context.set_alpn_protocols(["http/1.1"])
        self.tls_context = context
        super().__init__(host, port=443, timeout=remaining(deadline), context=context)

    def connect(self) -> None:
        # No hostname is passed to connect(), so there is no second DNS resolution.
        family = socket.AF_INET6 if ":" in self.target_ip else socket.AF_INET
        raw = socket.socket(family, socket.SOCK_STREAM)
        self.sock = raw
        self.active_socket = raw
        try:
            raw.settimeout(remaining(self.deadline))
            raw.connect((self.target_ip, 443))
            self.sock = self.tls_context.wrap_socket(raw, server_hostname=self.host)
            self.active_socket = self.sock
            self.sock.settimeout(remaining(self.deadline))
        except BaseException:
            raw.close()
            raise


def pinned_request(host: str, ip: str, path: str, deadline: float) -> FetchResponse:
    connection = PinnedHTTPSConnection(host, ip, deadline)

    def expire() -> None:
        # HTTPResponse may keep a makefile alive after HTTPConnection.sock becomes
        # None for Connection: close. Retain the actual socket for deadline shutdown.
        sock = connection.active_socket
        if sock is not None:
            try:
                sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            sock.close()

    timer = threading.Timer(remaining(deadline), expire)
    timer.daemon = True
    timer.start()
    response: http.client.HTTPResponse | None = None
    try:
        connection.request(
            "GET",
            path,
            headers={
                "Host": host,
                "User-Agent": "FishLife-ReadOnly/1.0",
                "Accept": "text/html,text/plain",
                "Accept-Encoding": "identity",
                "Connection": "close",
            },
        )
        response = connection.getresponse()
        headers = {key.lower(): value for key, value in response.getheaders()}
        content_length = headers.get("content-length")
        if content_length and (not content_length.isdigit() or int(content_length) > MAX_BYTES):
            raise BusinessError("WEB_TOO_LARGE", "网页超过256KiB限制", 400)
        chunks = bytearray()
        if response.status not in (301, 302, 303, 307, 308):
            while True:
                remaining(deadline)
                if connection.sock is not None:
                    connection.sock.settimeout(remaining(deadline))
                chunk = response.read1(min(16384, MAX_BYTES + 1 - len(chunks)))
                if not chunk:
                    break
                chunks.extend(chunk)
                if len(chunks) > MAX_BYTES:
                    raise BusinessError("WEB_TOO_LARGE", "网页超过256KiB限制", 400)
        remaining(deadline)
        return FetchResponse(response.status, headers, bytes(chunks))
    finally:
        timer.cancel()
        if response is not None:
            response.close()
        connection.close()


class TextOnly(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.hidden = 0
        self.parts: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag in ("script", "style", "noscript", "template"):
            self.hidden += 1

    def handle_endtag(self, tag: str) -> None:
        if tag in ("script", "style", "noscript", "template"):
            self.hidden = max(0, self.hidden - 1)

    def handle_data(self, data: str) -> None:
        if not self.hidden and data.strip():
            self.parts.append(data.strip())


def fetch_page(
    url: str,
    domains: set[str],
    resolver: Resolver = resolve_public,
    transport: Transport = pinned_request,
    timeout_seconds: float = 15,
) -> Row:
    deadline = time.monotonic() + min(15, timeout_seconds)
    current = url
    for hop in range(4):
        host, path, normalized = validate_url(current, domains)
        addresses = public_addresses(resolver(host, deadline))
        remaining(deadline)
        try:
            response = transport(host, addresses[0], path, deadline)
        except BusinessError:
            raise
        except (OSError, http.client.HTTPException) as exc:
            raise BusinessError("WEB_FETCH_UNKNOWN", "网页连接失败或结果不确定", 502) from exc
        remaining(deadline)
        if response.status in (301, 302, 303, 307, 308):
            if hop == 3 or not response.headers.get("location"):
                raise BusinessError("WEB_REDIRECT_DENIED", "网页重定向超过限制或无效", 400)
            current = urljoin(normalized, response.headers["location"])
            continue
        if response.status != 200:
            raise BusinessError("WEB_HTTP_FAILED", "网页未返回成功状态", 502)
        if len(response.body) > MAX_BYTES:
            raise BusinessError("WEB_TOO_LARGE", "网页超过256KiB限制", 400)
        kind = response.headers.get("content-type", "").split(";", 1)[0].strip().lower()
        if kind not in ("text/html", "text/plain"):
            raise BusinessError("WEB_TYPE_DENIED", "只允许HTML或纯文本网页", 400)
        if response.headers.get("content-encoding", "identity").lower() != "identity":
            raise BusinessError("WEB_ENCODING_DENIED", "不接受压缩内容", 400)
        decoded = response.body.decode("utf-8", errors="replace")
        if kind == "text/html":
            parser = TextOnly()
            parser.feed(decoded)
            decoded = "\n".join(parser.parts)
        text = decoded[:10000]
        return {
            "final_url": normalized,
            "text_content": text,
            "untrusted": True,
            "text_sha256": hashlib.sha256(text.encode()).hexdigest(),
            "raw_sha256": hashlib.sha256(response.body).hexdigest(),
            "byte_size": len(response.body),
            "http_status": response.status,
        }
    raise AssertionError("Bounded redirect loop exhausted")
