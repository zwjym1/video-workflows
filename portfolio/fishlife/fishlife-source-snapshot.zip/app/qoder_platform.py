"""Explicit backend-selected paths and process dispatch; never model input."""

import os
from collections.abc import Mapping, Sequence
from pathlib import PurePosixPath, PureWindowsPath
from typing import Literal

Platform = Literal["posix", "windows"]


def run_native_process(
    *,
    executable: str,
    args: Sequence[str],
    cwd: str,
    env: Mapping[str, str],
    stdin: str = "",
    timeout: float = 10,
    max_output_bytes: int = 1048576,
) -> str:
    if os.name == "nt":
        from app.windows_process import run_windows_process

        runner = run_windows_process
    else:
        from app.bounded_process import run_bounded_process

        runner = run_bounded_process
    return runner(
        executable=executable,
        args=args,
        cwd=cwd,
        env=env,
        stdin=stdin,
        timeout=timeout,
        max_output_bytes=max_output_bytes,
    )


def validate_path(value: str, platform: Platform) -> None:
    if not isinstance(value, str) or "\0" in value or platform not in ("posix", "windows"):
        raise ValueError("Invalid configured path")
    if platform == "windows":
        path = PureWindowsPath(value)
        if (
            not path.is_absolute()
            or len(path.drive) != 2
            or path.drive[1] != ":"
            or ".." in path.parts
            or ":" in value[2:]
        ):
            raise ValueError("Absolute local Windows path required")
    else:
        if not PurePosixPath(value).is_absolute() or ".." in value.split("/") or "\\" in value:
            raise ValueError("Absolute POSIX path required")


def minimal_environment(node: str, cwd: str, config_dir: str, platform: Platform) -> dict[str, str]:
    environment = {"LANG": "C.UTF-8", "HOME": cwd, "QODERCN_CONFIG_DIR": config_dir}
    if platform == "windows":
        # Only the operating-system root is inherited; no proxy/model/database secrets.
        system_root = os.environ.get("SystemRoot", "C:/Windows")
        validate_path(system_root, "windows")
        environment.update(
            SystemRoot=system_root,
            USERPROFILE=cwd,
            TEMP=cwd,
            TMP=cwd,
            PATH=str(PureWindowsPath(node).parent),
        )
    return environment
