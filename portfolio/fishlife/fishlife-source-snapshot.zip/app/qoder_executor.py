"""One bounded, explicitly enabled Qoder invocation; no provider auto-registration."""

import json
import re
from collections.abc import Callable
from copy import deepcopy
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Literal
from uuid import UUID

from sqlalchemy import Engine

from app.config import Settings
from app.errors import BusinessError
from app.model_client import ModelFailure, ModelResult, request_payload
from app.qoder_catalog import select_free_model
from app.qoder_dispatch import begin_dispatch, mark_unknown, revalidate_dispatch
from app.qoder_invocation import QoderInvocation, build_invocation
from app.qoder_platform import Platform, run_native_process
from app.qoder_result import parse_result
from app.qoder_routing import cli_model_name
from app.repository import Row


@dataclass(frozen=True)
class QoderMetadata:
    snapshot: dict[str, object]
    account_scope: str
    ds_free_remaining: int | None = None


@dataclass(frozen=True)
class QoderPaths:
    node: str
    cli: str
    cwd: str
    config_dir: str
    platform: Platform = "posix"


@dataclass(frozen=True)
class PreparedQoderCall:
    metadata: QoderMetadata
    selected: Literal["dfmodel", "qfmodel"]
    owner_id: UUID
    task_id: UUID
    run_id: UUID
    source_id: UUID
    _issuer: object = field(repr=False)

    @property
    def model(self) -> str:
        return cli_model_name(self.selected)


def _run(invocation: QoderInvocation) -> str:
    return run_native_process(
        executable=invocation.executable,
        args=invocation.args,
        cwd=invocation.cwd,
        env=invocation.env,
        stdin=invocation.stdin,
        timeout=invocation.timeout,
        max_output_bytes=invocation.max_output_bytes,
    )


def _source(task: Row, context: Row) -> tuple[str, str]:
    try:
        source = context["message"]
        expected = {
            "owner_id": task["owner_id"],
            "character_id": task["character_id"],
            "id": task["input"]["message_id"],
        }
        if any(UUID(str(source[key])) != UUID(str(value)) for key, value in expected.items()):
            raise ValueError("Source identity mismatch")
        content, kind = source["content"], source["content_kind"]
        if not isinstance(content, str) or not isinstance(kind, str):
            raise ValueError("Invalid source text")
        return content, kind
    except (KeyError, TypeError, ValueError):
        raise ModelFailure("QODER_CONTEXT_INVALID") from None


class QoderExecutor:
    """Dependencies must be trusted backend code, never API/model supplied values.

    Metadata must come from the authenticated official transport for the same
    CLI configuration. account_preflight must verify consent, account binding
    and pre-existing unresolved calls outside this database. No production
    implementation of those transports is registered yet. Enabled defaults off.
    """

    def __init__(
        self,
        engine: Engine,
        settings: Settings,
        paths: QoderPaths,
        *,
        metadata: Callable[[], QoderMetadata],
        account_preflight: Callable[[str], None],
        enabled: bool = False,
        clock: Callable[[], datetime] = lambda: datetime.now(UTC),
        runner: Callable[[QoderInvocation], str] = _run,
    ) -> None:
        self.engine, self.settings, self.paths = engine, settings, paths
        self.metadata, self.account_preflight = metadata, account_preflight
        self.enabled, self.clock, self.runner = enabled, clock, runner
        self._issuer = object()

    def prepare(self, task: Row, context: Row) -> PreparedQoderCall:
        """Choose a model once, before the queue reserves its exact provider/model."""
        if self.enabled is not True:
            raise ModelFailure("QODER_NOT_ENABLED")
        try:
            _source(task, context)
            value = self.metadata()
            metadata = QoderMetadata(
                deepcopy(value.snapshot), value.account_scope, value.ds_free_remaining
            )
            if not re.fullmatch(r"[0-9a-f]{64}", metadata.account_scope):
                raise ModelFailure("QODER_ACCOUNT_UNVERIFIED")
            self.account_preflight(metadata.account_scope)
            selected = select_free_model(
                metadata.snapshot, self.clock(), ds_free_remaining=metadata.ds_free_remaining
            )
            if selected is None:
                raise ModelFailure("QODER_FREE_STATE_UNVERIFIED")
            return PreparedQoderCall(
                metadata,
                selected,
                UUID(str(task["owner_id"])),
                UUID(str(task["id"])),
                UUID(str(task["run_id"])),
                UUID(str(context["message"]["id"])),
                self._issuer,
            )
        except (ModelFailure, BusinessError):
            raise
        except Exception:
            raise ModelFailure("QODER_PREFLIGHT_UNVERIFIED") from None

    def execute(
        self, task: Row, context: Row, *, prepared: PreparedQoderCall | None = None
    ) -> ModelResult:
        if self.enabled is not True:
            raise ModelFailure("QODER_NOT_ENABLED")
        dispatch: UUID | None = None
        dispatch_attempted = False
        runner_entered = False
        try:
            content, kind = _source(task, context)
            if "reading_qa" in context and not self.settings.reading_enabled:
                raise ModelFailure("READING_QA_UNAVAILABLE")
            prepared = prepared or self.prepare(task, context)
            expected = (
                UUID(str(task["owner_id"])),
                UUID(str(task["id"])),
                UUID(str(task["run_id"])),
                UUID(str(context["message"]["id"])),
            )
            if prepared._issuer is not self._issuer or expected != (
                prepared.owner_id,
                prepared.task_id,
                prepared.run_id,
                prepared.source_id,
            ):
                raise ModelFailure("QODER_PREPARATION_INVALID")
            metadata, selected = prepared.metadata, prepared.selected
            now = self.clock()
            current_selection = select_free_model(
                metadata.snapshot, now, ds_free_remaining=metadata.ds_free_remaining
            )
            if current_selection != selected:
                raise ModelFailure("QODER_FREE_STATE_EXPIRED")
            payload = request_payload(context, self.settings)
            prompt = json.dumps(
                {
                    "messages": payload["input"],
                    "response_schema": payload["text"]["format"]["schema"],
                    "instruction": "只输出符合response_schema的JSON对象，不调用工具。",
                },
                ensure_ascii=False,
            )
            invocation = build_invocation(
                now=now,
                ds_free_available=selected == "dfmodel",
                qwen_free_verified=selected == "qfmodel",
                prompt=prompt,
                node=self.paths.node,
                cli=self.paths.cli,
                cwd=self.paths.cwd,
                config_dir=self.paths.config_dir,
                platform=self.paths.platform,
            )
            dispatch_attempted = True
            dispatch = begin_dispatch(
                self.engine,
                task["owner_id"],
                task["id"],
                task["run_id"],
                expected_model=cli_model_name(selected),
                account_scope=metadata.account_scope,
                allow_reported_free=self.settings.qoder_continue_reported_free,
            )
            # Database locks may have waited. Recheck snapshot age and consent
            # without reusing an expired or differently selected authorization.
            self.account_preflight(metadata.account_scope)
            revalidate_dispatch(
                self.engine,
                task["owner_id"],
                dispatch,
                task["id"],
                task["run_id"],
                account_scope=metadata.account_scope,
                expected_model=cli_model_name(selected),
                source_id=UUID(str(context["message"]["id"])),
                source_content=content,
                source_kind=kind,
                reading_context=context.get("reading_qa"),
                allow_reported_free=self.settings.qoder_continue_reported_free,
            )
            if (
                select_free_model(
                    metadata.snapshot, self.clock(), ds_free_remaining=metadata.ds_free_remaining
                )
                != selected
            ):
                raise ModelFailure("QODER_FREE_STATE_EXPIRED")
            runner_entered = True
            raw = self.runner(invocation)
            return parse_result(
                raw,
                expected_model=cli_model_name(selected),
                source_content=content,
                source_kind=kind,
            ).reply
        except Exception as error:
            if dispatch is not None:
                try:
                    mark_unknown(self.engine, task["owner_id"], dispatch)
                except Exception:
                    raise ModelFailure("QODER_OUTCOME_RECORDING_FAILED", uncertain=True) from None
            if isinstance(error, BusinessError) and not runner_entered:
                raise
            if isinstance(error, ModelFailure):
                raise ModelFailure(
                    error.code, uncertain=runner_entered or error.uncertain
                ) from None
            raise ModelFailure(
                "QODER_EXECUTION_UNVERIFIED", uncertain=dispatch_attempted or runner_entered
            ) from None
