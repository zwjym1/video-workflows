"""Durable dispatch guard. Does not authorize billing, start a process or settle usage."""

import re
from datetime import UTC, datetime
from typing import Literal
from uuid import UUID, uuid4

from sqlalchemy import Connection, Engine

from app.activity_plan_sources import claim_daily_allowance, load_candidates
from app.errors import BusinessError
from app.repository import Row, execute, one


def _account_key(account_scope: str) -> int:
    if not isinstance(account_scope, str) or re.fullmatch(r"[0-9a-f]{64}", account_scope) is None:
        raise ValueError("Invalid trusted account fingerprint")
    value = int(account_scope[:16], 16)
    return value - (1 << 64) if value >= 1 << 63 else value


def _unresolved_dispatch(
    conn: Connection,
    account_scope: str,
    *,
    allow_reported_free: bool,
    exclude: UUID | None = None,
) -> Row | None:
    # A zero receipt permits bounded continuation only. It does not verify the
    # bill, change unknown accounting, or release any reserved budget.
    return one(
        conn,
        """SELECT d.id FROM provider_dispatches d
        WHERE d.account_scope IN (:scope,'unverified')
        AND (CAST(:exclude AS uuid) IS NULL OR d.id<>CAST(:exclude AS uuid))
        AND d.status IN ('started','unknown')
        AND (d.account_scope='unverified' OR (
            NOT EXISTS (SELECT 1 FROM qoder_settlements s
                WHERE s.dispatch_id=d.id AND s.owner_id=d.owner_id
                AND s.reservation_id=d.reservation_id)
            AND NOT (:allow_free AND d.status='unknown' AND d.provider='qoder'
                AND EXISTS (
                    SELECT 1 FROM qoder_usage_reports report
                    JOIN budget_reservations b ON b.id=d.reservation_id
                        AND b.run_id=d.run_id AND b.owner_id=d.owner_id
                    JOIN model_usage_logs u ON u.reservation_id=b.id
                        AND u.run_id=d.run_id AND u.owner_id=d.owner_id
                        AND u.character_id=d.character_id
                    JOIN tasks t ON t.id=d.task_id AND t.owner_id=d.owner_id
                        AND t.character_id=d.character_id
                    JOIN task_runs r ON r.id=d.run_id AND r.task_id=t.id
                        AND r.owner_id=d.owner_id AND r.character_id=d.character_id
                    WHERE report.dispatch_id=d.id AND report.reservation_id=b.id
                        AND report.owner_id=d.owner_id AND report.provider_model=d.model
                        AND report.reported_cost_usd=0 AND report.reported_credits=0
                        AND t.status='succeeded' AND r.status='succeeded'
                        AND b.status='unknown' AND u.status='unknown'
                        AND u.provider=d.provider AND u.model=d.model)
                AND NOT EXISTS (SELECT 1 FROM qoder_usage_reports conflict
                    WHERE (conflict.dispatch_id=d.id OR conflict.reservation_id=d.reservation_id)
                    AND (conflict.reported_cost_usd<>0 OR conflict.reported_credits<>0))
            )
        )) LIMIT 1""",
        {"scope": account_scope, "exclude": exclude, "allow_free": allow_reported_free},
    )


def begin_dispatch(
    engine: Engine,
    owner: UUID,
    task_id: UUID,
    run_id: UUID,
    *,
    expected_model: str,
    account_scope: str,
    allow_reported_free: bool = False,
    expected_kind: Literal["chat_reply", "activity_plan"] = "chat_reply",
) -> UUID:
    """Commit BEFORE starting a provider process. A returned ID is consumed once.

    No API supplies these arguments. Free status, user consent, prior account-wide
    unresolved calls and billing policy still require independent checks. This
    function alone is never permission to send. The scope is a trusted backend
    account fingerprint, never API/model data. Started/unknown records block that
    account across owners; legacy unverified records conservatively block all.
    Explicit zero-receipt continuation leaves accounting and budget holds unknown.
    """
    if expected_kind not in ("chat_reply", "activity_plan"):
        raise ValueError("Invalid trusted task kind")
    if expected_model not in ("DeepSeek-Flash", "Qwen3.8-Flash"):
        raise ValueError("Invalid selected model")
    advisory_key = _account_key(account_scope)
    p = {"o": owner, "t": task_id, "r": run_id, "m": expected_model, "scope": account_scope}
    with engine.begin() as conn:
        # Account serialization precedes all owner/state locks. Hash-prefix
        # collisions only serialize independent accounts; the full scope below
        # still determines which unresolved evidence blocks a request.
        execute(conn, "SELECT pg_advisory_xact_lock(:key)", {"key": advisory_key})
        candidate = one(conn, "SELECT character_id FROM tasks WHERE owner_id=:o AND id=:t", p)
        if not candidate:
            raise BusinessError("QODER_TASK_INVALID", "没有可执行的所属任务", 409)
        character = candidate["character_id"]
        p["c"] = character
        # Match user-level stop operations: owner before character state.
        user = one(conn, "SELECT disabled FROM users WHERE id=:o FOR UPDATE", p)
        state = one(
            conn,
            """SELECT memory_epoch FROM character_states
            WHERE owner_id=:o AND character_id=:c FOR UPDATE""",
            p,
        )
        task = one(
            conn,
            """SELECT t.*,r.memory_epoch AS run_epoch,r.status AS run_status,
            r.fencing_token AS run_fence FROM tasks t JOIN task_runs r
            ON r.task_id=t.id AND r.owner_id=t.owner_id AND r.character_id=t.character_id
            JOIN characters c ON c.id=t.character_id AND c.owner_id=t.owner_id
            WHERE t.id=:t AND t.owner_id=:o AND r.id=:r AND c.enabled
            AND t.lease_until>clock_timestamp() FOR UPDATE OF t,r""",
            p,
        )
        if (
            not state
            or not user
            or user["disabled"]
            or not task
            or task["kind"] != expected_kind
            or task["status"] != "running"
            or task["run_status"] != "running"
            or task["cancel_requested"]
            or task["fencing_token"] != task["run_fence"]
            or state["memory_epoch"] != task["run_epoch"]
        ):
            raise BusinessError("QODER_TASK_INVALID", "任务已停止、过期或上下文已变化", 409)
        existing = one(conn, "SELECT id FROM provider_dispatches WHERE task_id=:t", p)
        if existing:
            raise BusinessError("QODER_DISPATCH_EXISTS", "本请求已消耗调用许可，禁止重发", 409)
        held = one(
            conn,
            """SELECT b.id FROM budget_reservations b JOIN model_usage_logs u
            ON u.reservation_id=b.id AND u.run_id=b.run_id AND u.owner_id=b.owner_id
            WHERE b.run_id=:r AND b.owner_id=:o AND b.status='held'
            AND u.character_id=:c AND u.provider='qoder' AND u.model=:m
            AND u.status='reserved' FOR UPDATE OF b,u""",
            p,
        )
        if not held:
            raise BusinessError("QODER_RESERVATION_REQUIRED", "缺少匹配的有效费用预留", 409)
        unresolved = _unresolved_dispatch(
            conn,
            account_scope,
            allow_reported_free=allow_reported_free,
        )
        if unresolved:
            raise BusinessError("QODER_UNRESOLVED_DISPATCH", "存在未核对调用，禁止自动继续", 409)
        if expected_kind == "activity_plan":
            load_candidates(conn, owner, character, task_id)
            claim_daily_allowance(conn, owner, character, datetime.now(UTC))
        elif "reading_qa" in task["input"]:
            from app.reading_qa import load_source

            load_source(conn, task)
        # Reservation locks may also wait. Do not reuse the transaction's start
        # time or the earlier lease check after waiting for those locks.
        valid = one(
            conn,
            """SELECT id FROM tasks WHERE owner_id=:o AND id=:t
            AND lease_until>clock_timestamp()""",
            p,
        )
        if not valid:
            raise BusinessError("QODER_TASK_INVALID", "任务租约已到期，未创建调用记录", 409)
        identity = uuid4()
        execute(
            conn,
            """INSERT INTO provider_dispatches(id,owner_id,character_id,task_id,
            run_id,reservation_id,provider,model,status,account_scope)
            VALUES (:id,:o,:c,:t,:r,:b,'qoder',:m,'started',:scope)""",
            {**p, "id": identity, "b": held["id"]},
        )
    return identity


def revalidate_dispatch(
    engine: Engine,
    owner: UUID,
    identity: UUID,
    task_id: UUID,
    run_id: UUID,
    *,
    account_scope: str,
    expected_model: str,
    source_id: UUID | None = None,
    source_content: str = "",
    source_kind: str = "",
    reading_context: Row | None = None,
    allow_reported_free: bool = False,
    expected_kind: Literal["chat_reply", "activity_plan"] = "chat_reply",
) -> None:
    """Final bounded check after waiting preflights, without issuing a new permit."""
    if expected_kind not in ("chat_reply", "activity_plan"):
        raise ValueError("Invalid trusted task kind")
    if expected_model not in ("DeepSeek-Flash", "Qwen3.8-Flash"):
        raise ValueError("Invalid selected model")
    if expected_kind == "activity_plan" and (source_id or source_content or source_kind):
        raise ValueError("Planning dispatch cannot use a chat source")
    p = {
        "o": owner,
        "id": identity,
        "t": task_id,
        "r": run_id,
        "scope": account_scope,
        "model": expected_model,
        "source": source_id,
        "kind": expected_kind,
    }
    with engine.begin() as conn:
        execute(conn, "SELECT pg_advisory_xact_lock(:key)", {"key": _account_key(account_scope)})
        candidate = one(conn, "SELECT character_id FROM tasks WHERE owner_id=:o AND id=:t", p)
        if not candidate:
            raise BusinessError("QODER_TASK_INVALID", "任务不存在", 409)
        character = candidate["character_id"]
        p["c"] = character
        user = one(conn, "SELECT disabled,autonomy_paused FROM users WHERE id=:o FOR UPDATE", p)
        state = one(
            conn,
            """SELECT memory_epoch,mode FROM character_states
            WHERE owner_id=:o AND character_id=:c FOR UPDATE""",
            p,
        )
        if (
            not user
            or user["disabled"]
            or (expected_kind == "activity_plan" and user["autonomy_paused"])
            or not state
            or state["mode"] == "deleting"
        ):
            raise BusinessError("QODER_TASK_INVALID", "用户或角色状态已变化", 409)
        task = one(
            conn,
            """SELECT t.input FROM tasks t JOIN task_runs r
            ON r.task_id=t.id AND r.owner_id=t.owner_id AND r.character_id=t.character_id
            JOIN characters c ON c.id=t.character_id AND c.owner_id=t.owner_id
            WHERE t.id=:t AND t.owner_id=:o AND r.id=:r AND c.enabled
            AND t.kind=:kind AND t.status='running' AND r.status='running'
            AND NOT t.cancel_requested AND t.fencing_token=r.fencing_token
            AND r.memory_epoch=:epoch AND t.lease_until>clock_timestamp()
            FOR UPDATE OF t,r""",
            {**p, "epoch": state["memory_epoch"]},
        )
        if not task or (
            expected_kind == "chat_reply"
            and (source_id is None or task["input"].get("message_id") != str(source_id))
        ):
            raise BusinessError("QODER_TASK_INVALID", "任务或上下文已失效", 409)
        held = one(
            conn,
            """SELECT b.id FROM budget_reservations b JOIN model_usage_logs u
            ON u.reservation_id=b.id AND u.run_id=b.run_id AND u.owner_id=b.owner_id
            WHERE b.run_id=:r AND b.owner_id=:o AND b.status='held'
            AND u.character_id=:c AND u.provider='qoder' AND u.model=:model
            AND u.status='reserved' FOR UPDATE OF b,u""",
            p,
        )
        dispatch = one(
            conn,
            """SELECT reservation_id FROM provider_dispatches
            WHERE id=:id AND owner_id=:o AND character_id=:c AND task_id=:t AND run_id=:r
            AND account_scope=:scope AND model=:model AND status='started' FOR UPDATE""",
            p,
        )
        source_valid = False
        if expected_kind == "chat_reply":
            if "reading_qa" in task["input"]:
                from app.reading_qa import load_source

                reading = load_source(
                    conn, {"input": task["input"], "owner_id": owner, "character_id": character}
                )
                if reading_context != {
                    "book_id": str(reading["book_id"]),
                    "ordinal": reading["ordinal"],
                    "source_hash": reading["source_hash"],
                    "content": reading["content"],
                }:
                    raise BusinessError("READING_QA_INVALID", "发送前原文快照已变化", 409)
            source = one(
                conn,
                """SELECT content,content_kind FROM messages WHERE id=:source
                AND owner_id=:o AND character_id=:c AND role='user' AND status='completed'""",
                p,
            )
            source_valid = bool(
                source
                and source["content"] == source_content
                and source["content_kind"] == source_kind
            )
        else:
            # Recheck consent and the exact persisted selection, but do not
            # charge another daily attempt or reject this already issued quota.
            prefs = one(
                conn,
                """SELECT enabled,quiet_until FROM activity_planning_preferences
                WHERE owner_id=:o AND character_id=:c FOR UPDATE""",
                p,
            )
            if (
                not prefs
                or not prefs["enabled"]
                or (prefs["quiet_until"] and prefs["quiet_until"] > datetime.now(UTC))
            ):
                raise BusinessError("ACTIVITY_PLAN_UNAVAILABLE", "规划许可已失效", 409)
            load_candidates(conn, owner, character, task_id)
            source_valid = True
        other = _unresolved_dispatch(
            conn,
            account_scope,
            allow_reported_free=allow_reported_free,
            exclude=identity,
        )
        due = one(
            conn,
            """SELECT id FROM memory_items WHERE owner_id=:o AND character_id=:c
            AND status IN ('active','disputed') AND deleted_at IS NULL
            AND (expires_at<=clock_timestamp() OR valid_until<=clock_timestamp()) LIMIT 1""",
            p,
        )
        lease = one(conn, "SELECT id FROM tasks WHERE id=:t AND lease_until>clock_timestamp()", p)
        if (
            not held
            or not dispatch
            or dispatch["reservation_id"] != held["id"]
            or not source_valid
            or other
            or due
            or not lease
        ):
            raise BusinessError("QODER_TASK_INVALID", "发送前记录、来源或费用预留已失效", 409)
        # Metadata setup can consume most of the original claim lease. Only a
        # still-valid, fenced run receives one bounded send/persist window.
        renewed = one(
            conn,
            """UPDATE tasks SET lease_until=clock_timestamp()+interval '60 seconds'
            WHERE owner_id=:o AND id=:t AND status='running' AND NOT cancel_requested
            AND lease_until>clock_timestamp() RETURNING id""",
            p,
        )
        if not renewed:
            raise BusinessError("QODER_TASK_INVALID", "任务租约已到期，未开始调用", 409)
        execute(conn, "UPDATE task_runs SET heartbeat_at=clock_timestamp() WHERE id=:r", p)


def mark_unknown(engine: Engine, owner: UUID, identity: UUID) -> None:
    """Monotonic, idempotent evidence update; never reopens or releases a call."""
    with engine.begin() as conn:
        p = {"o": owner, "id": identity}
        item = one(
            conn,
            """SELECT id FROM provider_dispatches
            WHERE owner_id=:o AND id=:id FOR UPDATE""",
            p,
        )
        if not item:
            raise BusinessError("QODER_DISPATCH_NOT_FOUND", "调用记录不存在", 404)
        execute(
            conn,
            """UPDATE provider_dispatches SET status='unknown',finished_at=now()
            WHERE owner_id=:o AND id=:id AND status='started'""",
            p,
        )
