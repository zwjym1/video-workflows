"""Explicit-title topic suggestions from verified completed local reading only."""

import hashlib
import json
import re
from uuid import UUID

from sqlalchemy import Connection, Engine

from app.config import Settings
from app.errors import BusinessError
from app.life_service import check_version, owned
from app.memory import assert_character
from app.reading_service import read_snapshot, verified
from app.repository import Row, one, rows

CONSENT = "确认添加这项兴趣"
REASON = "两份已处理资料具有相同显式主题；这不代表角色一定喜欢"


def explicit_topics(title: str) -> list[str]:
    found: list[str] = []
    seen: set[str] = set()
    # Match the whole word before applying length bounds, never a 20-char prefix.
    for match in re.finditer(r"(?<!\w)#(\w+)", title, re.UNICODE):
        topic = match.group(1)
        folded = topic.casefold()
        if 2 <= len(topic) <= 20 and folded not in seen:
            seen.add(folded)
            found.append(topic)
            if len(found) == 3:
                break
    return found


def _items(conn: Connection, owner: UUID, character: UUID, interests: list[str]) -> list[Row]:
    books = rows(
        conn,
        """SELECT * FROM books WHERE owner_id=:o AND character_id=:c
        AND status='completed' ORDER BY created_at,id LIMIT 20""",
        {"o": owner, "c": character},
    )
    existing = {value.casefold() for value in interests}
    topics: dict[str, Row] = {}
    for book in books:
        try:
            verified(conn, book)
        except BusinessError:
            continue
        for topic in explicit_topics(book["title"]):
            key = topic.casefold()
            if key in existing:
                continue
            candidate = topics.setdefault(key, {"topic": topic, "reason": REASON, "evidence": []})
            candidate["evidence"].append(
                {"book_id": book["id"], "title": book["title"], "source_hash": book["source_hash"]}
            )
    candidates = []
    for candidate in topics.values():
        if len(candidate["evidence"]) < 2:
            continue
        source = {
            "topic": candidate["topic"],
            "books": sorted(
                (str(item["book_id"]), item["source_hash"]) for item in candidate["evidence"]
            ),
        }
        candidate["source_digest"] = hashlib.sha256(
            json.dumps(source, ensure_ascii=True, sort_keys=True, separators=(",", ":")).encode()
        ).hexdigest()
        candidates.append(candidate)
    candidates.sort(key=lambda item: (-len(item["evidence"]), item["topic"].casefold()))
    return candidates[:3]


def suggestions(engine: Engine, settings: Settings, owner: UUID, character: UUID) -> Row:
    with read_snapshot(engine) as conn:
        state = assert_character(conn, owner, character)
        current = owned(conn, "characters", owner, character)
        return {
            "items": _items(conn, owner, character, state["interests"])
            if settings.reading_enabled
            else [],
            "character_version": current["version"],
            "method": "local_explicit_tags",
            "cloud_processing": False,
            "capability_enabled": settings.reading_enabled,
        }


def accept(
    engine: Engine,
    settings: Settings,
    owner: UUID,
    character: UUID,
    topic: str,
    source_digest: str,
    expected_version: int,
    acknowledgement: str,
) -> Row:
    if not settings.reading_enabled:
        raise BusinessError("READING_UNAVAILABLE", "当前服务尚未开放本地阅读", 409)
    if acknowledgement != CONSENT:
        raise BusinessError("INTEREST_CONSENT_REQUIRED", "请确认本次兴趣修改", 422)
    with engine.begin() as conn:
        user = one(conn, "SELECT disabled FROM users WHERE id=:o FOR UPDATE", {"o": owner})
        state = assert_character(conn, owner, character, lock=True)
        current = owned(conn, "characters", owner, character, lock=True)
        if not user or user["disabled"] or not state["enabled"] or state["mode"] == "deleting":
            raise BusinessError("CHARACTER_UNAVAILABLE", "角色当前不可用", 409)
        check_version(current, str(expected_version))
        candidates = _items(conn, owner, character, current["interests"])
        if not any(
            item["topic"] == topic and item["source_digest"] == source_digest for item in candidates
        ):
            raise BusinessError("INTEREST_SOURCE_CHANGED", "建议来源已变化，请刷新", 409)
        if len(current["interests"]) >= 20:
            raise BusinessError("INTEREST_LIMIT", "最多保留20项兴趣，请先整理", 409)
        result = one(
            conn,
            """UPDATE characters SET interests=CAST(:i AS jsonb),version=version+1,
            persona_version=persona_version+1,updated_at=now() WHERE id=:c RETURNING *""",
            {"i": json.dumps([*current["interests"], topic], ensure_ascii=False), "c": character},
        )
        assert result
        return result
