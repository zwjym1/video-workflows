import hashlib
import json
from uuid import UUID, uuid4

from sqlalchemy import Connection, Engine

from app.errors import BusinessError
from app.life_service import check_version, owned
from app.memory import assert_character, extract_claims, memory_view
from app.repository import Row, execute, one, rows


def revision_family(conn: Connection, owner: UUID, character: UUID, ids: set[UUID]) -> set[UUID]:
    family = rows(
        conn,
        """SELECT id,supersedes_id FROM memory_items WHERE owner_id=:o AND character_id=:c
        AND (id=ANY(:ids) OR supersedes_id=ANY(:ids))""",
        {"o": owner, "c": character, "ids": list(ids)},
    )
    expanded = ids | {x["id"] for x in family}
    expanded.update(x["supersedes_id"] for x in family if x["supersedes_id"])
    # A user correction may replace two predicates; retain every replacement edge.
    corrections = rows(
        conn,
        """SELECT payload FROM experience_events WHERE owner_id=:o AND character_id=:c
        AND event_type='memory_corrected'""",
        {"o": owner, "c": character},
    )
    for event in corrections:
        payload = event["payload"]
        if not payload.get("memory_id"):
            continue
        edge = {UUID(payload["memory_id"])}
        edge.update(UUID(x) for x in payload.get("replaces_memory_ids", []))
        if edge & expanded:
            expanded.update(edge)
    return expanded


def correct_memory(
    engine: Engine, owner: UUID, memory_id: UUID, content: str, reason: str, expected: str | None
) -> Row:
    with engine.begin() as conn:
        old = owned(conn, "memory_items", owner, memory_id)
        state = assert_character(conn, owner, old["character_id"], lock=True)
        old = owned(conn, "memory_items", owner, memory_id, lock=True)
        check_version(old, expected)
        if old["status"] == "deleted":
            raise BusinessError("DELETED", "记忆已删除", 409)
        parsed = extract_claims(content)
        predicate = parsed[0].predicate if len(parsed) == 1 else old["predicate"]
        value = parsed[0].value if len(parsed) == 1 else content
        replaced = rows(
            conn,
            """SELECT id FROM memory_items WHERE owner_id=:o AND character_id=:c
            AND (id=:id OR (status IN ('active','disputed') AND
            (predicate IS NOT DISTINCT FROM :old OR predicate IS NOT DISTINCT FROM :new)))""",
            {
                "o": owner,
                "c": old["character_id"],
                "id": memory_id,
                "old": old["predicate"],
                "new": predicate,
            },
        )
        replaced_ids = [x["id"] for x in replaced]
        # Correction also invalidates in-flight contexts using the old fact.
        execute(
            conn,
            """UPDATE character_states SET memory_epoch=memory_epoch+1,
            state_version=state_version+1 WHERE character_id=:c""",
            {"c": old["character_id"]},
        )
        execute(
            conn,
            """UPDATE tasks SET status='cancelled',cancel_requested=true,
            fencing_token=fencing_token+1 WHERE owner_id=:o AND character_id=:c
            AND status IN ('queued','retry_wait','running')""",
            {"o": owner, "c": old["character_id"]},
        )
        execute(
            conn,
            """UPDATE task_runs SET status='cancelled',finished_at=now(),
            error_code='CONTEXT_CORRECTED' WHERE owner_id=:o AND character_id=:c AND
            status='running'""",
            {"o": owner, "c": old["character_id"]},
        )
        execute(
            conn,
            """UPDATE memory_items SET status='superseded',version=version+1,
            updated_at=now() WHERE owner_id=:o AND id=ANY(:ids)
            AND status IN ('active','disputed')""",
            {"o": owner, "ids": replaced_ids},
        )
        event_id, new_id = uuid4(), uuid4()
        execute(
            conn,
            """INSERT INTO experience_events(id,owner_id,character_id,event_type,
            reality_class,dedupe_key,payload) VALUES (:id,:o,:c,'memory_corrected','user_claim',
            :key,CAST(:payload AS jsonb))""",
            {
                "id": event_id,
                "o": owner,
                "c": old["character_id"],
                "key": "correction:" + str(event_id),
                "payload": json.dumps(
                    {
                        "content": content,
                        "reason": reason,
                        "memory_id": str(new_id),
                        "replaces_memory_ids": [str(x) for x in replaced_ids],
                    }
                ),
            },
        )
        result = one(
            conn,
            """INSERT INTO memory_items(id,owner_id,character_id,content,predicate,
            object_value,status,supersedes_id) VALUES (:id,:o,:c,:text,:p,CAST(:value AS jsonb),
            'active',:old) RETURNING *""",
            {
                "id": new_id,
                "o": owner,
                "c": old["character_id"],
                "text": content,
                "p": predicate,
                "value": json.dumps(value),
                "old": memory_id,
            },
        )
        execute(
            conn,
            """INSERT INTO memory_sources(id,owner_id,character_id,memory_id,event_id,
            quote,source_hash) VALUES (:id,:o,:c,:m,:e,:q,:h)""",
            {
                "id": uuid4(),
                "o": owner,
                "c": old["character_id"],
                "m": new_id,
                "e": event_id,
                "q": content,
                "h": hashlib.sha256(content.encode()).hexdigest(),
            },
        )
        # Stop summaries contradicting the correction; original messages remain inspectable.
        execute(
            conn,
            "UPDATE conversations SET summary=NULL,summary_epoch=:epoch WHERE character_id=:c",
            {"epoch": state["memory_epoch"] + 1, "c": old["character_id"]},
        )
        assert result
        return memory_view(conn, result)


def delete_memory(engine: Engine, owner: UUID, memory_id: UUID, scope: str) -> Row:
    with engine.begin() as conn:
        target = owned(conn, "memory_items", owner, memory_id)
        if target["status"] == "deleted":
            raise BusinessError("NOT_FOUND", "记忆已删除", 404)
        state = assert_character(conn, owner, target["character_id"], lock=True)
        character = target["character_id"]
        deletion_id = uuid4()
        epoch = state["memory_epoch"] + 1
        execute(
            conn,
            """UPDATE character_states SET mode='deleting',memory_epoch=:epoch,
            state_version=state_version+1 WHERE character_id=:c""",
            {"epoch": epoch, "c": character},
        )
        execute(
            conn,
            """INSERT INTO deletion_requests(id,owner_id,character_id,status,epoch)
            VALUES (:id,:o,:c,'running',:e)""",
            {"id": deletion_id, "o": owner, "c": character, "e": epoch},
        )
        memories = rows(
            conn,
            """SELECT id FROM memory_items WHERE owner_id=:o AND character_id=:c
            AND (id=:id OR (predicate IS NOT NULL AND predicate=:p))""",
            {"o": owner, "c": character, "id": memory_id, "p": target["predicate"]},
        )
        ids = {x["id"] for x in memories}
        # Correction ancestry can change predicate; follow both directions before source closure.
        while True:
            next_ids = revision_family(conn, owner, character, ids)
            if next_ids == ids:
                break
            ids = next_ids
        source_messages: set[UUID] = set()
        source_events: set[UUID] = set()
        if scope == "memory_and_sources":
            # A source can contain several facts; remove all its memory projections together.
            while True:
                previous_ids = set(ids)
                ids = revision_family(conn, owner, character, ids)
                sources = rows(
                    conn,
                    "SELECT message_id,event_id FROM memory_sources WHERE memory_id=ANY(:ids)",
                    {"ids": list(ids)},
                )
                source_messages.update(x["message_id"] for x in sources if x["message_id"])
                source_events.update(x["event_id"] for x in sources if x["event_id"])
                linked = rows(
                    conn,
                    """SELECT memory_id FROM memory_sources WHERE owner_id=:o
                    AND (message_id=ANY(:msgs) OR event_id=ANY(:events))""",
                    {"o": owner, "msgs": list(source_messages), "events": list(source_events)},
                )
                ids.update(x["memory_id"] for x in linked)
                if ids == previous_ids:
                    break
            dependent = rows(
                conn,
                "SELECT message_id FROM message_memory_links WHERE memory_id=ANY(:ids)",
                {"ids": list(ids)},
            )
            messages = source_messages | {x["message_id"] for x in dependent}
            # Also redact direct replies to the original message even if no old memory existed yet.
            direct = rows(
                conn,
                "SELECT id FROM messages WHERE owner_id=:o AND in_reply_to=ANY(:ids)",
                {"o": owner, "ids": list(source_messages)},
            )
            messages.update(x["id"] for x in direct)
            if messages:
                execute(
                    conn,
                    """UPDATE messages SET content='[用户已删除相关内容]',status='deleted',
                    version=version+1 WHERE owner_id=:o AND id=ANY(:ids)""",
                    {"o": owner, "ids": list(messages)},
                )
            if source_events:
                execute(
                    conn,
                    "UPDATE experience_events SET payload='{}' WHERE owner_id=:o AND id=ANY(:ids)",
                    {"o": owner, "ids": list(source_events)},
                )
        execute(
            conn,
            "DELETE FROM message_memory_links WHERE owner_id=:o AND memory_id=ANY(:ids)",
            {"o": owner, "ids": list(ids)},
        )
        execute(
            conn,
            "DELETE FROM memory_sources WHERE owner_id=:o AND memory_id=ANY(:ids)",
            {"o": owner, "ids": list(ids)},
        )
        execute(
            conn,
            """UPDATE memory_items SET content='',object_value=NULL,predicate=NULL,
            embedding=NULL,embedding_model=NULL,tags='{}',status='deleted',deleted_at=now(),
            version=version+1,updated_at=now() WHERE owner_id=:o AND id=ANY(:ids)""",
            {"o": owner, "ids": list(ids)},
        )
        execute(
            conn,
            """UPDATE tasks SET status='cancelled',cancel_requested=true,input='{}',
            fencing_token=fencing_token+1,error_code='CONTEXT_DELETED'
            WHERE owner_id=:o AND character_id=:c
            AND status IN ('queued','retry_wait','running')""",
            {"o": owner, "c": character},
        )
        execute(
            conn,
            """UPDATE task_runs SET status='cancelled',finished_at=now(),
            error_code='CONTEXT_DELETED' WHERE owner_id=:o AND character_id=:c AND
            status='running'""",
            {"o": owner, "c": character},
        )
        execute(
            conn,
            "UPDATE conversations SET summary=NULL,summary_epoch=:e WHERE character_id=:c",
            {"e": epoch, "c": character},
        )
        report = {"memories": len(ids), "source_messages": len(source_messages), "scope": scope}
        execute(
            conn,
            """UPDATE deletion_requests SET status='completed',completed_at=now(),
            report=CAST(:report AS jsonb) WHERE id=:id""",
            {"report": json.dumps(report), "id": deletion_id},
        )
        execute(
            conn, "UPDATE character_states SET mode='idle' WHERE character_id=:c", {"c": character}
        )
        return {
            "deletion_request_id": deletion_id,
            "status": "completed",
            "report": report,
            "warning": (
                "原始聊天仍保留，可能再次进入对话上下文" if scope == "memory_only" else None
            ),
        }
