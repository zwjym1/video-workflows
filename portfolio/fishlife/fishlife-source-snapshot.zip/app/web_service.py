"""Persistent explicit read requests; untrusted documents never become agent instructions."""

import hashlib
from datetime import UTC, datetime
from uuid import UUID, uuid4

from sqlalchemy import Connection, Engine

from app import safe_web
from app.errors import BusinessError
from app.life_service import owned
from app.memory import assert_character
from app.repository import Row, execute, one, rows


def policy(conn: Connection, owner: UUID, character: UUID, lock: bool = False) -> Row:
    assert_character(conn, owner, character)
    execute(
        conn,
        "INSERT INTO web_policies(owner_id,character_id) VALUES (:o,:c) "
        "ON CONFLICT(character_id) DO NOTHING",
        {"o": owner, "c": character},
    )
    result = one(
        conn,
        "SELECT * FROM web_policies WHERE owner_id=:o AND character_id=:c"
        + (" FOR UPDATE" if lock else ""),
        {"o": owner, "c": character},
    )
    assert result
    return result


def expire_running(conn: Connection, owner: UUID) -> None:
    execute(
        conn,
        """UPDATE web_documents SET status='unknown',error_code='WEB_INTERRUPTED'
        WHERE id IN (SELECT id FROM web_documents WHERE owner_id=:o AND status='running'
        AND created_at<now()-interval '5 minutes' ORDER BY created_at LIMIT 20)""",
        {"o": owner},
    )


def import_document(engine: Engine, owner: UUID, character: UUID, url: str, key: UUID) -> Row:
    fingerprint = hashlib.sha256(url.encode()).hexdigest()
    with engine.begin() as conn:
        # Owner lock makes the 20/day quota atomic across all characters.
        one(conn, "SELECT id FROM users WHERE id=:o FOR UPDATE", {"o": owner})
        state = assert_character(conn, owner, character, lock=True)
        expire_running(conn, owner)
        old = one(
            conn,
            "SELECT * FROM web_documents WHERE owner_id=:o AND request_key=:k",
            {"o": owner, "k": key},
        )
        if old:
            if old["request_hash"] != fingerprint or old["character_id"] != character:
                raise BusinessError("IDEMPOTENCY_CONFLICT", "请求标识已绑定其他网页参数", 409)
            return old
        current = policy(conn, owner, character, lock=True)
        if not state["tools_enabled"] or not current["enabled"]:
            raise BusinessError("WEB_DISABLED", "请明确启用该角色网页白名单及工具权限", 409)
        domains = set(current["allowed_domains"])
        safe_web.validate_url(url, domains)
        usage = one(
            conn,
            """SELECT count(*) AS total FROM web_documents WHERE owner_id=:o
            AND created_at >= date_trunc('day',now() AT TIME ZONE 'UTC') AT TIME ZONE 'UTC'""",
            {"o": owner},
        )
        assert usage
        if usage["total"] >= 20:
            raise BusinessError("WEB_DAILY_LIMIT", "今日网页读取次数已达20次上限", 429)
        identity = uuid4()
        version, epoch = current["version"], state["tools_epoch"]
        execute(
            conn,
            """INSERT INTO web_documents(id,owner_id,character_id,request_key,
            request_hash,url,status,policy_version)
            VALUES (:id,:o,:c,:k,:hash,:url,'running',:v)""",
            {
                "id": identity,
                "o": owner,
                "c": character,
                "k": key,
                "hash": fingerprint,
                "url": url,
                "v": version,
            },
        )
    try:
        result = safe_web.fetch_page(url, domains)
    except Exception as exc:
        code = exc.code if isinstance(exc, BusinessError) else "WEB_FETCH_UNKNOWN"
        with engine.begin() as conn:
            assert_character(conn, owner, character, lock=True)
            current_doc = owned(conn, "web_documents", owner, identity, lock=True)
            if current_doc["status"] == "running":
                execute(
                    conn,
                    "UPDATE web_documents SET status='unknown',error_code=:code WHERE id=:id",
                    {"code": code, "id": identity},
                )
        if isinstance(exc, BusinessError):
            raise
        raise BusinessError("WEB_FETCH_UNKNOWN", "网页请求未确认成功，未保存正文", 502) from exc
    with engine.begin() as conn:
        state = assert_character(conn, owner, character, lock=True)
        current = policy(conn, owner, character, lock=True)
        document = owned(conn, "web_documents", owner, identity, lock=True)
        if document["status"] != "running":
            return document
        if (
            not state["tools_enabled"]
            or not current["enabled"]
            or current["version"] != version
            or state["tools_epoch"] != epoch
        ):
            execute(
                conn,
                "UPDATE web_documents SET status='unknown',error_code='WEB_CONTEXT_CHANGED' "
                "WHERE id=:id",
                {"id": identity},
            )
            document.update(status="unknown", error_code="WEB_CONTEXT_CHANGED")
            return document
        safe_web.validate_url(result["final_url"], set(current["allowed_domains"]))
        value = one(
            conn,
            """UPDATE web_documents SET final_url=:final_url,text_content=:text_content,
            text_sha256=:text_sha256,raw_sha256=:raw_sha256,byte_size=:byte_size,
            http_status=:http_status,status='succeeded',fetched_at=:at WHERE id=:id RETURNING *""",
            {**result, "id": identity, "at": datetime.now(UTC)},
        )
        assert value
        return value


def delete_document(engine: Engine, owner: UUID, identity: UUID) -> Row:
    with engine.begin() as conn:
        document = owned(conn, "web_documents", owner, identity)
        assert_character(conn, owner, document["character_id"], lock=True)
        execute(
            conn,
            """UPDATE web_documents SET status='deleted',url='',final_url='',
            text_content='',text_sha256=NULL,raw_sha256=NULL,error_code=NULL WHERE id=:id""",
            {"id": identity},
        )
        return {"status": "deleted"}


def document_list(conn: Connection, owner: UUID, character: UUID) -> list[Row]:
    assert_character(conn, owner, character)
    expire_running(conn, owner)
    return rows(
        conn,
        "SELECT * FROM web_documents WHERE owner_id=:o AND character_id=:c "
        "AND status<>'deleted' ORDER BY created_at DESC LIMIT 100",
        {"o": owner, "c": character},
    )
