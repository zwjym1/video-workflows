"""Queue a bounded, opted-in planning task without dispatching or consuming allowance."""

from collections.abc import Sequence
from datetime import UTC, datetime
from uuid import UUID, uuid4
from zoneinfo import ZoneInfo

from sqlalchemy import Connection

from app.activity_plan_sources import snapshot_candidates
from app.config import Settings
from app.errors import BusinessError
from app.memory import assert_character
from app.repository import Row, execute, one


def maybe_enqueue_plan(
    conn: Connection,
    owner: UUID,
    character: UUID,
    key: str,
    settings: Settings,
    candidates: Sequence[Row],
    schedule: UUID | None = None,
) -> Row | None:
    """Return None only for the local path; an opted-in plan never silently falls back.

    The caller holds the character lock. Reassert it here to serialize standalone
    callers too, without acquiring an owner lock in the opposite lock order.
    """
    if not settings.model_planning_enabled:
        return None
    state = assert_character(conn, owner, character, lock=True)
    params = {"o": owner, "c": character}
    prefs = one(
        conn,
        """SELECT * FROM activity_planning_preferences
        WHERE owner_id=:o AND character_id=:c""",
        params,
    )
    if not prefs or not prefs["enabled"]:
        return None
    if (
        settings.model_provider != "qoder"
        or not settings.allow_real_model_calls
        or not settings.autonomy_enabled
    ):
        raise BusinessError("MODEL_PLANNING_UNAVAILABLE", "当前服务尚未开放模型选择", 409)
    user = one(conn, "SELECT * FROM users WHERE id=:o", params)
    if not user or user["disabled"] or user["autonomy_paused"] or not state["enabled"]:
        raise BusinessError("AUTONOMY_PAUSED", "自主活动尚未授权或已暂停", 409)
    prior = one(
        conn,
        "SELECT id,status FROM tasks WHERE owner_id=:o AND idempotency_key=:k",
        {**params, "k": key},
    )
    if prior:
        return {"task_id": prior["id"], "status": prior["status"]}
    pending = one(
        conn,
        """SELECT id,status FROM tasks WHERE owner_id=:o AND character_id=:c
        AND kind='activity_plan' AND status IN ('queued','retry_wait','running')
        ORDER BY created_at,id LIMIT 1""",
        params,
    )
    if pending:
        return {"task_id": pending["id"], "status": pending["status"]}
    if not candidates:
        return {"task_id": None, "status": "quiet", "reason": "没有可执行的新目标，保持安静"}
    now = datetime.now(UTC)
    if prefs["quiet_until"] and prefs["quiet_until"] > now:
        return {"task_id": None, "status": "quiet", "reason": "模型选择处于静默期"}
    day = now.astimezone(ZoneInfo(user["timezone"])).date()
    if prefs["local_day"] == day and prefs["calls_today"] >= prefs["daily_limit"]:
        return {"task_id": None, "status": "quiet", "reason": "今日模型选择次数已用完"}
    task = uuid4()
    execute(
        conn,
        """INSERT INTO tasks(id,owner_id,character_id,kind,input,status,idempotency_key,
        max_attempts,schedule_id) VALUES (:t,:o,:c,'activity_plan','{}','queued',:k,1,:s)""",
        {**params, "t": task, "k": key, "s": schedule},
    )
    snapshot_candidates(conn, owner, character, task, candidates)
    return {"task_id": task, "status": "queued"}
