"""Flat UUID artifact store. Caller never supplies a filesystem path."""

import hashlib
import os
from pathlib import Path
from uuid import UUID

from app.errors import BusinessError
from app.repository import Row

MAX_BYTES = 100_000


def artifact_path(root: Path, identity: UUID) -> Path:
    if not isinstance(identity, UUID):
        raise BusinessError("ARTIFACT_PATH_DENIED", "产物路径不被允许", 400)
    absolute = root.absolute()
    if any(p.is_symlink() for p in [absolute, *absolute.parents]):
        raise BusinessError("ARTIFACT_PATH_DENIED", "产物目录不能是链接", 409)
    path = absolute / f"{identity}.md"
    if path.is_symlink():
        raise BusinessError("ARTIFACT_PATH_DENIED", "产物不能是链接", 409)
    return path


def write_note(root: Path, identity: UUID, content: str) -> Row:
    path = artifact_path(root, identity)
    data = content.encode("utf-8")
    if not data or len(data) > MAX_BYTES:
        raise BusinessError("ARTIFACT_SIZE", "产物大小不符合限制", 400)
    root.mkdir(parents=True, exist_ok=True)
    # Recheck after directory creation; the directory is only writable by the service account.
    path = artifact_path(root, identity)
    temp = path.with_name(f".{identity}.tmp")
    if temp.is_symlink():
        raise BusinessError("ARTIFACT_PATH_DENIED", "产物临时文件不能是链接", 409)
    try:
        with temp.open("xb") as output:
            output.write(data)
            output.flush()
            os.fsync(output.fileno())
        try:
            # A hard link publishes a complete file atomically and never replaces an existing name.
            os.link(temp, path)
        except FileExistsError as exc:
            raise BusinessError("ARTIFACT_EXISTS", "产物已存在，禁止覆盖", 409) from exc
    finally:
        temp.unlink(missing_ok=True)
    digest = hashlib.sha256(data).hexdigest()
    read_verified(root, identity, digest, len(data))
    return {"sha256": digest, "byte_size": len(data)}


def read_verified(root: Path, identity: UUID, sha256: str, byte_size: int) -> bytes:
    path = artifact_path(root, identity)
    try:
        with path.open("rb") as source:
            data = source.read(MAX_BYTES + 1)
    except OSError as exc:
        raise BusinessError("ARTIFACT_UNAVAILABLE", "产物文件不可读取", 409) from exc
    if len(data) != byte_size or hashlib.sha256(data).hexdigest() != sha256:
        raise BusinessError("ARTIFACT_VERIFICATION_FAILED", "产物核验失败", 409)
    return data


def remove_note(root: Path, identity: UUID) -> None:
    path = artifact_path(root, identity)
    temp = path.with_name(f".{identity}.tmp")
    if temp.is_symlink():
        raise BusinessError("ARTIFACT_PATH_DENIED", "产物临时文件不能是链接", 409)
    path.unlink(missing_ok=True)
    temp.unlink(missing_ok=True)
