"""Authenticated local text import with bounded request streaming and owned sources."""

import json
from typing import Literal
from uuid import UUID

from fastapi import APIRouter, Query, Request
from pydantic import BaseModel, ConfigDict, Field, ValidationError
from sqlalchemy import Engine
from starlette.concurrency import run_in_threadpool

from app import reading_service as service
from app.config import Settings
from app.errors import BusinessError
from app.repository import Row
from app.security import authenticate


class ImportBody(BaseModel):
    model_config = ConfigDict(extra="forbid")
    title: str = Field(min_length=1, max_length=120, strict=True)
    content: str = Field(min_length=1, strict=True)


class PolicyBody(BaseModel):
    model_config = ConfigDict(extra="forbid")
    auto_enabled: bool = Field(strict=True)
    interval_seconds: int = Field(ge=60, le=86400, strict=True)
    expected_version: int = Field(ge=1, strict=True)


class NextBody(BaseModel):
    model_config = ConfigDict(extra="forbid")
    expected_version: int = Field(ge=1, strict=True)


class QuestionBody(BaseModel):
    model_config = ConfigDict(extra="forbid")
    ordinal: int = Field(ge=0, le=99, strict=True)
    source_hash: str = Field(pattern=r"^[0-9a-f]{64}$", strict=True)
    question: str = Field(min_length=1, max_length=1500, strict=True)
    acknowledgement: Literal["允许将所选原文和问题发送给Qoder"]


class SuggestedReadingBody(BaseModel):
    model_config = ConfigDict(extra="forbid")
    expected_version: int = Field(ge=1, strict=True)
    ordinal: int = Field(ge=0, le=99, strict=True)
    source_hash: str = Field(pattern=r"^[0-9a-f]{64}$", strict=True)
    acknowledgement: Literal["确认处理这段本地资料"]


def request_key(request: Request) -> UUID:
    try:
        return UUID(request.headers.get("Idempotency-Key", ""))
    except ValueError:
        raise BusinessError("IDEMPOTENCY_REQUIRED", "请提供UUID请求标识", 400) from None


async def bounded_import(request: Request) -> ImportBody:
    data = bytearray()
    async for chunk in request.stream():
        if len(data) + len(chunk) > 2 * 1024 * 1024:
            raise BusinessError("READING_TEXT_TOO_LARGE", "导入请求超过2MiB", 413)
        data.extend(chunk)
    try:
        value = json.loads(data)
        return ImportBody.model_validate(value)
    except (ValueError, UnicodeError, RecursionError, ValidationError):
        raise BusinessError("READING_TEXT_INVALID", "请检查标题和纯文本格式", 422) from None


def reading_router(engine: Engine, settings: Settings) -> APIRouter:
    routes = APIRouter()

    @routes.get("/characters/{character_id}/reading-suggestions")
    def reading_suggestions(character_id: UUID, request: Request) -> Row:
        from app.reading_suggestions import suggestions

        owner = authenticate(request, engine, settings)["id"]
        return suggestions(engine, settings, owner, character_id)

    @routes.post("/books/{book_id}/suggested-reading", status_code=202)
    def confirm_suggested_reading(
        book_id: UUID, body: SuggestedReadingBody, request: Request
    ) -> Row:
        from app.reading_suggestions import confirm

        owner = authenticate(request, engine, settings, True)["id"]
        return confirm(
            engine,
            settings,
            owner,
            book_id,
            body.expected_version,
            body.ordinal,
            body.source_hash,
            body.acknowledgement,
            request_key(request),
        )

    @routes.get("/books/{book_id}/search")
    def search(
        book_id: UUID, request: Request, q: str = Query(min_length=1, max_length=120)
    ) -> Row:
        from app.reading_search import search_book

        owner = authenticate(request, engine, settings)["id"]
        return search_book(engine, settings, owner, book_id, q)

    @routes.post("/books/{book_id}/questions", status_code=202)
    def question(book_id: UUID, body: QuestionBody, request: Request) -> Row:
        from app.reading_qa import enqueue

        owner = authenticate(request, engine, settings, True)["id"]
        return enqueue(
            engine,
            settings,
            owner,
            book_id,
            body.ordinal,
            body.source_hash,
            body.question,
            body.acknowledgement,
            request_key(request),
        )

    @routes.get("/books/{book_id}/questions/{task_id}")
    def answer(book_id: UUID, task_id: UUID, request: Request) -> Row:
        from app.reading_qa import get_answer

        owner = authenticate(request, engine, settings)["id"]
        return get_answer(engine, settings, owner, book_id, task_id)

    @routes.get("/books/{book_id}/questions")
    def questions(book_id: UUID, request: Request, ordinal: int = Query(ge=0, le=99)) -> Row:
        from app.reading_qa import list_questions

        owner = authenticate(request, engine, settings)["id"]
        return list_questions(engine, settings, owner, book_id, ordinal)

    @routes.get("/characters/{character_id}/books")
    def books(character_id: UUID, request: Request) -> Row:
        owner = authenticate(request, engine, settings)["id"]
        return service.list_books(engine, settings, owner, character_id)

    @routes.post(
        "/characters/{character_id}/books",
        status_code=201,
        openapi_extra={
            "requestBody": {
                "required": True,
                "content": {"application/json": {"schema": ImportBody.model_json_schema()}},
            }
        },
    )
    async def add_book(character_id: UUID, request: Request) -> Row:
        owner = await run_in_threadpool(authenticate, request, engine, settings, True)
        service.capability(settings)
        key = request_key(request)
        body = await bounded_import(request)
        return await run_in_threadpool(
            service.import_book,
            engine,
            settings,
            owner["id"],
            character_id,
            body.title,
            body.content,
            key,
        )

    @routes.get("/books/{book_id}")
    def book(book_id: UUID, request: Request) -> Row:
        owner = authenticate(request, engine, settings)["id"]
        return service.get_book(engine, settings, owner, book_id)

    @routes.patch("/books/{book_id}")
    def policy(book_id: UUID, body: PolicyBody, request: Request) -> Row:
        owner = authenticate(request, engine, settings, True)["id"]
        return service.configure_book(
            engine,
            settings,
            owner,
            book_id,
            body.auto_enabled,
            body.interval_seconds,
            body.expected_version,
        )

    @routes.delete("/books/{book_id}")
    def erase(book_id: UUID, request: Request) -> Row:
        owner = authenticate(request, engine, settings, True)["id"]
        return service.delete_book(engine, settings, owner, book_id)

    @routes.post("/books/{book_id}/next", status_code=202)
    def next_segment(book_id: UUID, body: NextBody, request: Request) -> Row:
        owner = authenticate(request, engine, settings, True)["id"]
        return service.enqueue_next(
            engine, settings, owner, book_id, request_key(request), body.expected_version
        )

    @routes.get("/books/{book_id}/segments/{ordinal}")
    def segment(book_id: UUID, ordinal: int, request: Request) -> Row:
        owner = authenticate(request, engine, settings)["id"]
        return service.segment_view(engine, settings, owner, book_id, ordinal)

    @routes.get("/books/{book_id}/notes")
    def notes(
        book_id: UUID,
        request: Request,
        after: int = Query(default=-1, ge=-1, le=99),
        limit: int = Query(default=20, ge=1, le=100),
    ) -> Row:
        owner = authenticate(request, engine, settings)["id"]
        return service.list_notes(engine, settings, owner, book_id, after, limit)

    return routes
