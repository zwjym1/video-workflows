from datetime import UTC, datetime
from typing import Any

from sqlalchemy import Engine, create_engine, text

from app.config import Settings
from app.release import REQUIRED_TABLES, SCHEMA_REVISION


def build_engine(settings: Settings) -> Engine:
    return create_engine(
        settings.database_url.get_secret_value(),
        pool_pre_ping=True,
        connect_args={
            "connect_timeout": 2,
            "options": "-c statement_timeout=2000 -c lock_timeout=1000",
        },
    )


def probe_database(engine: Engine) -> dict[str, Any]:
    with engine.connect() as connection:
        revision = connection.execute(
            text("SELECT version_num FROM public.alembic_version")
        ).scalar_one()
        if revision != SCHEMA_REVISION:
            raise RuntimeError("Database migration does not match this application")
        missing = connection.execute(
            text("""SELECT name
            FROM unnest(CAST(:names AS text[])) AS required(name)
            WHERE to_regclass('public.'||quote_ident(name)) IS NULL
              OR NOT has_table_privilege(current_user,'public.'||quote_ident(name),'SELECT')"""),
            {"names": list(REQUIRED_TABLES)},
        ).first()
        if missing:
            raise RuntimeError("Required database table or read permission is missing")
        version = connection.execute(
            text("SELECT extversion FROM pg_extension WHERE extname='vector'")
        )
        vector_version = version.scalar_one()
        heartbeat = connection.execute(
            text("""SELECT heartbeat_at FROM public.service_heartbeats
            WHERE service_name='worker'""")
        ).scalar_one_or_none()
        age = (datetime.now(UTC) - heartbeat).total_seconds() if heartbeat else None
        return {
            "database": "available",
            "vector_version": str(vector_version),
            "schema_revision": revision,
            "worker_fresh": age is not None and 0 <= age < 70,
            "worker_heartbeat_age_seconds": age,
        }
