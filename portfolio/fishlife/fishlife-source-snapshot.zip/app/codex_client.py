"""One subscription CLI call with committed dispatch evidence and no automatic replay."""

import json
import os
import re
from pathlib import Path
from uuid import UUID, uuid4

from sqlalchemy import Engine

from app.bounded_process import BoundedProcessError
from app.config import Settings
from app.errors import BusinessError
from app.memory import extract_claims
from app.memory_lifecycle import expire_due
from app.model_client import ModelFailure, ModelResult, request_payload
from app.qoder_platform import run_native_process
from app.repository import Row, execute, one

SCHEMA = Path(__file__).with_name("codex_reply_schema.json")
# Serializes every user sharing this single local subscription CLI identity.
DISPATCH_LOCK = 571598177194886


def validate_configuration(settings: Settings) -> None:
    if (
        settings.model_provider != "codex"
        or not settings.allow_real_model_calls
        or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,99}", settings.codex_model)
        or not Path(settings.codex_cli).is_absolute()
        or not Path(settings.codex_cli).is_file()
        or not Path(settings.codex_cwd).is_absolute()
        or not Path(settings.codex_cwd).is_dir()
        or not SCHEMA.is_file()
    ):
        raise ModelFailure("CODEX_NOT_CONFIGURED")
    # Never inherit project instructions or execute inside a source checkout.
    if any(Path(settings.codex_cwd).iterdir()):
        raise ModelFailure("CODEX_WORKSPACE_NOT_EMPTY")


def invocation(settings: Settings) -> tuple[list[str], dict[str, str]]:
    args = [
        "exec",
        "--ignore-user-config",
        "--ephemeral",
        "--skip-git-repo-check",
        "-s",
        "read-only",
        "--json",
        "--output-schema",
        str(SCHEMA),
        "-C",
        settings.codex_cwd,
        "-m",
        settings.codex_model,
    ]
    overrides = [
        'forced_login_method="chatgpt"',
        'web_search="disabled"',
        "notify=[]",
        'history.persistence="none"',
        'model_reasoning_effort="low"',
    ]
    overrides += [
        f"features.{name}=false"
        for name in (
            "shell_tool",
            "apps",
            "hooks",
            "plugins",
            "remote_plugin",
            "browser_use",
            "view_image",
            "multi_agent",
            "memories",
            "workspace_dependencies",
            "tool_suggest",
            "shell_snapshot",
            "skill_mcp_dependency_install",
        )
    ]
    for value in overrides:
        args.extend(["-c", value])
    args.append("-")
    environment = {
        key: value
        for key, value in os.environ.items()
        if key.upper()
        in {
            "SYSTEMROOT",
            "WINDIR",
            "USERPROFILE",
            "HOME",
            "APPDATA",
            "LOCALAPPDATA",
            "CODEX_HOME",
            "HTTP_PROXY",
            "HTTPS_PROXY",
            "NO_PROXY",
            "ALL_PROXY",
            "SSL_CERT_FILE",
        }
    }
    environment.update(
        PYTHONUTF8="1", NO_COLOR="1", TEMP=settings.codex_cwd, TMP=settings.codex_cwd
    )
    return args, environment


def parse_result(output: str, context: Row) -> ModelResult:
    try:
        events = [json.loads(line) for line in output.splitlines() if line.strip()]
        texts, completions, receipts = [], [], []
        for event in events:
            kind = event["type"]
            if kind == "thread.started":
                receipts.append(event["thread_id"])
            elif kind == "turn.completed":
                completions.append(event["usage"])
            elif kind in ("item.started", "item.updated", "item.completed"):
                item = event["item"]
                if item["type"] not in ("agent_message", "reasoning"):
                    raise ValueError("Unexpected tool item")
                if kind == "item.completed" and item["type"] == "agent_message":
                    texts.append(item["text"])
            elif kind != "turn.started":
                raise ValueError("Unexpected or failed event")
        if len(texts) != 1 or len(completions) != 1 or len(receipts) != 1:
            raise ValueError("Incomplete response")
        usage = completions[0]
        if not all(
            type(usage.get(key)) is int and usage[key] >= 0
            for key in ("input_tokens", "output_tokens")
        ):
            raise ValueError("Invalid token receipt")
        receipt = receipts[0]
        if not isinstance(receipt, str) or not 1 <= len(receipt) <= 200:
            raise ValueError("Invalid thread receipt")
        parsed = json.loads(texts[0])
        if not isinstance(parsed, dict) or set(parsed) != {"reply", "memory_quotes"}:
            raise ValueError("Invalid reply schema")
        if not isinstance(parsed["reply"], str) or not 1 <= len(parsed["reply"].strip()) <= 12000:
            raise ValueError("Invalid reply text")
        quotes = parsed["memory_quotes"]
        if (
            not isinstance(quotes, list)
            or len(quotes) > 20
            or not all(isinstance(quote, str) and len(quote) <= 300 for quote in quotes)
            or ("reading_qa" in context and quotes)
        ):
            raise ValueError("Invalid source quotes")
        source = context["message"]
        claims = [
            claim
            for claim in extract_claims(source["content"], source["content_kind"])
            if claim.quote in quotes
        ]
        return ModelResult(
            parsed["reply"], claims, usage["input_tokens"], usage["output_tokens"], receipt
        )
    except (ValueError, TypeError, KeyError, AttributeError) as exc:
        raise ModelFailure("CODEX_INVALID_OUTPUT", uncertain=True) from exc


def begin_dispatch(engine: Engine, settings: Settings, task: Row, context: Row) -> UUID:
    p = {
        "o": task["owner_id"],
        "c": task["character_id"],
        "t": task["id"],
        "r": task["run_id"],
        "m": settings.codex_model,
    }
    with engine.begin() as conn:
        execute(conn, "SELECT pg_advisory_xact_lock(:k)", {"k": DISPATCH_LOCK})
        user = one(conn, "SELECT disabled FROM users WHERE id=:o FOR UPDATE", p)
        state = one(
            conn,
            "SELECT * FROM character_states WHERE owner_id=:o AND character_id=:c FOR UPDATE",
            p,
        )
        if state:
            expire_due(conn, state)
            state = one(
                conn, "SELECT * FROM character_states WHERE owner_id=:o AND character_id=:c", p
            )
        current = one(
            conn,
            """SELECT t.*,r.memory_epoch AS run_epoch,r.status AS run_status,
            r.fencing_token AS run_fence FROM tasks t JOIN task_runs r
            ON r.task_id=t.id AND r.owner_id=t.owner_id AND r.character_id=t.character_id
            JOIN characters c ON c.id=t.character_id AND c.owner_id=t.owner_id
            WHERE t.id=:t AND t.owner_id=:o AND r.id=:r AND c.enabled
            AND t.lease_until>clock_timestamp() FOR UPDATE OF t,r""",
            p,
        )
        if (
            not user
            or user["disabled"]
            or not state
            or state["mode"] == "deleting"
            or not current
            or current["kind"] != "chat_reply"
            or current["status"] != "running"
            or current["run_status"] != "running"
            or current["cancel_requested"]
            or current["fencing_token"] != current["run_fence"]
            or current["fencing_token"] != task["fencing_token"]
            or state["memory_epoch"] != current["run_epoch"]
            or state["memory_epoch"] != task["memory_epoch"]
        ):
            raise BusinessError("CODEX_CONTEXT_INVALID", "任务已停止或上下文已变化", 409)
        message = one(
            conn,
            """SELECT content,content_kind FROM messages WHERE id=:s
            AND owner_id=:o AND character_id=:c AND role='user' AND status='completed'""",
            {**p, "s": context["message"]["id"]},
        )
        if (
            str(current["input"].get("message_id")) != str(context["message"]["id"])
            or not message
            or message["content"] != context["message"]["content"]
            or message["content_kind"] != context["message"]["content_kind"]
        ):
            raise BusinessError("CODEX_CONTEXT_INVALID", "原消息已变化", 409)
        if "reading_qa" in current["input"]:
            from app.reading_qa import load_source

            load_source(conn, current)
        if one(conn, "SELECT id FROM codex_dispatches WHERE task_id=:t", p):
            raise BusinessError("CODEX_DISPATCH_EXISTS", "本请求已消耗调用许可，禁止重发", 409)
        if one(
            conn,
            """SELECT d.id FROM codex_dispatches d JOIN tasks t ON t.id=d.task_id
            WHERE d.status IN ('started','unknown') OR t.status<>'succeeded' LIMIT 1""",
        ):
            raise BusinessError(
                "CODEX_UNRESOLVED_DISPATCH", "存在未确认的订阅调用，禁止继续发送", 409
            )
        used = one(
            conn,
            """SELECT count(*) AS n FROM codex_dispatches WHERE owner_id=:o
            AND started_at>=date_trunc('day',clock_timestamp() AT TIME ZONE 'UTC') AT TIME ZONE 'UTC'""",
            p,
        )
        if used and used["n"] >= settings.codex_daily_limit:
            raise BusinessError("CODEX_DAILY_LIMIT", "今日订阅聊天次数已达上限", 429)
        held = one(
            conn,
            """SELECT b.id FROM budget_reservations b JOIN model_usage_logs u
            ON u.reservation_id=b.id AND u.run_id=b.run_id AND u.owner_id=b.owner_id
            WHERE b.run_id=:r AND b.owner_id=:o AND b.status='held'
            AND u.character_id=:c AND u.provider='codex' AND u.model=:m AND u.status='reserved'
            FOR UPDATE OF b,u""",
            p,
        )
        if not held:
            raise BusinessError("CODEX_RESERVATION_REQUIRED", "缺少订阅调用预占记录", 409)
        if not one(conn, "SELECT id FROM tasks WHERE id=:t AND lease_until>clock_timestamp()", p):
            raise BusinessError("CODEX_CONTEXT_INVALID", "任务租约已到期", 409)
        identity = uuid4()
        execute(
            conn,
            """INSERT INTO codex_dispatches(id,owner_id,character_id,task_id,run_id,
            reservation_id,model,status) VALUES (:id,:o,:c,:t,:r,:b,:m,'started')""",
            {**p, "id": identity, "b": held["id"]},
        )
    return identity


class CodexClient:
    def __init__(self, engine: Engine, settings: Settings, task: Row) -> None:
        self.engine, self.settings, self.task = engine, settings, task

    def generate(self, context: Row) -> ModelResult:
        validate_configuration(self.settings)
        args, environment = invocation(self.settings)
        payload = request_payload(context, self.settings)
        prompt = json.dumps(
            {
                "instruction": "只进行文字对话，禁止使用工具。按schema返回JSON。",
                "messages": payload["input"],
            },
            ensure_ascii=False,
            default=str,
        )
        if len(prompt.encode()) > 24000:
            raise ModelFailure("CONTEXT_TOO_LARGE")
        identity = begin_dispatch(self.engine, self.settings, self.task, context)
        try:
            output = run_native_process(
                executable=self.settings.codex_cli,
                args=args,
                cwd=self.settings.codex_cwd,
                env=environment,
                stdin=prompt,
                timeout=90,
                max_output_bytes=262144,
            )
            result = parse_result(output, context)
            with self.engine.begin() as conn:
                execute(
                    conn,
                    """UPDATE codex_dispatches SET status='succeeded',
                    finished_at=now() WHERE id=:id AND status='started'""",
                    {"id": identity},
                )
            return result
        except Exception as exc:
            with self.engine.begin() as conn:
                execute(
                    conn,
                    """UPDATE codex_dispatches SET status='unknown',
                    finished_at=now() WHERE id=:id AND status='started'""",
                    {"id": identity},
                )
            if isinstance(exc, (ModelFailure, BoundedProcessError)):
                raise ModelFailure("CODEX_RESULT_UNKNOWN", uncertain=True) from exc
            raise ModelFailure("CODEX_EXECUTION_UNKNOWN", uncertain=True) from exc
