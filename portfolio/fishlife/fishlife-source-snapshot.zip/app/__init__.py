"""FishLife application package."""
