from datetime import UTC, datetime
from decimal import Decimal
from uuid import NAMESPACE_URL, UUID, uuid4, uuid5
from zoneinfo import ZoneInfo

from sqlalchemy import Connection, Engine

from app.config import Settings
from app.errors import BusinessError
from app.model_client import ModelFailure, ModelResult
from app.qoder_accounting import record_report
from app.repository import Row, execute, one, rows


def reconcile_cancelled_reservations(engine: Engine) -> int:
    """Bounded restart recovery for held costs whose tasks were privacy-cancelled."""
    with engine.connect() as conn:
        candidates = rows(
            conn,
            """SELECT b.id,r.owner_id,r.character_id
            FROM budget_reservations b JOIN task_runs r ON r.id=b.run_id
            JOIN tasks t ON t.id=r.task_id WHERE b.status='held' AND t.status='cancelled'
            ORDER BY b.created_at,b.id LIMIT 20""",
        )
    count = 0
    for item in candidates:
        with engine.begin() as conn:
            state = one(
                conn,
                """SELECT character_id FROM character_states
                WHERE owner_id=:owner_id AND character_id=:character_id
                FOR UPDATE SKIP LOCKED""",
                item,
            )
            if not state:
                continue
            pending = one(
                conn,
                """SELECT b.id FROM budget_reservations b
                JOIN task_runs r ON r.id=b.run_id JOIN tasks t ON t.id=r.task_id
                WHERE b.id=:id AND b.owner_id=:owner_id AND b.status='held'
                AND t.status='cancelled' FOR UPDATE OF b""",
                item,
            )
            if not pending:
                continue
            execute(conn, "UPDATE budget_reservations SET status='unknown' WHERE id=:id", item)
            execute(
                conn, "UPDATE model_usage_logs SET status='unknown' WHERE reservation_id=:id", item
            )
            count += 1
    return count


def reserve(engine: Engine, task: Row, amount: Decimal, settings: Settings) -> UUID:
    with engine.begin() as conn:
        user = one(conn, "SELECT * FROM users WHERE id=:o", {"o": task["owner_id"]})
        assert user is not None
        day = datetime.now(UTC).astimezone(ZoneInfo(user["timezone"])).date()
        definitions = []
        for period, start, limit in [
            ("day", day, user["daily_budget_usd"]),
            ("month", day.replace(day=1), user["monthly_budget_usd"]),
        ]:
            for bucket in ("total", "chat"):
                account_id = uuid5(
                    NAMESPACE_URL, f"fishlife:{task['owner_id']}:{period}:{start}:{bucket}"
                )
                definitions.append(
                    {
                        "id": account_id,
                        "o": task["owner_id"],
                        "p": period,
                        "s": start,
                        "b": bucket,
                        "l": limit,
                    }
                )
        # Initialize in canonical order without locking existing rows via UPDATE.
        for definition in sorted(definitions, key=lambda x: str(x["id"])):
            execute(
                conn,
                """INSERT INTO budget_accounts(id,owner_id,period_type,
                    period_start,bucket,limit_amount) VALUES (:id,:o,:p,:s,:b,:l)
                    ON CONFLICT(owner_id,period_type,period_start,bucket) DO NOTHING""",
                definition,
            )
        ids = [x["id"] for x in definitions]
        accounts = rows(
            conn,
            "SELECT * FROM budget_accounts WHERE id=ANY(:ids) ORDER BY id FOR UPDATE",
            {"ids": ids},
        )
        limits = {x["id"]: x["l"] for x in definitions}
        for account in accounts:
            account["limit_amount"] = limits[account["id"]]
            execute(
                conn,
                "UPDATE budget_accounts SET limit_amount=:l WHERE id=:id",
                {"l": account["limit_amount"], "id": account["id"]},
            )
        if any(
            x["spent_amount"] + x["reserved_amount"] + amount > x["limit_amount"] for x in accounts
        ):
            raise BusinessError("BUDGET_EXCEEDED", "预算不足，未调用模型", 429)
        reservation = uuid4()
        if settings.model_provider == "qoder":
            pricing = "qoder-unverified-hold-v1"
        elif settings.model_provider == "codex":
            pricing = "codex-subscription-unverified-hold-v1"
        elif settings.model_provider == "mock":
            pricing = "mock-zero-v1"
        else:
            pricing = (
                f"configured:{settings.model_input_usd_per_million}:"
                f"{settings.model_output_usd_per_million}"
            )
        execute(
            conn,
            """INSERT INTO budget_reservations(id,owner_id,run_id,status,reserved_cost,
            pricing_version) VALUES (:id,:o,:run,'held',:cost,:price)""",
            {
                "id": reservation,
                "o": task["owner_id"],
                "run": task["run_id"],
                "cost": amount,
                "price": pricing,
            },
        )
        for account in accounts:
            execute(
                conn,
                "UPDATE budget_accounts SET reserved_amount=reserved_amount+:a WHERE id=:id",
                {"a": amount, "id": account["id"]},
            )
            execute(
                conn,
                """INSERT INTO budget_reservation_accounts(reservation_id,account_id,
                reserved_amount) VALUES (:r,:a,:amount)""",
                {"r": reservation, "a": account["id"], "amount": amount},
            )
        execute(
            conn,
            """INSERT INTO model_usage_logs(id,owner_id,character_id,run_id,reservation_id,
            provider,model,purpose,estimated_cost_usd,status,pricing_version)
            VALUES (:id,:o,:c,:run,:res,:provider,:model,:purpose,:cost,'reserved',:price)""",
            {
                "id": uuid4(),
                "o": task["owner_id"],
                "c": task["character_id"],
                "run": task["run_id"],
                "res": reservation,
                "provider": settings.model_provider,
                "model": settings.chat_model or "mock-v1",
                "purpose": "activity_plan" if task.get("kind") == "activity_plan" else "chat",
                "cost": amount,
                "price": pricing,
            },
        )
        return reservation


def settle(
    conn: Connection,
    reservation: UUID,
    result: ModelResult | None,
    settings: Settings,
    uncertain: bool = False,
) -> None:
    item = one(conn, "SELECT * FROM budget_reservations WHERE id=:r FOR UPDATE", {"r": reservation})
    if not item or item["status"] not in {"held", "unknown"}:
        return
    # A confirmed late response can resolve its own unknown reservation once.
    # A missing/failed response cannot release an unknown charge.
    if item["status"] == "unknown" and result is None:
        return
    usage = one(
        conn,
        "SELECT * FROM model_usage_logs WHERE reservation_id=:r FOR UPDATE",
        {"r": reservation},
    )
    if not usage:
        raise ModelFailure("USAGE_LOG_MISSING", uncertain=True)
    # Stored provider identity governs accounting, even if caller settings differ.
    # Qoder USD/Credits reports are not verified charges and never use API prices.
    dispatched = None
    if usage["provider"] == "codex":
        dispatched = one(
            conn,
            "SELECT id FROM codex_dispatches WHERE run_id=:run",
            {"run": item["run_id"]},
        )
        if result is not None or uncertain or dispatched:
            execute(
                conn,
                "UPDATE budget_reservations SET status='unknown' WHERE id=:r",
                {"r": reservation},
            )
            execute(
                conn,
                """UPDATE model_usage_logs SET status='unknown',
                input_tokens=COALESCE(:i,input_tokens),output_tokens=COALESCE(:o,output_tokens),
                provider_request_id=COALESCE(:p,provider_request_id)
                WHERE reservation_id=:r""",
                {
                    "r": reservation,
                    "i": result.input_tokens if result else None,
                    "o": result.output_tokens if result else None,
                    "p": result.request_id if result else None,
                },
            )
            return
    if usage["provider"] == "qoder" and result is None:
        dispatched = one(
            conn,
            """SELECT id FROM provider_dispatches
            WHERE owner_id=:o AND run_id=:run""",
            {"o": item["owner_id"], "run": item["run_id"]},
        )
    if usage["provider"] == "qoder" and (result is not None or uncertain or dispatched):
        if result:
            record_report(conn, item, usage, result)
        execute(
            conn, "UPDATE budget_reservations SET status='unknown' WHERE id=:r", {"r": reservation}
        )
        execute(
            conn,
            """UPDATE model_usage_logs SET status='unknown',
            input_tokens=COALESCE(:i,input_tokens),output_tokens=COALESCE(:o,output_tokens),
            provider_request_id=COALESCE(:p,provider_request_id)
            WHERE reservation_id=:r""",
            {
                "r": reservation,
                "i": result.input_tokens if result else None,
                "o": result.output_tokens if result else None,
                "p": result.request_id if result else None,
            },
        )
        return
    if result and result.qoder_usage is not None:
        raise ModelFailure("PROVIDER_REPORT_MISMATCH", uncertain=True)
    if uncertain:
        execute(
            conn, "UPDATE budget_reservations SET status='unknown' WHERE id=:r", {"r": reservation}
        )
        execute(
            conn,
            "UPDATE model_usage_logs SET status='unknown' WHERE reservation_id=:r",
            {"r": reservation},
        )
        return
    cost = Decimal(0)
    if result and settings.model_provider != "mock":
        assert settings.model_input_usd_per_million is not None
        assert settings.model_output_usd_per_million is not None
        cost = (
            (
                result.input_tokens * settings.model_input_usd_per_million
                + result.output_tokens * settings.model_output_usd_per_million
            )
            / 1000000
        ).quantize(Decimal(".00000001"))
    accounts = rows(
        conn,
        """SELECT a.*,m.reserved_amount AS held FROM budget_accounts a
        JOIN budget_reservation_accounts m ON m.account_id=a.id WHERE m.reservation_id=:r
        ORDER BY a.id FOR UPDATE OF a""",
        {"r": reservation},
    )
    for account in accounts:
        execute(
            conn,
            """UPDATE budget_accounts SET reserved_amount=reserved_amount-:held,
            spent_amount=spent_amount+:cost WHERE id=:id""",
            {"held": account["held"], "cost": cost, "id": account["id"]},
        )
    execute(
        conn,
        """UPDATE budget_reservations SET status=:s,settled_cost=:cost,settled_at=now()
        WHERE id=:r""",
        {"r": reservation, "s": "settled" if result else "released", "cost": cost},
    )
    execute(
        conn,
        """UPDATE model_usage_logs SET status=:s,actual_cost_usd=:cost,input_tokens=:i,
        output_tokens=:o,provider_request_id=:p WHERE reservation_id=:r""",
        {
            "s": "succeeded" if result else "failed",
            "cost": cost,
            "r": reservation,
            "i": result.input_tokens if result else None,
            "o": result.output_tokens if result else None,
            "p": result.request_id if result else None,
        },
    )
