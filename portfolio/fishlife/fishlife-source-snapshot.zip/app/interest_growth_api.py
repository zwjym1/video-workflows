from uuid import UUID

from fastapi import APIRouter, Request
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import Engine

from app import interest_growth as service
from app.config import Settings
from app.repository import Row
from app.security import authenticate


class AcceptBody(BaseModel):
    model_config = ConfigDict(extra="forbid")
    topic: str = Field(min_length=2, max_length=20, strict=True)
    source_digest: str = Field(pattern=r"^[0-9a-f]{64}$", strict=True)
    expected_version: int = Field(ge=1, strict=True)
    acknowledgement: str = Field(max_length=40, strict=True)


def interest_growth_router(engine: Engine, settings: Settings) -> APIRouter:
    router = APIRouter()

    @router.get("/characters/{character_id}/interest-suggestions")
    def suggestions(character_id: UUID, request: Request) -> Row:
        owner = authenticate(request, engine, settings)["id"]
        return service.suggestions(engine, settings, owner, character_id)

    @router.post("/characters/{character_id}/interest-suggestions/accept")
    def accept(character_id: UUID, body: AcceptBody, request: Request) -> Row:
        owner = authenticate(request, engine, settings, True)["id"]
        return service.accept(
            engine,
            settings,
            owner,
            character_id,
            body.topic,
            body.source_digest,
            body.expected_version,
            body.acknowledgement,
        )

    return router
