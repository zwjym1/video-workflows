"""Single-attempt Qoder planning; local verification remains the execution authority."""

import json
from collections.abc import Callable
from datetime import UTC, datetime
from uuid import UUID, uuid4

from sqlalchemy import Connection, Engine

from app.activity_choice import parse_choice
from app.activity_model import ActivityChoiceCall, ActivityModelOutcome, prepare_activity_choice
from app.activity_plan_sources import load_candidates
from app.budgets import reserve, settle
from app.config import Settings
from app.errors import BusinessError
from app.memory import assert_character
from app.model_client import ModelFailure
from app.queue import claim_task, fail_task, recover_expired
from app.repository import Row, execute, one


def _lock_context(
    conn: Connection, task: Row, *, lock_run: bool = False
) -> tuple[Row | None, Row, Row | None]:
    params = {
        "o": task["owner_id"],
        "c": task["character_id"],
        "t": task["id"],
        "r": task["run_id"],
    }
    # Stop operations use the same owner -> character order. No provider account
    # lock is acquired here; dispatch itself owns account serialization.
    # The separate reserve transaction inserts rows whose owner foreign key
    # takes KEY SHARE. NO KEY UPDATE still serializes owner stops while allowing
    # that FK check, avoiding a self-deadlock across the two connections.
    user = one(
        conn,
        "SELECT * FROM users WHERE id=:o " + ("FOR UPDATE" if lock_run else "FOR NO KEY UPDATE"),
        params,
    )
    state = assert_character(conn, task["owner_id"], task["character_id"], lock=True)
    current = one(
        conn,
        """SELECT t.*,r.memory_epoch AS run_epoch,r.fencing_token AS run_fence,
        r.status AS run_status,t.lease_until>clock_timestamp() AS lease_valid
        FROM tasks t JOIN task_runs r ON r.task_id=t.id AND r.owner_id=t.owner_id
        AND r.character_id=t.character_id
        WHERE t.id=:t AND t.owner_id=:o AND t.character_id=:c AND r.id=:r"""
        + (" FOR UPDATE OF t,r" if lock_run else ""),
        params,
    )
    return user, state, current


def _eligible(
    conn: Connection,
    task: Row,
    settings: Settings,
    user: Row | None,
    state: Row,
    current: Row | None,
) -> list[Row]:
    if (
        not settings.model_planning_enabled
        or not settings.autonomy_enabled
        or settings.model_provider != "qoder"
        or not settings.allow_real_model_calls
        or not user
        or user["disabled"]
        or user["autonomy_paused"]
        or not state["enabled"]
        or state["mode"] == "deleting"
        or not current
        or current["kind"] != "activity_plan"
        or current["max_attempts"] != 1
        or current["status"] != "running"
        or current["run_status"] != "running"
        or current["cancel_requested"]
        or not current["lease_valid"]
        or current["fencing_token"] != task["fencing_token"]
        or current["run_fence"] != task["fencing_token"]
        or current["run_epoch"] != task["memory_epoch"]
        or state["memory_epoch"] != task["memory_epoch"]
    ):
        raise BusinessError("ACTIVITY_PLAN_UNAVAILABLE", "规划来源或许可已失效", 409)
    policy = one(
        conn,
        """SELECT enabled,quiet_until FROM activity_planning_preferences
        WHERE owner_id=:o AND character_id=:c""",
        {"o": task["owner_id"], "c": task["character_id"]},
    )
    if (
        not policy
        or not policy["enabled"]
        or (policy["quiet_until"] and policy["quiet_until"] > datetime.now(UTC))
    ):
        raise BusinessError("ACTIVITY_PLAN_UNAVAILABLE", "模型选择已关闭或处于静默期", 409)
    candidates = load_candidates(conn, task["owner_id"], task["character_id"], task["id"])
    # Source/reservation locks can wait; do not reuse the earlier lease snapshot.
    if not one(
        conn,
        "SELECT id FROM tasks WHERE id=:t AND lease_until>clock_timestamp()",
        {"t": task["id"]},
    ):
        raise BusinessError("ACTIVITY_PLAN_UNAVAILABLE", "规划任务租约已到期", 409)
    return candidates


def _finish(
    conn: Connection,
    task: Row,
    status: str,
    *,
    code: str | None = None,
    result: Row | None = None,
) -> None:
    execute(
        conn,
        """UPDATE tasks SET status=:s,error_code=:code,result=CAST(:result AS jsonb),
        lease_until=NULL,lease_owner=NULL,updated_at=now() WHERE id=:t""",
        {
            "t": task["id"],
            "s": status,
            "code": code,
            "result": json.dumps(result, ensure_ascii=False) if result is not None else None,
        },
    )
    execute(
        conn,
        """UPDATE task_runs SET status=:s,error_code=:code,node='plan_persist',
        finished_at=now() WHERE id=:r""",
        {"r": task["run_id"], "s": status, "code": code},
    )


def _cooldown(conn: Connection, task: Row) -> None:
    execute(
        conn,
        """UPDATE activity_planning_preferences SET
        quiet_until=GREATEST(quiet_until,clock_timestamp()+interval '1 hour'),
        version=version+1 WHERE owner_id=:o AND character_id=:c""",
        {"o": task["owner_id"], "c": task["character_id"]},
    )


def persist_plan_outcome(
    engine: Engine,
    task: Row,
    outcome: ActivityModelOutcome,
    reservation: UUID,
    settings: Settings,
) -> None:
    """Record the bound receipt even when its reason can no longer be retained."""
    with engine.begin() as conn:
        user, state, current = _lock_context(conn, task, lock_run=True)
        binding = one(
            conn,
            """SELECT b.id FROM budget_reservations b JOIN model_usage_logs u
            ON u.reservation_id=b.id AND u.run_id=b.run_id AND u.owner_id=b.owner_id
            WHERE b.id=:b AND b.owner_id=:o AND b.run_id=:r AND u.character_id=:c
            AND u.provider='qoder' AND u.purpose='activity_plan' AND u.model=:m""",
            {
                "b": reservation,
                "o": task["owner_id"],
                "r": task["run_id"],
                "c": task["character_id"],
                "m": settings.chat_model,
            },
        )
        if not binding or not current or outcome.result.qoder_usage is None:
            raise ModelFailure("QODER_REPORT_REQUIRED", uncertain=True)
        settle(conn, reservation, outcome.result, settings)
        report = one(
            conn,
            """SELECT q.reservation_id FROM qoder_usage_reports q JOIN provider_dispatches d
            ON d.id=q.dispatch_id AND d.reservation_id=q.reservation_id AND d.owner_id=q.owner_id
            WHERE q.reservation_id=:b AND d.owner_id=:o AND d.character_id=:c
            AND d.task_id=:t AND d.run_id=:r""",
            {
                "b": reservation,
                "o": task["owner_id"],
                "c": task["character_id"],
                "t": task["id"],
                "r": task["run_id"],
            },
        )
        if not report:
            raise ModelFailure("QODER_DISPATCH_REQUIRED", uncertain=True)
        # Repeated/late persistence may only contribute accounting evidence.
        if (
            current["status"] != "running"
            or current["run_status"] != "running"
            or current["fencing_token"] != task["fencing_token"]
            or current["run_fence"] != task["fencing_token"]
        ):
            return
        try:
            candidates = _eligible(conn, task, settings, user, state, current)
        except BusinessError as error:
            _cooldown(conn, task)
            _finish(conn, task, "failed", code=error.code)
            return
        error_code = outcome.error_code
        try:
            # The original receipt text, not an injected outcome object, decides.
            choice = parse_choice(outcome.result.text, candidates)
            if outcome.result.claims or choice != outcome.choice:
                raise ValueError("Choice differs from validated receipt")
        except ValueError:
            error_code = error_code or "ACTIVITY_CHOICE_INVALID"
        if error_code:
            _cooldown(conn, task)
            _finish(conn, task, "failed", code=error_code)
            return
        result: Row = {
            "kind": "activity_plan",
            "content_kind": "inference",
            "reason": choice.reason,
            "quiet": choice.goal_id is None,
            "selected_goal_id": str(choice.goal_id) if choice.goal_id else None,
            "selected_task_id": None,
        }
        if choice.goal_id is None:
            _cooldown(conn, task)
        else:
            selected = uuid4()
            execute(
                conn,
                """INSERT INTO tasks(id,owner_id,character_id,kind,input,status,
                idempotency_key,goal_id) VALUES (:id,:o,:c,'local_activity','{}','queued',:k,:g)""",
                {
                    "id": selected,
                    "o": task["owner_id"],
                    "c": task["character_id"],
                    "k": "plan-selected:" + str(task["id"]),
                    "g": choice.goal_id,
                },
            )
            result["selected_task_id"] = str(selected)
        _finish(conn, task, "succeeded", result=result)


def _cooldown_failed(engine: Engine, task: Row) -> None:
    with engine.begin() as conn:
        _, state, current = _lock_context(conn, task, lock_run=True)
        if (
            current
            and current["status"] in ("failed", "unknown")
            and current["run_status"] in ("failed", "unknown")
            and current["fencing_token"] == task["fencing_token"]
            and current["run_fence"] == task["fencing_token"]
            and current["run_epoch"] == task["memory_epoch"]
            and state["memory_epoch"] == task["memory_epoch"]
        ):
            _cooldown(conn, task)


def process_plan_once(
    engine: Engine,
    settings: Settings,
    *,
    factory: Callable[[Engine, Settings, Row], ActivityChoiceCall] = prepare_activity_choice,
) -> bool:
    if (
        not settings.model_planning_enabled
        or not settings.autonomy_enabled
        or settings.model_provider != "qoder"
        or not settings.allow_real_model_calls
    ):
        return False
    recover_expired(engine, settings)
    task = claim_task(engine, kind="activity_plan")
    if not task:
        return False
    reservation: UUID | None = None
    effective = settings
    try:
        # Metadata and provider execution run outside database transactions.
        call = factory(engine, settings, task)
        effective = call.model_settings
        with engine.begin() as conn:
            user, state, current = _lock_context(conn, task)
            _eligible(conn, task, effective, user, state, current)
            # reserve has its own transaction. Do not lock task_runs above: its
            # foreign-key checks must remain compatible with this outer lock.
            reservation = reserve(engine, task, call.estimated_usd, effective)
        outcome = call.generate()
        persist_plan_outcome(engine, task, outcome, reservation, effective)
    except ModelFailure as error:
        fail_task(engine, task, error.code, effective, reservation, uncertain=error.uncertain)
        _cooldown_failed(engine, task)
    except BusinessError as error:
        fail_task(engine, task, error.code, effective, reservation)
        _cooldown_failed(engine, task)
    except Exception:
        fail_task(
            engine,
            task,
            "EXECUTION_FAILED",
            effective,
            reservation,
            uncertain=reservation is not None,
        )
        _cooldown_failed(engine, task)
    return True
