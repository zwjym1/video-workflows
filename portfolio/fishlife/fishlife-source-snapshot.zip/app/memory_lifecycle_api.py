from uuid import UUID

from fastapi import APIRouter, Request
from pydantic import AwareDatetime, BaseModel
from sqlalchemy import Engine

from app.config import Settings
from app.memory_lifecycle import set_expiration
from app.repository import Row
from app.security import authenticate


class ExpirationBody(BaseModel):
    expires_at: AwareDatetime | None


def memory_lifecycle_router(engine: Engine, settings: Settings) -> APIRouter:
    routes = APIRouter()

    @routes.patch("/memories/{memory_id}/expiration")
    def expiration(memory_id: UUID, body: ExpirationBody, request: Request) -> Row:
        user = authenticate(request, engine, settings, True)
        return set_expiration(
            engine, user["id"], memory_id, body.expires_at, request.headers.get("if-match")
        )

    return routes
