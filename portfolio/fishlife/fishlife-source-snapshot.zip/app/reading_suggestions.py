"""Local rule suggestions reference existing books; confirmation only queues one step."""

from uuid import UUID

from sqlalchemy import Engine

from app.config import Settings
from app.errors import BusinessError
from app.memory import assert_character
from app.reading_service import (
    capability,
    enqueue_locked,
    lock_book,
    permitted,
    read_snapshot,
    verified,
)
from app.repository import Row, one, rows

CONSENT = "确认处理这段本地资料"


def matched_interests(title: str, interests: object) -> list[str]:
    if not isinstance(interests, list):
        return []
    found, seen = [], set()
    folded = title.casefold()
    for value in interests[:20]:
        if not isinstance(value, str) or not 0 < len(value) <= 120 or not value.strip():
            continue
        term = value.strip()
        key = term.casefold()
        if key not in seen and key in folded:
            found.append(term)
            seen.add(key)
    return found


def suggestions(engine: Engine, settings: Settings, owner: UUID, character: UUID) -> Row:
    with read_snapshot(engine) as conn:
        state = assert_character(conn, owner, character)
        result: Row = {
            "items": [],
            "method": "local_rule",
            "cloud_processing": False,
            "capability_enabled": settings.reading_enabled,
        }
        if not settings.reading_enabled:
            return result
        books = rows(
            conn,
            """SELECT * FROM books WHERE owner_id=:o AND character_id=:c
            AND status='active' AND cursor<segment_count ORDER BY created_at,id LIMIT 20""",
            {"o": owner, "c": character},
        )
        candidates = []
        for book in books:
            try:
                segments, _ = verified(conn, book)
            except BusinessError:
                continue
            # Recommending a failed/unknown or already queued segment would invite re-execution.
            existing = one(
                conn,
                """SELECT id FROM tasks WHERE owner_id=:o AND character_id=:c
                AND reading_book_id=:b AND reading_ordinal=:n AND kind='reading_step'
                AND status IN ('queued','retry_wait','running','succeeded','failed','unknown')
                LIMIT 1""",
                {"o": owner, "c": character, "b": book["id"], "n": book["cursor"]},
            )
            if existing:
                continue
            matched = matched_interests(book["title"], state["interests"])
            candidates.append(
                {
                    "book_id": book["id"],
                    "title": book["title"],
                    "ordinal": book["cursor"],
                    "source_hash": segments[book["cursor"]]["source_hash"],
                    "book_version": book["version"],
                    "matched_interests": matched,
                    "reason": "标题包含已设置的兴趣词，可继续处理下一段原文。"
                    if matched
                    else "这份本地资料尚有未处理段落，可继续处理下一段原文。",
                    "action": "read_next_segment",
                }
            )
        candidates.sort(key=lambda value: -len(value["matched_interests"]))
        result["items"] = candidates[:3]
        return result


def confirm(
    engine: Engine,
    settings: Settings,
    owner: UUID,
    book: UUID,
    expected_version: int,
    ordinal: int,
    source_hash: str,
    acknowledgement: str,
    request_key: UUID,
) -> Row:
    capability(settings)
    if acknowledgement != CONSENT:
        raise BusinessError("READING_SUGGESTION_CONSENT", "请明确确认本次本地处理", 422)
    if type(ordinal) is not int or not 0 <= ordinal < 100:
        raise BusinessError("READING_SEGMENT_INVALID", "段落编号无效", 422)
    with engine.begin() as conn:
        user, state, value = lock_book(conn, owner, book)
        permitted(user, state, settings)
        key = "reading:" + str(request_key)
        prior = one(
            conn,
            "SELECT * FROM tasks WHERE owner_id=:o AND idempotency_key=:k",
            {"o": owner, "k": key},
        )
        if prior:
            if (
                prior["kind"] != "reading_step"
                or prior["reading_book_id"] != value["id"]
                or prior["reading_ordinal"] != ordinal
                or prior["input"].get("source_hash") != source_hash
                or prior["input"].get("book_version") != expected_version
            ):
                raise BusinessError("IDEMPOTENCY_CONFLICT", "请求标识对应了不同资料或进度", 409)
        else:
            if value["version"] != expected_version or value["cursor"] != ordinal:
                raise BusinessError("BOOK_CHANGED", "阅读进度或设置已变化，请刷新建议", 409)
            segments, _ = verified(conn, value)
            if ordinal >= len(segments) or segments[ordinal]["source_hash"] != source_hash:
                raise BusinessError("READING_SOURCE_INVALID", "建议来源已失效，请刷新", 409)
        return enqueue_locked(conn, settings, user, state, value, key, expected_version)
