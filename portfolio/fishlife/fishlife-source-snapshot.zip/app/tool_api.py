import json
from uuid import UUID

from fastapi import APIRouter, Query, Request, Response
from pydantic import BaseModel, Field, field_validator
from sqlalchemy import Engine

from app.config import Settings
from app.errors import BusinessError
from app.memory import assert_character
from app.pagination import decode_cursor, encode_cursor
from app.repository import Row, execute, rows
from app.security import authenticate
from app.tool_service import (
    approve_preview,
    artifact_view,
    create_preview,
    download_note,
    export_note,
    preview_view,
)


class NoteBody(BaseModel):
    goal_id: UUID
    client_request_id: UUID


class PolicyBody(BaseModel):
    enabled: bool


class PreviewBody(BaseModel):
    action: str = Field(max_length=40)
    payload: Row = Field(default_factory=dict)
    client_request_id: UUID

    @field_validator("payload")
    @classmethod
    def bounded_payload(cls, value: Row) -> Row:
        if len(json.dumps(value, ensure_ascii=False)) > 6000:
            raise ValueError("Preview payload too large")
        return value


class ApproveBody(BaseModel):
    payload_hash: str = Field(min_length=64, max_length=64)


def tool_router(engine: Engine, settings: Settings) -> APIRouter:
    routes = APIRouter()

    def user(request: Request, write: bool = False) -> Row:
        return authenticate(request, engine, settings, write)

    def idempotency(request: Request, identity: UUID) -> None:
        if request.headers.get("idempotency-key") != str(identity):
            raise BusinessError("IDEMPOTENCY_REQUIRED", "请求标识不匹配", 400)

    @routes.get("/characters/{character_id}/tool-policy")
    def policy(character_id: UUID, request: Request) -> Row:
        current = user(request)
        with engine.connect() as conn:
            state = assert_character(conn, current["id"], character_id)
        return {
            "enabled": state["tools_enabled"],
            "allowed_tools": ["local_note"],
            "external_execution_supported": False,
        }

    @routes.patch("/characters/{character_id}/tool-policy")
    def change_policy(character_id: UUID, body: PolicyBody, request: Request) -> Row:
        current = user(request, True)
        with engine.begin() as conn:
            assert_character(conn, current["id"], character_id, lock=True)
            execute(
                conn,
                "UPDATE character_states SET tools_enabled=:e,tools_epoch=tools_epoch+1 "
                "WHERE character_id=:c",
                {"e": body.enabled, "c": character_id},
            )
        return {
            "enabled": body.enabled,
            "allowed_tools": ["local_note"],
            "external_execution_supported": False,
        }

    @routes.post("/characters/{character_id}/tools/notes", status_code=201)
    def note(character_id: UUID, body: NoteBody, request: Request) -> Row:
        current = user(request, True)
        idempotency(request, body.client_request_id)
        return export_note(
            engine, settings, current["id"], character_id, body.goal_id, body.client_request_id
        )

    def history(
        character_id: UUID, request: Request, table: str, at: str, limit: int, cursor: str | None
    ) -> Row:
        current = user(request)
        with engine.connect() as conn:
            assert_character(conn, current["id"], character_id)
            params = {"o": current["id"], "c": character_id, "n": limit + 1}
            sql = f"SELECT * FROM {table} WHERE owner_id=:o AND character_id=:c"
            if cursor:
                params["at"], params["last_id"] = decode_cursor(cursor)
                sql += f" AND ({at},id)<(:at,:last_id)"
            found = rows(conn, sql + f" ORDER BY {at} DESC,id DESC LIMIT :n", params)
        more = len(found) > limit
        found = found[:limit]
        next_cursor = encode_cursor(found[-1][at], found[-1]["id"]) if more else None
        if table == "artifacts":
            found = [artifact_view(value) for value in found]
        elif table == "tool_previews":
            found = [preview_view(value) for value in found]
        return {"items": found, "next_cursor": next_cursor}

    @routes.get("/characters/{character_id}/artifacts")
    def artifacts(
        character_id: UUID,
        request: Request,
        limit: int = Query(default=100, ge=1, le=100),
        cursor: str | None = Query(default=None, max_length=512),
    ) -> Row:
        return history(character_id, request, "artifacts", "created_at", limit, cursor)

    @routes.get("/artifacts/{artifact_id}/download")
    def download(artifact_id: UUID, request: Request) -> Response:
        data = download_note(engine, settings, user(request)["id"], artifact_id)
        return Response(
            data,
            media_type="text/markdown; charset=utf-8",
            headers={
                "Content-Disposition": f'attachment; filename="fishlife-{artifact_id}.md"',
                "Cache-Control": "no-store",
                "X-Content-Type-Options": "nosniff",
            },
        )

    @routes.get("/characters/{character_id}/tool-executions")
    def executions(
        character_id: UUID,
        request: Request,
        limit: int = Query(default=100, ge=1, le=100),
        cursor: str | None = Query(default=None, max_length=512),
    ) -> Row:
        return history(character_id, request, "tool_execution_logs", "started_at", limit, cursor)

    @routes.post("/characters/{character_id}/tool-previews", status_code=201)
    def preview(character_id: UUID, body: PreviewBody, request: Request) -> Row:
        current = user(request, True)
        idempotency(request, body.client_request_id)
        return create_preview(
            engine, current["id"], character_id, body.action, body.payload, body.client_request_id
        )

    @routes.get("/characters/{character_id}/tool-previews")
    def previews(
        character_id: UUID,
        request: Request,
        limit: int = Query(default=100, ge=1, le=100),
        cursor: str | None = Query(default=None, max_length=512),
    ) -> Row:
        return history(character_id, request, "tool_previews", "created_at", limit, cursor)

    @routes.post("/tool-previews/{preview_id}/approve")
    def approve(preview_id: UUID, body: ApproveBody, request: Request) -> Row:
        return approve_preview(engine, user(request, True)["id"], preview_id, body.payload_hash)

    return routes
