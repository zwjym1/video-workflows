from typing import Annotated
from uuid import UUID
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from fastapi import APIRouter, Depends, Query, Request
from pydantic import BaseModel, Field, field_validator
from sqlalchemy import Engine

from app.config import Settings
from app.life_service import check_version, owned
from app.memory import assert_character
from app.notifications import preferences, safety_status, stop_all
from app.pagination import decode_cursor, encode_cursor
from app.repository import Row, one, rows
from app.security import authenticate


class PreferenceBody(BaseModel):
    enabled: bool
    timezone: str = Field(max_length=80)
    quiet_start_hour: int = Field(ge=0, le=23)
    quiet_end_hour: int = Field(ge=0, le=23)
    daily_limit: int = Field(ge=1, le=5)
    min_interval_minutes: int = Field(ge=60, le=1440)

    @field_validator("timezone")
    @classmethod
    def valid_timezone(cls, value: str) -> str:
        try:
            ZoneInfo(value)
        except (ZoneInfoNotFoundError, ValueError) as exc:
            raise ValueError("Unknown IANA timezone") from exc
        return value


def notifications_router(engine: Engine, settings: Settings) -> APIRouter:
    router = APIRouter()

    def user(request: Request) -> Row:
        return authenticate(request, engine, settings)

    def writer(request: Request) -> Row:
        return authenticate(request, engine, settings, True)

    @router.get("/notification-preferences")
    def get_preferences(current: Annotated[Row, Depends(user)]) -> Row:
        with engine.begin() as conn:
            return {
                **preferences(conn, current["id"]),
                "capability_enabled": settings.notifications_enabled,
            }

    @router.patch("/notification-preferences")
    def patch_preferences(
        body: PreferenceBody, request: Request, current: Annotated[Row, Depends(writer)]
    ) -> Row:
        with engine.begin() as conn:
            old = preferences(conn, current["id"], lock=True)
            check_version(old, request.headers.get("if-match"))
            result = one(
                conn,
                """UPDATE notification_preferences SET enabled=:enabled,timezone=:timezone,
                quiet_start_hour=:quiet_start_hour,quiet_end_hour=:quiet_end_hour,
                daily_limit=:daily_limit,min_interval_minutes=:min_interval_minutes,
                version=version+1,updated_at=now() WHERE owner_id=:owner RETURNING *""",
                {**body.model_dump(), "owner": current["id"]},
            )
            assert result
            return {**result, "capability_enabled": settings.notifications_enabled}

    @router.get("/characters/{character_id}/notifications")
    def list_notifications(
        character_id: UUID,
        current: Annotated[Row, Depends(user)],
        limit: int = Query(default=100, ge=1, le=100),
        cursor: str | None = Query(default=None, max_length=512),
    ) -> Row:
        with engine.connect() as conn:
            assert_character(conn, current["id"], character_id)
            params = {"o": current["id"], "c": character_id, "n": limit + 1}
            sql = "SELECT * FROM notifications WHERE owner_id=:o AND character_id=:c"
            if cursor is not None:
                params["at"], params["last_id"] = decode_cursor(cursor)
                sql += " AND (created_at,id)<(:at,:last_id)"
            found = rows(conn, sql + " ORDER BY created_at DESC,id DESC LIMIT :n", params)
            more = len(found) > limit
            found = found[:limit]
            return {
                "items": found,
                "next_cursor": (
                    encode_cursor(found[-1]["created_at"], found[-1]["id"]) if more else None
                ),
            }

    @router.post("/notifications/{notification_id}/read")
    def mark_read(notification_id: UUID, current: Annotated[Row, Depends(writer)]) -> Row:
        with engine.begin() as conn:
            value = owned(conn, "notifications", current["id"], notification_id, lock=True)
            if value["status"] == "unread":
                updated = one(
                    conn,
                    "UPDATE notifications SET status='read',read_at=now() WHERE id=:id RETURNING *",
                    {"id": notification_id},
                )
                assert updated
                value = updated
            return value

    @router.get("/safety/status")
    def get_safety(current: Annotated[Row, Depends(user)]) -> Row:
        with engine.begin() as conn:
            return safety_status(conn, current["id"])

    @router.post("/safety/stop")
    def safety_stop(current: Annotated[Row, Depends(writer)]) -> Row:
        return stop_all(engine, current["id"])

    return router
