import json
import socket
from collections.abc import Callable
from datetime import UTC, datetime, timedelta
from typing import Any, TypedDict
from uuid import UUID, uuid4

from langgraph.graph import END, START, StateGraph
from sqlalchemy import Engine

from app.budgets import reserve, settle
from app.config import Settings
from app.errors import BusinessError
from app.memory import assert_character, retrieve, save_claims
from app.memory_lifecycle import expire_due
from app.model_client import (
    MockModel,
    ModelClient,
    ModelFailure,
    ModelResult,
    OpenAIModel,
    estimate_cost,
)
from app.qoder_client import QoderCall, create_qoder_call
from app.repository import Row, execute, one, rows


def recover_expired(engine: Engine, settings: Settings) -> int:
    count = 0
    with engine.connect() as conn:
        expired = rows(
            conn,
            """SELECT id,owner_id,character_id FROM tasks WHERE status='running'
            AND lease_until<now() ORDER BY created_at LIMIT 20""",
        )
    for candidate in expired:
        with engine.begin() as conn:
            assert_character(conn, candidate["owner_id"], candidate["character_id"], lock=True)
            task = one(
                conn,
                """SELECT * FROM tasks WHERE id=:id AND status='running'
                AND lease_until<now() FOR UPDATE""",
                {"id": candidate["id"]},
            )
            if not task:
                continue
            run = one(
                conn,
                "SELECT * FROM task_runs WHERE task_id=:id ORDER BY attempt_no DESC LIMIT 1",
                {"id": task["id"]},
            )
            assert run
            held = one(
                conn,
                """SELECT r.id,u.provider FROM budget_reservations r
                JOIN model_usage_logs u ON u.reservation_id=r.id
                WHERE r.run_id=:id AND r.status='held'""",
                {"id": run["id"]},
            )
            uncertain = bool(held and held["provider"] != "mock")
            if held:
                settle(conn, held["id"], None, settings, uncertain=uncertain)
            status = (
                "unknown"
                if uncertain
                else ("queued" if task["attempt_count"] < task["max_attempts"] else "failed")
            )
            execute(
                conn,
                """UPDATE tasks SET status=:s,lease_until=NULL,lease_owner=NULL,
                fencing_token=fencing_token+1,error_code='WORKER_INTERRUPTED' WHERE id=:id""",
                {"s": status, "id": task["id"]},
            )
            execute(
                conn,
                """UPDATE task_runs SET status=:s,error_code='WORKER_INTERRUPTED',
                finished_at=now() WHERE id=:id""",
                {"s": "unknown" if uncertain else "failed", "id": run["id"]},
            )
            if task["kind"] == "local_activity" and status == "failed":
                execute(
                    conn,
                    """UPDATE goals SET status='cancelled',version=version+1,updated_at=now()
                    WHERE id=:g AND status='active'""",
                    {"g": task["goal_id"]},
                )
            count += 1
    return count


def claim_task(engine: Engine, kind: str = "chat_reply") -> Row | None:
    with engine.begin() as conn:
        candidates = rows(
            conn,
            """SELECT id,owner_id,character_id FROM tasks WHERE status
            IN ('queued','retry_wait') AND not_before<=now() AND NOT cancel_requested
            AND kind=:kind AND attempt_count<max_attempts ORDER BY created_at LIMIT 20""",
            {"kind": kind},
        )
        for candidate in candidates:
            state = assert_character(
                conn, candidate["owner_id"], candidate["character_id"], lock=True
            )
            if state["mode"] == "deleting":
                continue
            if one(
                conn,
                "SELECT id FROM tasks WHERE owner_id=:o AND character_id=:c AND status='running'",
                {"o": candidate["owner_id"], "c": candidate["character_id"]},
            ):
                continue
            task = one(
                conn,
                """SELECT * FROM tasks WHERE id=:id AND status IN ('queued','retry_wait')
                AND not_before<=now() AND NOT cancel_requested AND attempt_count<max_attempts
                FOR UPDATE SKIP LOCKED""",
                {"id": candidate["id"]},
            )
            if not task:
                continue
            run_id = uuid4()
            task["attempt_count"] += 1
            task["fencing_token"] += 1
            task["run_id"], task["memory_epoch"] = run_id, state["memory_epoch"]
            execute(
                conn,
                """UPDATE tasks SET status='running',attempt_count=:a,fencing_token=:f,
                lease_owner=:w,lease_until=now()+interval '60 seconds',updated_at=now() WHERE
                id=:id""",
                {
                    "a": task["attempt_count"],
                    "f": task["fencing_token"],
                    "w": socket.gethostname(),
                    "id": task["id"],
                },
            )
            execute(
                conn,
                """INSERT INTO task_runs(id,owner_id,character_id,task_id,attempt_no,
                status,memory_epoch,fencing_token) VALUES (:id,:o,:c,:t,:a,'running',:epoch,:f)""",
                {
                    "id": run_id,
                    "o": task["owner_id"],
                    "c": task["character_id"],
                    "t": task["id"],
                    "a": task["attempt_count"],
                    "epoch": state["memory_epoch"],
                    "f": task["fencing_token"],
                },
            )
            return task
    return None


def gather_context(engine: Engine, task: Row) -> Row:
    with engine.connect() as conn:
        state = assert_character(conn, task["owner_id"], task["character_id"])
        message = one(
            conn,
            """SELECT * FROM messages WHERE id=:id AND owner_id=:o
            AND status='completed' AND role='user'""",
            {"id": UUID(task["input"]["message_id"]), "o": task["owner_id"]},
        )
        if not message or state["memory_epoch"] != task["memory_epoch"]:
            raise BusinessError("CONTEXT_INVALIDATED", "上下文已删除或修改", 409)
        if "reading_qa" in task["input"]:
            from app.reading_qa import context as reading_context

            return reading_context(conn, task, message)
        memories = retrieve(conn, task["owner_id"], task["character_id"], message["content"])
        recent = rows(
            conn,
            """SELECT m.id,m.role,m.content FROM messages m WHERE m.conversation_id=:c
            AND m.seq<:s AND m.status='completed' AND m.content_kind<>'roleplay'
            AND NOT EXISTS (SELECT 1 FROM memory_sources src JOIN memory_items mem
              ON mem.id=src.memory_id WHERE (src.message_id=m.id OR src.message_id=m.in_reply_to)
              AND (mem.status IN ('superseded','disputed','deleted','expired')
                OR mem.expires_at<=now()))
            AND NOT EXISTS (SELECT 1 FROM message_memory_links link JOIN memory_items mem
              ON mem.id=link.memory_id WHERE link.message_id=m.id
              AND (mem.status<>'active' OR mem.expires_at<=now()))
            ORDER BY m.seq DESC LIMIT 12""",
            {"c": message["conversation_id"], "s": message["seq"]},
        )
        return {
            "message": message,
            "memories": memories,
            "persona": state["core_persona"],
            "conflicts": bool(
                one(
                    conn,
                    """SELECT id FROM memory_items WHERE owner_id=:o
                AND character_id=:c AND status='disputed' LIMIT 1""",
                    {"o": task["owner_id"], "c": task["character_id"]},
                )
            ),
            "recent_messages": [
                {"role": x["role"], "content": x["content"][:2000]} for x in reversed(recent)
            ],
            "recent_message_ids": [x["id"] for x in recent],
        }


def persist_result(
    engine: Engine,
    task: Row,
    context: Row,
    result: ModelResult,
    reservation: UUID,
    settings: Settings,
) -> None:
    with engine.begin() as conn:
        state = assert_character(conn, task["owner_id"], task["character_id"], lock=True)
        expire_due(conn, state)
        current = one(conn, "SELECT * FROM tasks WHERE id=:id FOR UPDATE", {"id": task["id"]})
        if (
            not current
            or current["status"] != "running"
            or current["cancel_requested"]
            or current["fencing_token"] != task["fencing_token"]
            or state["memory_epoch"] != task["memory_epoch"]
            or state["mode"] == "deleting"
        ):
            # Account for a completed paid request even when privacy invalidates its text.
            settle(conn, reservation, result, settings)
            return
        message = context["message"]
        if "reading_qa" in context:
            from app.reading_qa import validate_answer

            try:
                validate_answer(conn, current, result.text)
            except BusinessError as exc:
                # A malformed answer still has a real provider receipt and cost.
                settle(conn, reservation, result, settings)
                execute(
                    conn,
                    "UPDATE tasks SET status='failed',error_code=:e,lease_until=NULL WHERE id=:t",
                    {"e": exc.code, "t": task["id"]},
                )
                execute(
                    conn,
                    "UPDATE task_runs SET status='failed',error_code=:e,finished_at=now() "
                    "WHERE id=:r",
                    {"e": exc.code, "r": task["run_id"]},
                )
                return
        one(
            conn,
            "SELECT id FROM conversations WHERE id=:id FOR UPDATE",
            {"id": message["conversation_id"]},
        )
        seq = one(
            conn,
            "SELECT COALESCE(MAX(seq),0)+1 AS n FROM messages WHERE conversation_id=:id",
            {"id": message["conversation_id"]},
        )
        assert seq
        assistant_id = uuid4()
        execute(
            conn,
            """INSERT INTO messages(id,owner_id,character_id,conversation_id,role,content,
            content_kind,status,seq,in_reply_to) VALUES (:id,:o,:c,:conv,'assistant',:text,
            'inference','completed',:seq,:reply)""",
            {
                "id": assistant_id,
                "o": task["owner_id"],
                "c": task["character_id"],
                "conv": message["conversation_id"],
                "text": result.text,
                "seq": seq["n"],
                "reply": message["id"],
            },
        )
        if "reading_qa" not in context:
            save_claims(conn, task["owner_id"], task["character_id"], message, result.claims)
        # Propagate dependencies through recent messages as well as retrieved memories.
        # Newly extracted claims must exist before linking the first reply to its source.
        input_ids = [message["id"], *context.get("recent_message_ids", [])]
        dependencies = rows(
            conn,
            """SELECT memory_id FROM memory_sources WHERE owner_id=:o AND character_id=:c
            AND message_id=ANY(:ids) UNION SELECT memory_id FROM message_memory_links
            WHERE owner_id=:o AND character_id=:c AND message_id=ANY(:ids)""",
            {"o": task["owner_id"], "c": task["character_id"], "ids": input_ids},
        )
        memory_ids = {x["id"] for x in context["memories"]}
        memory_ids.update(x["memory_id"] for x in dependencies)
        for memory_id in memory_ids:
            execute(
                conn,
                """INSERT INTO message_memory_links(owner_id,character_id,message_id,memory_id)
                VALUES (:o,:c,:m,:memory)""",
                {
                    "o": task["owner_id"],
                    "c": task["character_id"],
                    "m": assistant_id,
                    "memory": memory_id,
                },
            )
        execute(
            conn,
            """UPDATE tasks SET status='succeeded',result_message_id=:m,lease_until=NULL,
            error_code=NULL,updated_at=now() WHERE id=:id""",
            {"m": assistant_id, "id": task["id"]},
        )
        execute(
            conn,
            """UPDATE task_runs SET status='succeeded',node='persist',finished_at=now()
            WHERE id=:id""",
            {"id": task["run_id"]},
        )
        execute(
            conn,
            """UPDATE character_states SET last_active_at=now(),state_version=state_version+1
            WHERE character_id=:c""",
            {"c": task["character_id"]},
        )
        execute(
            conn,
            """INSERT INTO experience_events(id,owner_id,character_id,event_type,reality_class,
            source_message_id,task_run_id,dedupe_key,payload) VALUES (:id,:o,:c,'chat_completed',
            'observed',:msg,:run,:key,CAST(:payload AS jsonb)) ON CONFLICT DO NOTHING""",
            {
                "id": uuid4(),
                "o": task["owner_id"],
                "c": task["character_id"],
                "msg": message["id"],
                "run": task["run_id"],
                "key": "reply:" + str(message["id"]),
                "payload": json.dumps({"assistant_message_id": str(assistant_id)}),
            },
        )
        settle(conn, reservation, result, settings)


def fail_task(
    engine: Engine,
    task: Row,
    code: str,
    settings: Settings,
    reservation: UUID | None = None,
    uncertain: bool = False,
) -> None:
    with engine.begin() as conn:
        assert_character(conn, task["owner_id"], task["character_id"], lock=True)
        current = one(conn, "SELECT * FROM tasks WHERE id=:id FOR UPDATE", {"id": task["id"]})
        if reservation:
            settle(conn, reservation, None, settings, uncertain=uncertain)
        if (
            not current
            or current["status"] != "running"
            or current["fencing_token"] != task["fencing_token"]
        ):
            return
        retryable = code == "MODEL_TEMPORARY" and task["attempt_count"] < task["max_attempts"]
        status = "unknown" if uncertain else ("retry_wait" if retryable else "failed")
        execute(
            conn,
            """UPDATE tasks SET status=:s,error_code=:code,lease_until=NULL,
            not_before=:time,updated_at=now() WHERE id=:id""",
            {
                "s": status,
                "code": code,
                "time": datetime.now(UTC) + timedelta(seconds=30),
                "id": task["id"],
            },
        )
        execute(
            conn,
            """UPDATE task_runs SET status=:s,error_code=:code,finished_at=now()
            WHERE id=:id""",
            {"s": status, "code": code, "id": task["run_id"]},
        )


class ChatState(TypedDict, total=False):
    context: Row
    result: ModelResult
    reservation: UUID


def process_once(
    engine: Engine,
    settings: Settings,
    client: ModelClient | None = None,
    *,
    qoder_factory: Callable[[Engine, Settings, Row, Row], QoderCall] | None = None,
) -> bool:
    recover_expired(engine, settings)
    task = claim_task(engine)
    if not task:
        return False
    reservation: UUID | None = None
    effective_settings = settings
    adapter = client or (
        MockModel()
        if settings.model_provider == "mock"
        else (OpenAIModel(settings) if settings.model_provider == "openai" else None)
    )

    def gather(state: ChatState) -> dict[str, Any]:
        return {"context": gather_context(engine, task)}

    def generate(state: ChatState) -> dict[str, Any]:
        nonlocal reservation, effective_settings
        chosen: ModelClient
        if settings.model_provider == "qoder":
            if client is not None:
                raise ModelFailure("QODER_CLIENT_OVERRIDE_FORBIDDEN")
            call = (qoder_factory or create_qoder_call)(engine, settings, task, state["context"])
            effective_settings = call.model_settings
            amount, chosen = call.estimated_usd, call
        elif settings.model_provider == "codex":
            from app.codex_client import CodexClient

            if client is not None:
                raise ModelFailure("CODEX_CLIENT_OVERRIDE_FORBIDDEN")
            effective_settings = settings.model_copy(update={"chat_model": settings.codex_model})
            amount = estimate_cost(state["context"], effective_settings)
            chosen = CodexClient(engine, effective_settings, task)
        else:
            assert adapter is not None
            amount, chosen = estimate_cost(state["context"], settings), adapter
        # Serialize reservation creation with expiry/permission invalidation, so
        # cancellation cannot miss a just-created held reservation.
        with engine.begin() as conn:
            current_state = assert_character(
                conn, task["owner_id"], task["character_id"], lock=True
            )
            expire_due(conn, current_state)
            current = one(conn, "SELECT * FROM tasks WHERE id=:id", {"id": task["id"]})
            valid = bool(
                current
                and current["status"] == "running"
                and not current["cancel_requested"]
                and current["fencing_token"] == task["fencing_token"]
                and current_state["memory_epoch"] == task["memory_epoch"]
            )
            if valid:
                reservation = reserve(engine, task, amount, effective_settings)
        if not valid:
            raise BusinessError("CONTEXT_INVALIDATED", "上下文已到期或变更，未请求模型", 409)
        assert reservation
        return {"result": chosen.generate(state["context"]), "reservation": reservation}

    def persist(state: ChatState) -> dict[str, Any]:
        persist_result(
            engine,
            task,
            state["context"],
            state["result"],
            state["reservation"],
            effective_settings,
        )
        return {}

    graph = StateGraph(ChatState)
    graph.add_node("gather", gather)
    graph.add_node("generate", generate)
    graph.add_node("persist", persist)
    graph.add_edge(START, "gather")
    graph.add_edge("gather", "generate")
    graph.add_edge("generate", "persist")
    graph.add_edge("persist", END)
    try:
        # Durable business steps contain IDs/epoch only; no private text checkpoint copies.
        graph.compile().invoke({}, {"recursion_limit": 8})
    except ModelFailure as exc:
        fail_task(engine, task, exc.code, settings, reservation, exc.uncertain)
    except BusinessError as exc:
        fail_task(engine, task, exc.code, settings, reservation)
    except Exception:
        # Provider may have completed before a DB error. Never release a paid unknown request.
        fail_task(
            engine,
            task,
            "EXECUTION_FAILED",
            effective_settings,
            reservation,
            uncertain=settings.model_provider != "mock" and reservation is not None,
        )
    return True
