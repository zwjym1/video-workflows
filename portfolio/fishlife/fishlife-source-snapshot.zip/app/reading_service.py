"""Owned immutable local sources, verified excerpts and resumable reading positions."""

import hashlib
import json
from collections.abc import Iterator
from contextlib import contextmanager
from uuid import UUID, uuid4

from sqlalchemy import Connection, Engine

from app.config import Settings
from app.errors import BusinessError
from app.memory import assert_character
from app.reading_lifecycle import cancel_reading
from app.reading_text import TextTooLargeError, prepare_text
from app.repository import Row, execute, one, rows


@contextmanager
def read_snapshot(engine: Engine) -> Iterator[Connection]:
    # Metadata, segments and evidence must come from one committed point in time.
    with engine.connect().execution_options(isolation_level="REPEATABLE READ") as conn:
        with conn.begin():
            conn.exec_driver_sql("SET TRANSACTION READ ONLY")
            yield conn


def capability(settings: Settings) -> None:
    if not settings.reading_enabled:
        raise BusinessError("READING_UNAVAILABLE", "当前服务尚未开放本地阅读", 409)


def source_error() -> BusinessError:
    return BusinessError("READING_SOURCE_INVALID", "阅读来源或处理证据已失效，未推进进度", 409)


def owned_book(conn: Connection, owner: UUID, book: UUID, *, lock: bool = False) -> Row:
    value = one(
        conn,
        "SELECT * FROM books WHERE owner_id=:o AND id=:b" + (" FOR UPDATE" if lock else ""),
        {"o": owner, "b": book},
    )
    if not value:
        raise BusinessError("NOT_FOUND", "书籍不存在", 404)
    if value["status"] == "deleted":
        raise BusinessError("BOOK_DELETED", "该阅读资料已清除", 410)
    return value


def lock_book(conn: Connection, owner: UUID, book: UUID) -> tuple[Row, Row, Row]:
    basic = owned_book(conn, owner, book)
    user = one(conn, "SELECT * FROM users WHERE id=:o FOR UPDATE", {"o": owner})
    state = assert_character(conn, owner, basic["character_id"], lock=True)
    assert user
    return user, state, owned_book(conn, owner, book, lock=True)


def permitted(user: Row, state: Row, settings: Settings) -> None:
    capability(settings)
    if (
        not settings.autonomy_enabled
        or user["disabled"]
        or user["autonomy_paused"]
        or not state["enabled"]
        or state["mode"] == "deleting"
    ):
        raise BusinessError("AUTONOMY_PAUSED", "请先启用站内活动；阅读不调用云端模型", 409)


def verified(conn: Connection, book: Row) -> tuple[list[Row], list[Row]]:
    """The counter alone is not evidence: check the complete source and successful prefix."""
    p = {"o": book["owner_id"], "c": book["character_id"], "b": book["id"]}
    segments = rows(
        conn,
        """SELECT * FROM reading_segments
        WHERE owner_id=:o AND character_id=:c AND book_id=:b ORDER BY ordinal""",
        p,
    )
    if len(segments) != book["segment_count"] or not 1 <= len(segments) <= 100:
        raise source_error()
    offset = 0
    combined = hashlib.sha256()
    for ordinal, segment in enumerate(segments):
        content = segment["content"]
        if (
            segment["deleted"]
            or segment["ordinal"] != ordinal
            or not content.strip()
            or len(content) > 2500
            or segment["start_offset"] != offset
            or segment["end_offset"] != offset + len(content)
        ):
            raise source_error()
        try:
            encoded = content.encode("utf8")
        except UnicodeError:
            raise source_error() from None
        if hashlib.sha256(encoded).hexdigest() != segment["source_hash"]:
            raise source_error()
        combined.update(encoded)
        offset += len(content)
    if offset != book["total_chars"] or combined.hexdigest() != book["source_hash"]:
        raise source_error()
    notes = rows(
        conn,
        """SELECT n.*,t.status AS task_status,t.kind AS task_kind,
        t.reading_book_id AS task_book,t.reading_ordinal AS task_ordinal,
        r.status AS run_status,r.task_id AS run_task,
        e.event_type,e.reality_class,e.payload,e.task_run_id AS event_run
        FROM reading_notes n JOIN tasks t ON t.id=n.task_id AND t.owner_id=n.owner_id
        AND t.character_id=n.character_id
        JOIN task_runs r ON r.id=n.run_id AND r.owner_id=n.owner_id
        AND r.character_id=n.character_id
        JOIN experience_events e ON e.id=n.event_id AND e.owner_id=n.owner_id
        AND e.character_id=n.character_id
        WHERE n.owner_id=:o AND n.character_id=:c AND n.book_id=:b AND n.status='active'
        ORDER BY n.ordinal""",
        p,
    )
    if len(notes) != book["cursor"]:
        raise source_error()
    for ordinal, note in enumerate(notes):
        segment = segments[ordinal]
        quotes = note["excerpts"]
        if (
            note["ordinal"] != ordinal
            or note["source_hash"] != segment["source_hash"]
            or note["task_status"] != "succeeded"
            or note["run_status"] != "succeeded"
            or note["task_kind"] != "reading_step"
            or note["run_task"] != note["task_id"]
            or note["task_book"] != book["id"]
            or note["task_ordinal"] != ordinal
            or note["event_run"] != note["run_id"]
            or note["event_type"] != "reading_segment_processed"
            or note["reality_class"] != "observed"
            or note["payload"]
            != {
                "book_id": str(book["id"]),
                "ordinal": ordinal,
                "source_hash": segment["source_hash"],
            }
            or not isinstance(quotes, list)
            or not 1 <= len(quotes) <= 3
            or any(
                not isinstance(q, str)
                or not q.strip()
                or len(q) > 220
                or q not in segment["content"]
                for q in quotes
            )
        ):
            raise source_error()
    return segments, notes


def book_view(conn: Connection, book: Row) -> Row:
    result = {
        key: book[key]
        for key in (
            "id",
            "character_id",
            "title",
            "status",
            "source_hash",
            "total_chars",
            "segment_count",
            "cursor",
            "auto_enabled",
            "interval_seconds",
            "next_read_at",
            "version",
            "created_at",
        )
    }
    result.update(method="local_extract", cloud_processing=False)
    try:
        verified(conn, book)
        result.update(source_valid=True, verified_cursor=book["cursor"])
    except BusinessError:
        result.update(source_valid=False, verified_cursor=None, error_code="READING_SOURCE_INVALID")
    result["last_task"] = one(
        conn,
        """SELECT id,status,error_code,attempt_count,max_attempts
        FROM tasks WHERE owner_id=:o AND character_id=:c AND reading_book_id=:b
        AND kind='reading_step' ORDER BY created_at DESC,id DESC LIMIT 1""",
        {"o": book["owner_id"], "c": book["character_id"], "b": book["id"]},
    )
    return result


def import_book(
    engine: Engine,
    settings: Settings,
    owner: UUID,
    character: UUID,
    title: str,
    content: str,
    import_key: UUID,
) -> Row:
    capability(settings)
    try:
        prepared = prepare_text(title, content)
    except TextTooLargeError:
        raise BusinessError("READING_TEXT_TOO_LARGE", "文本超过本地阅读限额", 413) from None
    except ValueError:
        raise BusinessError("READING_TEXT_INVALID", "请提供有效UTF-8纯文本和标题", 422) from None
    digest = hashlib.sha256(
        json.dumps([prepared["title"], prepared["source_hash"]], ensure_ascii=True).encode()
    ).hexdigest()
    p = {"o": owner, "c": character, "k": import_key}
    with engine.begin() as conn:
        user = one(conn, "SELECT id,disabled FROM users WHERE id=:o FOR UPDATE", p)
        if not user or user["disabled"]:
            raise BusinessError("ACCOUNT_UNAVAILABLE", "账号当前不可用", 409)
        state = assert_character(conn, owner, character, lock=True)
        if not state["enabled"] or state["mode"] == "deleting":
            raise BusinessError("CHARACTER_UNAVAILABLE", "角色当前不可用", 409)
        old = one(
            conn,
            """SELECT * FROM books WHERE owner_id=:o AND character_id=:c
            AND import_key=:k""",
            p,
        )
        if old:
            if old["status"] == "deleted":
                raise BusinessError("BOOK_DELETED", "该导入请求的资料已清除，请重新选择", 410)
            if old["request_hash"] != digest:
                raise BusinessError("IDEMPOTENCY_CONFLICT", "同一请求不能导入不同资料", 409)
            return book_view(conn, old)
        count = one(
            conn,
            """SELECT count(*) AS n FROM books WHERE owner_id=:o
            AND character_id=:c AND status<>'deleted'""",
            p,
        )
        if count and count["n"] >= 20:
            raise BusinessError("READING_LIBRARY_FULL", "每角色最多保留20本资料，请先清理", 409)
        identifier = uuid4()
        book = one(
            conn,
            """INSERT INTO books(id,owner_id,character_id,title,source_hash,
            total_chars,segment_count,import_key,request_hash)
            VALUES (:b,:o,:c,:title,:hash,:chars,:segments,:k,:request) RETURNING *""",
            {
                **p,
                "b": identifier,
                "title": prepared["title"],
                "hash": prepared["source_hash"],
                "chars": prepared["total_chars"],
                "segments": len(prepared["segments"]),
                "request": digest,
            },
        )
        assert book
        for segment in prepared["segments"]:
            execute(
                conn,
                """INSERT INTO reading_segments(owner_id,character_id,book_id,
                ordinal,start_offset,end_offset,content,source_hash)
                VALUES (:o,:c,:b,:ordinal,:start_offset,:end_offset,:content,:source_hash)""",
                {**p, "b": identifier, **segment},
            )
        return book_view(conn, book)


def list_books(engine: Engine, settings: Settings, owner: UUID, character: UUID) -> Row:
    with read_snapshot(engine) as conn:
        assert_character(conn, owner, character)
        found = (
            rows(
                conn,
                """SELECT * FROM books WHERE owner_id=:o AND character_id=:c
            AND status<>'deleted' ORDER BY created_at DESC,id DESC LIMIT 20""",
                {"o": owner, "c": character},
            )
            if settings.reading_enabled
            else []
        )
        return {
            "items": [book_view(conn, book) for book in found],
            "max_books": 20,
            "capability_enabled": settings.reading_enabled,
            "method": "local_extract",
        }


def get_book(engine: Engine, settings: Settings, owner: UUID, book: UUID) -> Row:
    capability(settings)
    with read_snapshot(engine) as conn:
        return book_view(conn, owned_book(conn, owner, book))


def segment_view(engine: Engine, settings: Settings, owner: UUID, book: UUID, ordinal: int) -> Row:
    capability(settings)
    with read_snapshot(engine) as conn:
        value = owned_book(conn, owner, book)
        segments, _ = verified(conn, value)
        if not 0 <= ordinal < len(segments):
            raise BusinessError("NOT_FOUND", "段落不存在", 404)
        return {
            key: segments[ordinal][key]
            for key in ("ordinal", "start_offset", "end_offset", "content", "source_hash")
        }


def list_notes(
    engine: Engine, settings: Settings, owner: UUID, book: UUID, after: int = -1, limit: int = 20
) -> Row:
    capability(settings)
    if not -1 <= after < 100 or not 1 <= limit <= 100:
        raise BusinessError("INVALID_PAGE", "笔记分页参数无效", 422)
    with read_snapshot(engine) as conn:
        _, notes = verified(conn, owned_book(conn, owner, book))
        eligible = [note for note in notes if note["ordinal"] > after]
        visible = eligible[:limit]
        return {
            "items": [
                {
                    **{
                        key: note[key]
                        for key in (
                            "id",
                            "ordinal",
                            "source_hash",
                            "excerpts",
                            "task_id",
                            "run_id",
                            "event_id",
                            "created_at",
                        )
                    },
                    "method": "local_extract",
                }
                for note in visible
            ],
            "next_after": visible[-1]["ordinal"] if len(eligible) > limit else None,
        }


def configure_book(
    engine: Engine,
    settings: Settings,
    owner: UUID,
    book: UUID,
    enabled: bool,
    interval: int,
    expected_version: int,
) -> Row:
    capability(settings)
    if not isinstance(enabled, bool) or type(interval) is not int or not 60 <= interval <= 86400:
        raise BusinessError("INVALID_READING_POLICY", "阅读间隔应为60秒到一天", 422)
    with engine.begin() as conn:
        user, state, value = lock_book(conn, owner, book)
        if value["version"] != expected_version:
            raise BusinessError("BOOK_CHANGED", "阅读进度或设置已变化，请刷新", 409)
        if enabled:
            permitted(user, state, settings)
            verified(conn, value)
            if value["status"] == "completed":
                raise BusinessError("BOOK_FINISHED", "资料已处理完毕", 409)
        cancel_reading(conn, owner, value["character_id"], book, bump_versions=False)
        changed = one(
            conn,
            """UPDATE books SET auto_enabled=:e,interval_seconds=:i,
            next_read_at=clock_timestamp()+make_interval(secs=>:i),version=version+1,
            updated_at=now() WHERE id=:b RETURNING *""",
            {"b": book, "e": enabled, "i": interval},
        )
        assert changed
        return book_view(conn, changed)


def enqueue_locked(
    conn: Connection,
    settings: Settings,
    user: Row,
    state: Row,
    book: Row,
    key: str,
    expected_version: int,
) -> Row:
    permitted(user, state, settings)
    p = {"o": book["owner_id"], "c": book["character_id"], "b": book["id"], "k": key}
    prior = one(conn, "SELECT * FROM tasks WHERE owner_id=:o AND idempotency_key=:k", p)
    if prior:
        if prior["kind"] != "reading_step" or prior["reading_book_id"] != book["id"]:
            raise BusinessError("IDEMPOTENCY_CONFLICT", "请求标识已用于其他任务", 409)
        return {"task_id": prior["id"], "status": prior["status"]}
    if book["version"] != expected_version:
        raise BusinessError("BOOK_CHANGED", "阅读进度或设置已变化，请刷新", 409)
    segments, _ = verified(conn, book)
    if book["cursor"] == book["segment_count"]:
        return {"task_id": None, "status": "quiet", "reason": "资料已全部处理"}
    existing = one(
        conn,
        """SELECT id,status FROM tasks WHERE owner_id=:o
        AND character_id=:c AND reading_book_id=:b AND kind='reading_step'
        AND reading_ordinal=:ordinal AND status IN
        ('queued','retry_wait','running','succeeded','failed','unknown')
        ORDER BY created_at DESC,id DESC LIMIT 1""",
        {**p, "ordinal": book["cursor"]},
    )
    if existing:
        return {"task_id": existing["id"], "status": existing["status"]}
    task = uuid4()
    source = segments[book["cursor"]]
    execute(
        conn,
        """INSERT INTO tasks(id,owner_id,character_id,kind,input,status,
        idempotency_key,max_attempts,reading_book_id,reading_ordinal)
        VALUES (:id,:o,:c,'reading_step',CAST(:input AS jsonb),'queued',:k,3,:b,:ordinal)""",
        {
            **p,
            "id": task,
            "ordinal": book["cursor"],
            "input": json.dumps(
                {
                    "book_version": book["version"],
                    "source_hash": source["source_hash"],
                }
            ),
        },
    )
    return {"task_id": task, "status": "queued"}


def enqueue_next(
    engine: Engine,
    settings: Settings,
    owner: UUID,
    book: UUID,
    request_key: UUID,
    expected_version: int,
) -> Row:
    capability(settings)
    with engine.begin() as conn:
        user, state, value = lock_book(conn, owner, book)
        return enqueue_locked(
            conn, settings, user, state, value, "reading:" + str(request_key), expected_version
        )


def delete_book(engine: Engine, settings: Settings, owner: UUID, book: UUID) -> Row:
    capability(settings)
    with engine.begin() as conn:
        _, _, value = lock_book(conn, owner, book)
        p = {"o": owner, "c": value["character_id"], "b": book}
        from app.reading_qa import erase as erase_questions

        erase_questions(conn, owner, value["character_id"], book)
        cancel_reading(conn, owner, value["character_id"], book, bump_versions=False)
        execute(
            conn,
            """UPDATE books SET title='已删除',status='deleted',source_hash=NULL,
            request_hash=NULL,total_chars=0,segment_count=0,cursor=0,auto_enabled=false,
            version=version+1,updated_at=now() WHERE id=:b""",
            p,
        )
        execute(
            conn,
            """UPDATE reading_segments SET content='',source_hash=NULL,
            start_offset=0,end_offset=0,deleted=true WHERE book_id=:b""",
            p,
        )
        execute(
            conn,
            """UPDATE reading_notes SET excerpts='[]',source_hash=NULL,status='deleted'
            WHERE owner_id=:o AND character_id=:c AND book_id=:b""",
            p,
        )
        execute(
            conn,
            """UPDATE tasks SET input='{}',result=NULL WHERE owner_id=:o
            AND character_id=:c AND reading_book_id=:b AND kind='reading_step'""",
            p,
        )
        execute(
            conn,
            """UPDATE experience_events SET payload='{}' WHERE owner_id=:o
            AND character_id=:c AND event_type='reading_segment_processed'
            AND task_run_id IN (SELECT r.id FROM task_runs r JOIN tasks t ON t.id=r.task_id
                WHERE t.owner_id=:o AND t.character_id=:c AND t.reading_book_id=:b)""",
            p,
        )
        return {"status": "deleted", "backup_erasure": False}
