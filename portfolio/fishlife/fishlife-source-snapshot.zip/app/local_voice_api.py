"""Explicit local synthesis of owned replies; generated audio is never cached."""

import os
import subprocess
import threading
from pathlib import Path
from uuid import UUID

from fastapi import APIRouter, Request, Response
from sqlalchemy import Engine

from app.config import Settings
from app.errors import BusinessError
from app.fish_audio import MAX_AUDIO_BYTES, SpeechProviderFailure, verify_wav
from app.repository import Row, one
from app.security import authenticate

ROOT = Path(__file__).resolve().parent.parent
RUNTIME = ROOT.parent / "work/tts-runtime"
PYTHON = RUNTIME / ".venv/Scripts/python.exe"
HELPER = ROOT / "scripts/synthesize_local_voice.py"
MODEL = RUNTIME / "kokoro-multi-lang-v1_1/model.onnx"
SYNTHESIS_LOCK = threading.Lock()


def available() -> bool:
    return PYTHON.is_file() and HELPER.is_file() and MODEL.is_file()


def synthesize(content: str) -> bytes:
    environment = {
        key: value for key, value in os.environ.items() if key.upper() in {"SYSTEMROOT", "WINDIR"}
    }
    environment.update(PYTHONUTF8="1", PYTHONNOUSERSITE="1", HF_HUB_OFFLINE="1")
    try:
        with subprocess.Popen(
            [str(PYTHON), str(HELPER)],
            cwd=RUNTIME,
            env=environment,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        ) as process:
            expired = threading.Event()

            def kill() -> None:
                expired.set()
                if process.poll() is None:
                    process.kill()

            timer = threading.Timer(60, kill)
            timer.start()
            try:
                assert process.stdin is not None and process.stdout is not None
                process.stdin.write(content.encode("utf8"))
                process.stdin.close()
                data = process.stdout.read(MAX_AUDIO_BYTES + 1)
                if len(data) > MAX_AUDIO_BYTES:
                    process.kill()
                code = process.wait(timeout=5)
                if expired.is_set():
                    raise BusinessError("LOCAL_VOICE_TIMEOUT", "语音生成超时，请稍后再试", 504)
                if code or len(data) > MAX_AUDIO_BYTES:
                    raise BusinessError("LOCAL_VOICE_FAILED", "本地语音生成失败", 502)
                return data
            finally:
                timer.cancel()
                if process.poll() is None:
                    process.kill()
                    process.wait(timeout=5)
    except (OSError, subprocess.SubprocessError) as exc:
        raise BusinessError("LOCAL_VOICE_FAILED", "本地语音暂时不可用", 502) from exc


def source(engine: Engine, owner: UUID, message: UUID) -> Row:
    with engine.connect() as conn:
        value = one(
            conn,
            """SELECT m.content,m.version FROM messages m
            JOIN conversations cv ON cv.id=m.conversation_id AND cv.owner_id=m.owner_id
            JOIN characters c ON c.id=m.character_id AND c.owner_id=m.owner_id
            JOIN character_states s ON s.character_id=c.id AND s.owner_id=c.owner_id
            JOIN users u ON u.id=m.owner_id
            WHERE m.id=:m AND m.owner_id=:o AND m.role='assistant'
            AND m.status='completed' AND m.content<>'' AND c.enabled
            AND s.mode<>'deleting' AND NOT u.disabled""",
            {"m": message, "o": owner},
        )
    if not value:
        raise BusinessError("NOT_FOUND", "回复不存在或已清除", 404)
    return value


def local_voice_router(engine: Engine, settings: Settings) -> APIRouter:
    router = APIRouter()

    @router.get("/speech/capabilities")
    def capabilities(request: Request) -> Row:
        authenticate(request, engine, settings)
        return {
            "available": available(),
            "provider": "kokoro_local",
            "cloud_processing": False,
            "max_characters": 500,
            "server_cached": False,
        }

    @router.post("/messages/{message_id}/audio")
    def audio(message_id: UUID, request: Request) -> Response:
        owner = authenticate(request, engine, settings, True)["id"]
        original = source(engine, owner, message_id)
        if not original["content"].strip() or len(original["content"]) > 500:
            raise BusinessError("VOICE_TEXT_LIMIT", "语音支持最多500字的单条回复", 422)
        if not available():
            raise BusinessError("LOCAL_VOICE_UNAVAILABLE", "本地语音模型尚未就绪", 503)
        if not SYNTHESIS_LOCK.acquire(blocking=False):
            raise BusinessError("LOCAL_VOICE_BUSY", "正在生成另一段语音，请稍后再试", 409)
        try:
            try:
                data = synthesize(original["content"])
                if len(data) > MAX_AUDIO_BYTES:
                    raise SpeechProviderFailure("AUDIO_TOO_LARGE")
                verify_wav(data)
            except SpeechProviderFailure as exc:
                raise BusinessError(
                    "LOCAL_VOICE_INVALID_AUDIO", "生成的音频未通过校验", 502
                ) from exc
            authenticate(request, engine, settings, True)
            if source(engine, owner, message_id) != original:
                raise BusinessError("VOICE_SOURCE_CHANGED", "回复已变化，请刷新后重试", 409)
            return Response(
                data,
                media_type="audio/wav",
                headers={
                    "Cache-Control": "private, no-store",
                    "Content-Disposition": 'attachment; filename="voice.wav"',
                    "X-Voice-Provider": "kokoro_local",
                },
            )
        finally:
            SYNTHESIS_LOCK.release()

    return router
