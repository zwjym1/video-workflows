import json
from datetime import UTC, datetime
from decimal import Decimal
from typing import Any, Literal
from uuid import UUID

from fastapi import APIRouter, Query, Request, Response
from pydantic import BaseModel, ConfigDict, Field, field_validator
from sqlalchemy import Engine

from app.activity_planning_api import activity_planning_router
from app.autobiography_api import autobiography_router
from app.config import Settings
from app.errors import BusinessError
from app.exchanges_api import exchanges_router
from app.experience_api import experience_router
from app.interest_growth_api import interest_growth_router
from app.life_service import (
    create_character,
    create_conversation,
    enqueue_message,
    list_messages,
    owned,
    retry_message,
    update_character,
)
from app.living_api import living_router
from app.local_voice_api import local_voice_router
from app.memory import assert_character, memory_view
from app.memory_lifecycle_api import memory_lifecycle_router
from app.notifications_api import notifications_router
from app.pagination import decode_cursor, encode_cursor
from app.privacy import correct_memory, delete_memory
from app.qoder_settlement import settle_qoder
from app.reading_api import reading_router
from app.release import APP_VERSION, CAPABILITIES, SCHEMA_REVISION, STAGE
from app.repository import Row, execute, one, rows
from app.security import COOKIE, authenticate, login, require_origin
from app.tool_api import tool_router
from app.web_api import web_router


class LoginBody(BaseModel):
    username: str = Field(min_length=1, max_length=80)
    password: str = Field(min_length=1, max_length=256)


class BudgetBody(BaseModel):
    daily_limit: Decimal = Field(ge=0, le=1000, decimal_places=8, allow_inf_nan=False)
    monthly_limit: Decimal = Field(ge=0, le=10000, decimal_places=8, allow_inf_nan=False)
    expected_daily_limit: Decimal = Field(ge=0, allow_inf_nan=False)
    expected_monthly_limit: Decimal = Field(ge=0, allow_inf_nan=False)


class QoderSettlementBody(BaseModel):
    model_config = ConfigDict(extra="forbid")

    idempotency_key: UUID
    actual_cost_usd: Decimal = Field(ge=0, le=1000000, decimal_places=8, allow_inf_nan=False)
    actual_credits: Decimal = Field(ge=0, le=1000000, decimal_places=8, allow_inf_nan=False)
    expected_reserved_usd: Decimal = Field(ge=0, le=1000000, decimal_places=8, allow_inf_nan=False)
    evidence_sha256: str = Field(min_length=64, max_length=64, pattern=r"^[0-9a-f]{64}$")
    acknowledgement: Literal["我已核对这次调用的供应商账单"]


class CharacterBody(BaseModel):
    name: str = Field(min_length=1, max_length=80)
    core_persona: dict[str, Any] = Field(default_factory=dict)
    interests: list[str] = Field(default_factory=list, max_length=20)

    @field_validator("core_persona")
    @classmethod
    def bounded_persona(cls, value: dict[str, Any]) -> dict[str, Any]:
        if len(json.dumps(value, ensure_ascii=False)) > 6000:
            raise ValueError("Persona too large")
        return value


class ConversationBody(BaseModel):
    title: str = Field(default="新对话", min_length=1, max_length=120)


class MessageBody(BaseModel):
    content: str = Field(min_length=1, max_length=6000)
    client_request_id: UUID
    content_kind: Literal["real", "roleplay", "inference"] = "real"


class CorrectionBody(BaseModel):
    content: str = Field(min_length=1, max_length=1000)
    reason: str = Field(default="用户修正", max_length=500)


def router(engine: Engine, settings: Settings) -> APIRouter:
    routes = APIRouter(prefix="/api/v1")

    def user(request: Request, write: bool = False) -> Row:
        return authenticate(request, engine, settings, write)

    @routes.post("/auth/login")
    def auth_login(body: LoginBody, request: Request, response: Response) -> Row:
        require_origin(request, settings)
        value, token = login(engine, settings, body.username, body.password)
        response.set_cookie(
            COOKIE,
            token,
            httponly=True,
            samesite="lax",
            secure=settings.public_origin.startswith("https://"),
            max_age=settings.session_days * 86400,
        )
        return value

    @routes.get("/auth/me")
    def me(request: Request) -> Row:
        current = user(request)
        return {
            "user": {"id": current["id"], "username": current["username"]},
            "csrf_token": current["csrf_token"],
        }

    @routes.post("/auth/logout", status_code=204)
    def logout(request: Request, response: Response) -> None:
        current = user(request, True)
        with engine.begin() as conn:
            execute(
                conn,
                "UPDATE sessions SET revoked_at=now() WHERE id=:id",
                {"id": current["session_id"]},
            )
        response.delete_cookie(COOKIE)

    @routes.get("/characters")
    def characters(request: Request) -> Row:
        current = user(request)
        with engine.connect() as conn:
            return {
                "items": rows(
                    conn,
                    "SELECT * FROM characters WHERE owner_id=:o ORDER BY created_at",
                    {"o": current["id"]},
                ),
                "next_cursor": None,
            }

    @routes.post("/characters", status_code=201)
    def new_character(body: CharacterBody, request: Request) -> Row:
        current = user(request, True)
        return create_character(engine, current["id"], body.name, body.core_persona, body.interests)

    @routes.get("/characters/{character_id}")
    def character(character_id: UUID, request: Request) -> Row:
        current = user(request)
        with engine.connect() as conn:
            return owned(conn, "characters", current["id"], character_id)

    @routes.patch("/characters/{character_id}")
    def patch_character(character_id: UUID, body: CharacterBody, request: Request) -> Row:
        current = user(request, True)
        return update_character(
            engine, current["id"], character_id, body.model_dump(), request.headers.get("if-match")
        )

    @routes.get("/characters/{character_id}/state")
    def character_state(character_id: UUID, request: Request) -> Row:
        current = user(request)
        with engine.connect() as conn:
            return assert_character(conn, current["id"], character_id)

    @routes.get("/characters/{character_id}/conversations")
    def conversations(character_id: UUID, request: Request) -> Row:
        current = user(request)
        with engine.connect() as conn:
            assert_character(conn, current["id"], character_id)
            return {
                "items": rows(
                    conn,
                    """SELECT * FROM conversations WHERE owner_id=:o
                    AND NOT EXISTS (SELECT 1 FROM tasks t WHERE t.owner_id=:o
                        AND t.input->>'conversation_id'=conversations.id::text
                        AND t.input ? 'reading_qa')
                AND character_id=:c ORDER BY created_at DESC LIMIT 100""",
                    {"o": current["id"], "c": character_id},
                ),
                "next_cursor": None,
            }

    @routes.post("/characters/{character_id}/conversations", status_code=201)
    def new_conversation(character_id: UUID, body: ConversationBody, request: Request) -> Row:
        current = user(request, True)
        return create_conversation(engine, current["id"], character_id, body.title)

    @routes.get("/conversations/{conversation_id}/messages")
    def messages(conversation_id: UUID, request: Request, cursor: int | None = None) -> Row:
        current = user(request)
        items = list_messages(engine, current["id"], conversation_id, cursor)
        truncated = bool(items and items[0]["seq"] > 1)
        return {
            "items": items,
            "truncated": truncated,
            "next_cursor": str(items[0]["seq"]) if truncated else None,
        }

    @routes.post("/conversations/{conversation_id}/messages", status_code=202)
    def new_message(conversation_id: UUID, body: MessageBody, request: Request) -> Row:
        current = user(request, True)
        if request.headers.get("idempotency-key") != str(body.client_request_id):
            raise BusinessError("IDEMPOTENCY_REQUIRED", "消息请求标识不匹配", 400)
        return enqueue_message(
            engine,
            current["id"],
            conversation_id,
            body.content,
            body.client_request_id,
            body.content_kind,
        )

    @routes.post("/messages/{message_id}/retry", status_code=202)
    def retry(message_id: UUID, request: Request) -> Row:
        current = user(request, True)
        return retry_message(engine, current["id"], message_id)

    @routes.get("/jobs/{job_id}")
    def job(job_id: UUID, request: Request) -> Row:
        current = user(request)
        with engine.connect() as conn:
            value = owned(conn, "tasks", current["id"], job_id)
            value.pop("input", None)
            return value

    @routes.get("/characters/{character_id}/memories")
    def memories(
        character_id: UUID,
        request: Request,
        q: str = "",
        status: str = "active",
        limit: int = Query(default=100, ge=1, le=100),
        cursor: str | None = Query(default=None, max_length=512),
    ) -> Row:
        current = user(request)
        with engine.connect() as conn:
            assert_character(conn, current["id"], character_id)
            params = {
                "o": current["id"],
                "c": character_id,
                "s": status,
                "q": "%" + q[:100] + "%",
                "n": limit + 1,
            }
            condition = ""
            if cursor:
                params["at"], params["last_id"] = decode_cursor(cursor)
                condition = " AND (created_at,id)<(:at,:last_id)"
            values = rows(
                conn,
                """SELECT * FROM memory_items WHERE owner_id=:o AND character_id=:c
                AND status<>'deleted' AND (:s='all' OR status=:s)
                AND content ILIKE :q"""
                + condition
                + " ORDER BY created_at DESC,id DESC LIMIT :n",
                params,
            )
            more = len(values) > limit
            values = values[:limit]
            return {
                "items": [memory_view(conn, x) for x in values],
                "next_cursor": encode_cursor(values[-1]["created_at"], values[-1]["id"])
                if more
                else None,
                "retrieval_mode": "keyword_recent",
                "embedding_enabled": False,
            }

    @routes.get("/memories/{memory_id}")
    def memory(memory_id: UUID, request: Request) -> Row:
        current = user(request)
        with engine.connect() as conn:
            return memory_view(conn, owned(conn, "memory_items", current["id"], memory_id))

    @routes.patch("/memories/{memory_id}")
    def patch_memory(memory_id: UUID, body: CorrectionBody, request: Request) -> Row:
        current = user(request, True)
        return correct_memory(
            engine,
            current["id"],
            memory_id,
            body.content,
            body.reason,
            request.headers.get("if-match"),
        )

    @routes.delete("/memories/{memory_id}", status_code=202)
    def forget(
        memory_id: UUID,
        request: Request,
        scope: Literal["memory_and_sources", "memory_only"] = "memory_and_sources",
    ) -> Row:
        current = user(request, True)
        return delete_memory(engine, current["id"], memory_id, scope)

    @routes.get("/deletions/{deletion_id}")
    def deletion(deletion_id: UUID, request: Request) -> Row:
        current = user(request)
        with engine.connect() as conn:
            return owned(conn, "deletion_requests", current["id"], deletion_id)

    @routes.get("/characters/{character_id}/events")
    def events(
        character_id: UUID,
        request: Request,
        limit: int = Query(default=100, ge=1, le=100),
        cursor: str | None = Query(default=None, max_length=512),
    ) -> Row:
        current = user(request)
        with engine.connect() as conn:
            assert_character(conn, current["id"], character_id)
            params = {"o": current["id"], "c": character_id, "n": limit + 1}
            condition = ""
            if cursor:
                params["at"], params["last_id"] = decode_cursor(cursor)
                condition = " AND (occurred_at,id)<(:at,:last_id)"
            items = rows(
                conn,
                "SELECT * FROM experience_events WHERE owner_id=:o "
                "AND character_id=:c" + condition + " ORDER BY occurred_at DESC,id DESC LIMIT :n",
                params,
            )
            more = len(items) > limit
            items = items[:limit]
            return {
                "items": items,
                "next_cursor": encode_cursor(items[-1]["occurred_at"], items[-1]["id"])
                if more
                else None,
            }

    @routes.get("/runtime/status")
    def runtime(request: Request) -> Row:
        user(request)
        with engine.connect() as conn:
            heartbeat = one(
                conn, "SELECT heartbeat_at FROM service_heartbeats WHERE service_name='worker'"
            )
        online = bool(
            heartbeat and 0 <= (datetime.now(UTC) - heartbeat["heartbeat_at"]).total_seconds() < 70
        )
        return {
            "stage": STAGE,
            "app_version": APP_VERSION,
            "schema_revision": SCHEMA_REVISION,
            "capabilities": dict(CAPABILITIES),
            "activity_mode": (
                "bounded_goal_choice_opt_in"
                if settings.model_planning_enabled
                else "local_deterministic"
            ),
            "model_planning_enabled": settings.model_planning_enabled,
            "reading_enabled": settings.reading_enabled,
            "reading_mode": "local_extract",
            "exchange_mode": "bounded_roleplay_template",
            "model_provider": settings.model_provider,
            "real_model_enabled": settings.allow_real_model_calls,
            "autonomy_enabled": settings.autonomy_enabled,
            "notifications_enabled": settings.notifications_enabled,
            "worker": {
                "online": online,
                "last_heartbeat_at": heartbeat["heartbeat_at"] if heartbeat else None,
            },
            "retrieval_mode": "keyword_recent",
            "embedding_enabled": False,
        }

    @routes.patch("/costs/limits")
    def update_budget(request: Request, body: BudgetBody) -> Row:
        current = user(request, True)
        with engine.begin() as conn:
            updated = one(
                conn,
                """UPDATE users SET daily_budget_usd=:d,monthly_budget_usd=:m
                WHERE id=:o AND daily_budget_usd=:old_d AND monthly_budget_usd=:old_m
                RETURNING daily_budget_usd,monthly_budget_usd""",
                {
                    "o": current["id"],
                    "d": body.daily_limit,
                    "m": body.monthly_limit,
                    "old_d": body.expected_daily_limit,
                    "old_m": body.expected_monthly_limit,
                },
            )
            if updated is None:
                raise BusinessError("BUDGET_SETTINGS_CHANGED", "预算已变化，请刷新后重试", 409)
        return {
            "limit": updated["daily_budget_usd"],
            "monthly_limit": updated["monthly_budget_usd"],
            "currency": "USD",
        }

    @routes.post("/costs/qoder/{reservation_id}/settlement")
    def confirm_qoder_settlement(
        request: Request, reservation_id: UUID, body: QoderSettlementBody
    ) -> Row:
        current = user(request, True)
        return settle_qoder(
            engine,
            current["id"],
            reservation_id,
            **body.model_dump(exclude={"acknowledgement"}),
        )

    @routes.get("/costs/qoder/{reservation_id}/settlement")
    def qoder_settlement_record(request: Request, reservation_id: UUID) -> Row:
        current = user(request)
        with engine.connect() as conn:
            result = one(
                conn,
                """SELECT reservation_id,dispatch_id,actual_cost_usd,actual_credits,
                evidence_sha256,confirmed_at,verification_source FROM qoder_settlements
                WHERE reservation_id=:r AND owner_id=:o""",
                {"r": reservation_id, "o": current["id"]},
            )
        if result is None:
            raise BusinessError("QODER_SETTLEMENT_NOT_FOUND", "人工确认记录不存在", 404)
        return result

    @routes.get("/costs/unresolved")
    def unresolved_costs(
        request: Request,
        limit: int = Query(default=20, ge=1, le=100),
        cursor: str | None = Query(default=None, max_length=512),
    ) -> Row:
        current = user(request)
        params: Row = {"o": current["id"], "limit": limit + 1}
        boundary = ""
        if cursor is not None:
            params["at"], params["id"] = decode_cursor(cursor)
            boundary = " AND (u.created_at,u.id)<(:at,:id)"
        with engine.connect() as conn:
            values = rows(
                conn,
                """SELECT u.id,u.created_at,u.provider,u.model,u.purpose,u.run_id,
                u.reservation_id,u.estimated_cost_usd,u.actual_cost_usd,u.status,
                u.pricing_version,u.provider_request_id,
                CASE WHEN q.reservation_id IS NULL THEN NULL ELSE jsonb_build_object(
                  'request_id',q.request_id,'session_id',q.session_id,
                  'reported_cost_usd',q.reported_cost_usd::text,
                  'reported_credits',q.reported_credits::text,
                  'verification_status',q.verification_status,'reported_at',q.reported_at
                ) END AS qoder_report
                FROM model_usage_logs u LEFT JOIN qoder_usage_reports q
                  ON q.reservation_id=u.reservation_id AND q.owner_id=u.owner_id
                  AND u.provider='qoder' AND q.provider_model=u.model
                WHERE u.owner_id=:o AND u.status='unknown'"""
                + boundary
                + " ORDER BY u.created_at DESC,u.id DESC LIMIT :limit",
                params,
            )
        items = values[:limit]
        return {
            "items": items,
            "next_cursor": (
                encode_cursor(items[-1]["created_at"], items[-1]["id"])
                if len(values) > limit
                else None
            ),
        }

    @routes.get("/costs/summary")
    def costs(request: Request) -> Row:
        current = user(request)
        with engine.connect() as conn:
            limits = one(
                conn,
                "SELECT daily_budget_usd,monthly_budget_usd FROM users WHERE id=:o",
                {"o": current["id"]},
            )
            value = one(
                conn,
                """SELECT COALESCE(SUM(actual_cost_usd),0) AS spent,
                COALESCE(SUM(CASE WHEN status IN ('reserved','unknown') THEN estimated_cost_usd
                ELSE 0 END),0)
                AS reserved,
                COALESCE(SUM(estimated_cost_usd) FILTER (WHERE status='unknown'),0)
                AS unknown_reserved,
                COUNT(*) FILTER (WHERE status='unknown') AS unknown_count,
                COUNT(*) FILTER (WHERE status='reserved') AS pending_count
                FROM model_usage_logs WHERE owner_id=:o""",
                {"o": current["id"]},
            )
        assert value and limits
        return {
            **value,
            "limit": limits["daily_budget_usd"],
            "monthly_limit": limits["monthly_budget_usd"],
            "currency": "USD",
            "scope": "all_time",
            "provider": settings.model_provider,
        }

    routes.include_router(living_router(engine, settings))
    routes.include_router(activity_planning_router(engine, settings))
    routes.include_router(tool_router(engine, settings))
    routes.include_router(notifications_router(engine, settings))
    routes.include_router(exchanges_router(engine, settings))
    routes.include_router(web_router(engine, settings))
    routes.include_router(autobiography_router(engine, settings))
    routes.include_router(memory_lifecycle_router(engine, settings))
    routes.include_router(experience_router(engine, settings))
    routes.include_router(reading_router(engine, settings))
    routes.include_router(interest_growth_router(engine, settings))
    routes.include_router(local_voice_router(engine, settings))
    return routes
