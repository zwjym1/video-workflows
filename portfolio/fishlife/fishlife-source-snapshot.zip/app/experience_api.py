from uuid import UUID

from fastapi import APIRouter, Request
from sqlalchemy import Engine

from app import experience_catalog
from app.config import Settings
from app.repository import Row
from app.security import authenticate


def experience_router(engine: Engine, settings: Settings) -> APIRouter:
    routes = APIRouter()

    @routes.get("/characters/{character_id}/skills")
    def listing(character_id: UUID, request: Request) -> Row:
        user = authenticate(request, engine, settings)
        with engine.begin() as conn:
            return experience_catalog.catalog(conn, settings, user["id"], character_id)

    return routes
